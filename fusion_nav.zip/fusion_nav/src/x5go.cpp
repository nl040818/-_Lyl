// 包含必要的头文件
#include "rclcpp/rclcpp.hpp"  // ROS2核心功能
#include "geometry_msgs/msg/twist.hpp"  // 速度控制消息
#include "ai_msgs/msg/perception_targets.hpp"  // AI感知目标消息
#include "std_msgs/msg/int32.hpp"  // 整型消息
#include <queue>  // 队列容器
#include <mutex>  // 线程互斥锁
#include <thread>  // 线程支持
#include <atomic>  // 原子操作
#include <condition_variable>  // 条件变量
#include <algorithm>  // 算法函数
#include <tuple>       // tuple支持
#include <stdexcept>   // 标准异常支持
#include <cstdio>      // 用于size_t格式说明符

// 图像尺寸常量
const int OBSTACLE_IMAGE_WIDTH = 640;   // 障碍物检测图像宽度
const int OBSTACLE_IMAGE_HEIGHT = 480;  // 障碍物检测图像高度

// 机器人状态枚举
enum class RobotState {
    LINE_FOLLOWING,    // 线路跟踪状态
    OBSTACLE_AVOIDING, // 避障状态
    RETURN_TO_LINE,    // 返回航线状态
    PARKING,           // 停车点状态
    QR_TRACKING,       // 新增：二维码追踪状态
    STOPPED            // 停止状态
};

// 转向方向枚举
enum class TurnDirection {
    LEFT,   // 左转
    RIGHT,  // 右转
    UNKNOWN // 未知方向
};

// 主节点类：赛道跟踪与避障
class TrackFollower : public rclcpp::Node {
public:
    TrackFollower() 
        : Node("track_follower"),
        Kp_(0.8), Ki_(0.0), Kd_(0.7),
        angular_z_(0), last_error_(0), error_sum_(0), error_diff_(0), output_(0),
        process_stop_(false),  // 线程停止标志
        sub_target_(false),    // 是否接到障碍物目标
        sub_parking_(false),   // 是否到停车点目标
        sub_line_point_(false), // 是否接收到线路点目标
        block_cmd_vel_(true), // 默认屏蔽cmd_vel发布
        current_state_(RobotState::LINE_FOLLOWING), // 初始状态为线路跟踪
        obstacle_detected_(false), // 初始化障碍物检测状态
        parking_detected_(false),  // 初始化停车点检测状态
        qr_detected_(false),       // 初始化二维码检测状态
        last_obstacle_time_(this->now()), // 初始化最后障碍物时间
        last_max_bottom_(0), // 初始化最后底部位置
        first_avoid_abs_angular_(0.0),  // 记录首次避障角速度的绝对值
        last_avoid_direction_(TurnDirection::UNKNOWN), // 记录最后一次避障方向
        first_avoid_recorded_(false),
        in_safety_buffer_(false), // 新增：安全缓冲期标志
        effective_area_left_(180), // 有效区域左边界
        effective_area_right_(460), // 有效区域右边界
        avoid_deviation_threshold_(50), // 避障偏差值
        force_right_return_params_(false),
        last_avoid_angular_z_(0.0)
    {
        // 声明获取所有参数
        this->declare_parameter<double>("Kp", 0.8);
        this->declare_parameter<double>("Ki", 0.0);
        this->declare_parameter<double>("Kd", 0.7);
        this->declare_parameter<float>("avoid_angular_ratio", 0.05);
        this->declare_parameter<float>("avoid_linear_speed", 0.3);
        this->declare_parameter<int>("bottom_threshold", 300);
        this->declare_parameter<float>("follow_linear_speed", 0.6);
        this->declare_parameter<float>("follow_angular_ratio", 0.8);
        this->declare_parameter<float>("confidence_threshold", 0.7);
        this->declare_parameter<float>("max_angular_velocity", 0.8);
        this->declare_parameter<float>("return_duration_left", 0.7); // 左转返航持续时间
        this->declare_parameter<float>("return_duration_right", 0.7); // 右转返航持续时间

        this->declare_parameter<float>("test3_return_duration_left", 0.7);
        this->declare_parameter<float>("test3_return_duration_right", 0.7);

        this->declare_parameter<float>("return_linear_speed", 0.5); // 返回航线的线速度
        
        // 安全持续时间参数（分别设置）
        this->declare_parameter<double>("safe_duration_obstacle", 0.5); // 避障安全持续时间
        this->declare_parameter<double>("safe_duration_obstacle_test3", 0.5); // 任务三避障安全持续时间
        this->declare_parameter<double>("safe_duration_parking", 1.0);  // 停车点安全持续时间
        this->declare_parameter<double>("safe_duration_line", 0.8);     // 线路跟踪安全持续时间
        this->declare_parameter<double>("safe_duration_qr", 1.0);      // 二维码安全持续时间
        
        this->declare_parameter<float>("return_angular_speed_left", 0.5); // 左转返航角速度比例
        this->declare_parameter<float>("return_angular_speed_right", 1.0); // 右转返航角速度比例

        this->declare_parameter<float>("test3_return_angular_speed_left", 0.5); // 左转返航角速度比例
        this->declare_parameter<float>("test3_return_angular_speed_right", 1.0); // 右转返航角速度比例
        
        // 新增停车点相关参数
        this->declare_parameter<float>("parking_linear_speed", 0.4); // 朝停车点前进的线速度
        this->declare_parameter<float>("parking_angular_ratio", 0.01); // 停车点角度控制比例
        this->declare_parameter<int>("parking_size_threshold", 200); // 停车点大小阈值（表示足够近）
        this->declare_parameter<float>("parking_approach_slowdown", 0.3); // 接近停车点时减速比例
        
        // 新增二维码相关参数
        this->declare_parameter<float>("qr_linear_speed", 0.4); // 朝二维码前进的线速度
        this->declare_parameter<float>("qr_angular_ratio", 0.01); // 二维码角度控制比例
        this->declare_parameter<int>("qr_size_threshold", 200); // 二维码大小阈值（表示足够近）
        this->declare_parameter<float>("qr_approach_slowdown", 0.3); // 接近二维码时减速比例
        this->declare_parameter<int>("qr_stop_size", 3800); // 二维码停止大小阈值
        
        // 新增有效区域参数
        this->declare_parameter<int>("effective_area_left", 180); // 有效区域左边界
        this->declare_parameter<int>("effective_area_right", 460); // 有效区域右边界
        this->declare_parameter<int>("avoid_deviation_threshold", 50);
        
        // 新增测试3相关参数
        this->declare_parameter<float>("test3_avoid_angular_ratio", 0.05);
        this->declare_parameter<float>("test3_avoid_linear_speed", 0.3);
        this->declare_parameter<float>("test3_follow_linear_speed", 0.6);
        this->declare_parameter<float>("test3_linear_speed", 0.5);
        this->declare_parameter<float>("test3_return_angular_speed", 0.5);
        
        // 获取参数值
        this->get_parameter<double>("Kp", Kp_);
        this->get_parameter<double>("Ki", Ki_);
        this->get_parameter<double>("Kd", Kd_);
        this->get_parameter<float>("avoid_angular_ratio", avoid_angular_ratio_);
        this->get_parameter<float>("avoid_linear_speed", avoid_linear_speed_);
        this->get_parameter<int>("bottom_threshold", bottom_threshold_);
        this->get_parameter<float>("follow_linear_speed", follow_linear_speed_);
        this->get_parameter<float>("follow_angular_ratio", follow_angular_ratio_);
        this->get_parameter<float>("confidence_threshold", confidence_threshold_);
        this->get_parameter<float>("max_angular_velocity", max_angular_velocity_);
        this->get_parameter<float>("return_duration_left", return_duration_left_);
        this->get_parameter<float>("return_duration_right", return_duration_right_);
        this->get_parameter<float>("return_linear_speed", return_linear_speed_);

        this->get_parameter<float>("test3_return_duration_left", test3_return_duration_left_);
        this->get_parameter<float>("test3_return_duration_right", test3_return_duration_right_);
        
        // 获取安全持续时间参数
        this->get_parameter<double>("safe_duration_obstacle", safe_duration_obstacle_);
        this->get_parameter<double>("safe_duration_obstacle_test3", safe_duration_obstacle_test3_);
        this->get_parameter<double>("safe_duration_parking", safe_duration_parking_);
        this->get_parameter<double>("safe_duration_line", safe_duration_line_);
        this->get_parameter<double>("safe_duration_qr", safe_duration_qr_);
        
        this->get_parameter<float>("return_angular_speed_left", return_angular_speed_left_);
        this->get_parameter<float>("return_angular_speed_right", return_angular_speed_right_);
        this->get_parameter<float>("test3_return_angular_speed_left", test3_return_angular_speed_left_);
        this->get_parameter<float>("test3_return_angular_speed_right", test3_return_angular_speed_right_);
        
        // 获取停车点参数值
        this->get_parameter<float>("parking_linear_speed", parking_linear_speed_);
        this->get_parameter<float>("parking_angular_ratio", parking_angular_ratio_);
        this->get_parameter<int>("parking_size_threshold", parking_size_threshold_);
        this->get_parameter<float>("parking_approach_slowdown", parking_approach_slowdown_);
        
        // 获取二维码参数值
        this->get_parameter<float>("qr_linear_speed", qr_linear_speed_);
        this->get_parameter<float>("qr_angular_ratio", qr_angular_ratio_);
        this->get_parameter<int>("qr_size_threshold", qr_size_threshold_);
        this->get_parameter<float>("qr_approach_slowdown", qr_approach_slowdown_);
        this->get_parameter<int>("qr_stop_size", qr_stop_size_); // 获取二维码停止大小阈值
        
        // 获取有效区域参数
        this->get_parameter<int>("effective_area_left", effective_area_left_);
        this->get_parameter<int>("effective_area_right", effective_area_right_);
        this->get_parameter<int>("avoid_deviation_threshold", avoid_deviation_threshold_);
        
        // 获取测试3相关参数值
        this->get_parameter<float>("test3_avoid_angular_ratio", test3_avoid_angular_ratio_);
        this->get_parameter<float>("test3_avoid_linear_speed", test3_avoid_linear_speed_);
        this->get_parameter<float>("test3_follow_linear_speed", test3_follow_linear_speed_);
        this->get_parameter<float>("test3_linear_speed", test3_linear_speed_);
        this->get_parameter<float>("test3_return_angular_speed", test3_return_angular_speed_);

        // 创建速度指令发布器
        cmd_vel_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);

        // 创建障碍物和线路点检测订阅器（合并为一个订阅器，从dnn_node_sample获取所有目标）
        target_subscriber_ = this->create_subscription<ai_msgs::msg::PerceptionTargets>(
            "dnn_node_sample",
            10,
            std::bind(&TrackFollower::targetCallback, this, std::placeholders::_1)
        );

        // 创建信号订阅器
        sign_subscription_ = this->create_subscription<std_msgs::msg::Int32>(
            "sign4return",
            10,
            std::bind(&TrackFollower::signCallback, this, std::placeholders::_1)
        );

        // 启动消息处理线程
        try {
            msg_process_ = std::make_shared<std::thread>(
                [this]() {
                    RCLCPP_INFO(this->get_logger(), "消息处理线程启动");
                    RCLCPP_INFO(this->get_logger(), "有效区域: X[%d - %d]", effective_area_left_, effective_area_right_);
                    this->messageProcess();
                });
        } catch (const std::system_error& e) {
            RCLCPP_FATAL(this->get_logger(), "无法启动线程: %s", e.what());
            throw;
        }
        
        // 初始化时间戳
        last_time_ = this->now();

        RCLCPP_INFO(this->get_logger(), "节点已启动，默认屏蔽cmd_vel发布");
        RCLCPP_INFO(this->get_logger(), "安全时间配置: 避障=%.2fs, 停车点=%.2fs, 线路=%.2fs, 二维码=%.2fs",
                   safe_duration_obstacle_, safe_duration_parking_, safe_duration_line_, safe_duration_qr_);
    }

    ~TrackFollower() {
        RCLCPP_INFO(this->get_logger(), "节点析构开始");
        
        // 先设置停止标志
        process_stop_.store(true);
        
        // 等待线程结束
        if (msg_process_ && msg_process_->joinable()) {
            msg_process_->join();
            RCLCPP_INFO(this->get_logger(), "消息处理线程已停止");
        }
        
        // 清空队列
        {
            std::unique_lock<std::mutex> lock(point_target_mutex_);
            while (!point_queue_.empty()) point_queue_.pop();
            while (!targets_queue_.empty()) targets_queue_.pop();
            RCLCPP_INFO(this->get_logger(), "队列已清空");
        }
        
        RCLCPP_INFO(this->get_logger(), "节点析构完成");
    }

private:
    // 检查障碍物是否在有效区域内
    bool isObstacleInEffectiveArea(const ai_msgs::msg::Target& obstacle) {
        if (obstacle.rois.empty()) return false;
        
        const auto& rect = obstacle.rois[0].rect;
        int left = rect.x_offset;
        int right = left + rect.width;
        
        // 检查障碍物是否与有效区域重叠
        bool in_area = (right > effective_area_left_ && left < effective_area_right_);
        
        RCLCPP_DEBUG(this->get_logger(), "障碍物位置: [%d - %d], 有效区域: [%d - %d], 有效: %s", 
                    left, right, effective_area_left_, effective_area_right_, 
                    in_area ? "是" : "否");
        
        return in_area;
    }

    // PID控制参数
    double Kp_;  // 比例系数
    double Ki_;  // 积分系数
    double Kd_;  // 微分系数

    // PID控制所需变量
    double angular_z_;   // 当前误差值
    double last_error_;  // 上一次计算的误差
    double error_sum_;   // 误差累积值
    double error_diff_;  // 误差变化率
    double output_;      // PID输出值
    int avoid_deviation_threshold_;  // 避障偏差截断阈值
    bool force_right_return_params_; // 新增：强制使用右转返航参数标志
    

    // 线路跟踪控制函数（使用point标签目标的中心点）
    void lineFollowingControl(int center_x) {
        int raw = center_x;
        auto twist_msg = geometry_msgs::msg::Twist();
        
        double dead_zone = 30.0;
        double image_center_x = OBSTACLE_IMAGE_WIDTH / 2.0;

        double temp = image_center_x - center_x;
        double guiyihua = std::abs(temp) / image_center_x;
        angular_z_ = follow_angular_ratio_ * guiyihua;
        if (temp < 0) 
            angular_z_ = -angular_z_;
        if (std::abs(temp) < dead_zone)
            angular_z_ = 0;
        
        // 应用PID控制
        rclcpp::Time current_time = this->now();
        double dt = (current_time - last_time_).seconds();
        if (dt <= 0) dt = 0.1;
        
        RCLCPP_INFO(this->get_logger(), "初始角速度：%.2f, dt：%.6f, last_error：%.2f, temp：%.2f",
            angular_z_, dt, last_error_, temp);

        error_sum_ += angular_z_ * dt;
        error_diff_ = (angular_z_ - last_error_) / dt;
        output_ = Kp_ * angular_z_ + Ki_ * error_sum_ + Kd_ * error_diff_;
        
        // 限制角速度范围
        angular_z_ = std::clamp(
            static_cast<float>(output_), 
            -max_angular_velocity_, 
            max_angular_velocity_
        );
        
        last_error_ = angular_z_;
        last_time_ = current_time;
        
        // 设置控制指令
        if (force_right_return_params_){
            twist_msg.linear.x = test3_follow_linear_speed_;
        }
        else {
            twist_msg.linear.x = follow_linear_speed_;
        }
        twist_msg.angular.z = angular_z_;
        
        // 发布控制指令
        if (!block_cmd_vel_) {
            cmd_vel_pub_->publish(twist_msg);
        }
        
        // 记录控制信息
        RCLCPP_INFO(this->get_logger(), 
                   "线路跟踪: 中心点x=%.1d, 偏差=%.1f, PID[P=%.2f I=%.2f D=%.2f] -> 线速=%.2f, 角速=%.2f", 
                   raw, temp,
                   Kp_ * angular_z_, Ki_ * error_sum_, Kd_ * error_diff_,
                   twist_msg.linear.x, twist_msg.angular.z);
    }

    // 障碍物目标回调函数（同时处理障碍物、停车点和线路点）
    void targetCallback(const ai_msgs::msg::PerceptionTargets::SharedPtr targets_msg) {
        std::unique_lock<std::mutex> lock(point_target_mutex_);
        sub_target_ = true;
        targets_queue_.push(targets_msg);
        if (targets_queue_.size() > 1) targets_queue_.pop();
        
        // 处理停车点信息
        bool parking_detected = false;
        ai_msgs::msg::Target closest_parking;
        int max_parking_size = 0;

        // 处理线路点信息
        bool line_point_detected = false;  // 修复：bbool改为bool
        ai_msgs::msg::Target top_line_point;
        int min_center_y = OBSTACLE_IMAGE_HEIGHT; // 初始化为图像高度（最大值）

        // 处理"tong"标签障碍物
        bool tong_obstacle_detected = false;
        ai_msgs::msg::Target closest_tong_obstacle;
        int max_tong_bottom = 0;

        // 处理二维码信息
        bool qr_detected = false;
        ai_msgs::msg::Target closest_qr;
        int max_qr_size = 0;

        for (const auto &target : targets_msg->targets) {
            // 处理停车点标签"P"
            if (target.type == "P") { 
                int size = target.rois[0].rect.width * target.rois[0].rect.height;
                
                if (size > 100 && // 忽略太小的检测
                    target.rois[0].confidence > confidence_threshold_) {
                    parking_detected = true;
                    // 选择最大的停车点（表示最接近）
                    if (size > max_parking_size) {
                        max_parking_size = size;
                        closest_parking = target;
                    }
                }
            }
            // 处理线路点标签"point"
            else if (target.type == "point") {
                    if (target.rois[0].confidence > confidence_threshold_) {
                    // 计算中心y坐标 (y_offset + height/2)
                    int center_y = target.rois[0].rect.y_offset + target.rois[0].rect.height / 2;
                    
                    // 选择最上方的点（y坐标最小）
                    if (center_y < min_center_y) {
                        min_center_y = center_y;
                        top_line_point = target;
                        line_point_detected = true;
                    }
                }
            }
            // 处理"tong"标签障碍物
            else if (target.type == "tong") {
                if (target.rois[0].confidence > confidence_threshold_) {
                    tong_obstacle_detected = true;
                    // 计算底部位置（y坐标+高度）
                    int current_bottom = target.rois[0].rect.y_offset + target.rois[0].rect.height;
                    
                    // 选择底部位置最大的（最近的）障碍物
                    if (current_bottom > max_tong_bottom) {
                        max_tong_bottom = current_bottom;
                        closest_tong_obstacle = target;
                    }
                    
                    // 记录位置信息
                    const auto& rect = target.rois[0].rect;
                    RCLCPP_INFO(this->get_logger(), 
                               "障碍物位置: [%d - %d], 有效区域: [%d - %d], 有效: %s", 
                               rect.x_offset, rect.x_offset + rect.width,
                               effective_area_left_, effective_area_right_,
                               isObstacleInEffectiveArea(target) ? "是" : "否");
                }
            }
            // 处理二维码标签"qr"
            else if (target.type == "qr") {
                int size = target.rois[0].rect.width * target.rois[0].rect.height;
                if (size > 100 && // 忽略太小的检测
                    target.rois[0].confidence > confidence_threshold_) {
                    qr_detected = true;
                    // 选择最大的二维码（表示最接近）
                    if (size > max_qr_size) {
                        max_qr_size = size;
                        closest_qr = target;
                    }
                }
            }
        }
        
        // 更新停车点检测状态
        sub_parking_ = parking_detected;
        parking_detected_ = parking_detected;
        
        if (parking_detected) {
            parking_detected_ = true;
            last_parking_time_ = this->now();
            parking_target_ = closest_parking;
            parking_target_size_ = max_parking_size;
            
            RCLCPP_INFO(this->get_logger(), "检测到停车点！位置: (%d, %d), 尺寸: %d",
                       closest_parking.rois[0].rect.x_offset + closest_parking.rois[0].rect.width / 2,
                       closest_parking.rois[0].rect.y_offset + closest_parking.rois[0].rect.height / 2,
                       max_parking_size);
        } else {
            if (parking_detected_) {
                RCLCPP_WARN(this->get_logger(), "未检测到停车点！");
            }
        }

        // 更新线路点检测状态
        sub_line_point_ = line_point_detected;
        if (line_point_detected) {
            // 使用最上方点的中心x坐标
            line_point_center_x_ = top_line_point.rois[0].rect.x_offset + top_line_point.rois[0].rect.width / 2;
            last_line_point_time_ = this->now();
            
            RCLCPP_INFO(this->get_logger(), "检测到最上方线路点！中心点: (%d, %d), 置信度: %.2f",
                    line_point_center_x_, 
                    min_center_y,
                    top_line_point.rois[0].confidence);
        } else {
            if (sub_line_point_) {
                RCLCPP_WARN(this->get_logger(), "未检测到线路点！");
            }
        }

        // 更新障碍物检测状态（仅"tong"标签）
        if (tong_obstacle_detected) {
            obstacle_detected_ = true;
            current_closest_obstacle_ = closest_tong_obstacle;
            current_max_bottom_ = max_tong_bottom;
            last_max_bottom_ = max_tong_bottom;
            last_obstacle_time_ = this->now();
            
            RCLCPP_INFO(this->get_logger(), "检测到障碍物，底部位置: %d", max_tong_bottom);
        } else {
            obstacle_detected_ = false;
        }
        
        // 更新二维码检测状态
        qr_detected_ = qr_detected;
        if (qr_detected) {
            last_qr_time_ = this->now();
            qr_target_ = closest_qr;
            qr_target_size_ = max_qr_size;
            
            RCLCPP_INFO(this->get_logger(), "检测到二维码！位置: (%d, %d), 尺寸: %d",
                       closest_qr.rois[0].rect.x_offset + closest_qr.rois[0].rect.width / 2,
                       closest_qr.rois[0].rect.y_offset + closest_qr.rois[0].rect.height / 2,
                       max_qr_size);
        } else {
            if (qr_detected_) {
                RCLCPP_WARN(this->get_logger(), "未检测到二维码！");
            }
        }
    }

    // 重置停车状态
    void resetParkingState() {
        parking_detected_ = false;
        sub_parking_ = false;
        parking_target_size_ = 0;
        last_parking_time_ = this->now(); // 重置时间戳
    }

    // 重置二维码状态
    void resetQRState() {
        qr_detected_ = false;
        qr_target_size_ = 0;
        last_qr_time_ = this->now(); // 重置时间戳
    }

    // 信号回调函数
    void signCallback(const std_msgs::msg::Int32::SharedPtr msg) {
        if (msg->data == 5) {
            block_cmd_vel_ = true;
            force_right_return_params_ = false;
            RCLCPP_INFO(this->get_logger(), "接收到遥测信号，屏蔽cmd_vel发布");
        } 
        else if (msg->data == 3 || msg->data == 4 || msg->data == 30) {
            // 发布速度为0的消息
            auto twist_msg = geometry_msgs::msg::Twist();
            twist_msg.linear.x = 0.0;
            twist_msg.angular.z = 0.0;
            cmd_vel_pub_->publish(twist_msg);
            block_cmd_vel_ = true;
            current_state_ = RobotState::STOPPED;
            RCLCPP_INFO(this->get_logger(), "接收到停止信号%d，进入停止状态", msg->data);
        }
        else if (msg->data == 6 || msg->data == 20) {
            block_cmd_vel_ = false;

            if (msg->data == 6) {
            force_right_return_params_ = true;
            RCLCPP_WARN(this->get_logger(), 
                       "接收到强制右转返航信号6，后续返航将使用右转参数: 角速比例=%.2f, 持续时间=%.2f秒",
                       return_angular_speed_right_, return_duration_right_);
        }

            if (current_state_ == RobotState::STOPPED) {
                current_state_ = RobotState::LINE_FOLLOWING;
            }
            RCLCPP_INFO(this->get_logger(), "接收到恢复信号%d，启用cmd_vel发布", msg->data);
        }
    }

    // 避障控制函数
    void obstaclesAvoiding(const ai_msgs::msg::Target& obstacle, int bottom) {
        if (block_cmd_vel_) return;
        
        auto twist_msg = geometry_msgs::msg::Twist();
        
        // 计算障碍物中心x坐标
        int center_x = obstacle.rois[0].rect.x_offset + obstacle.rois[0].rect.width / 2;
        double temp = center_x - OBSTACLE_IMAGE_WIDTH / 2.0;
        
        // 对偏差进行截断处理
        if (std::abs(temp) < avoid_deviation_threshold_) {
            temp = (temp > 0) ? avoid_deviation_threshold_ : -avoid_deviation_threshold_;
        }
        
        // 计算角速度 - 根据障碍物距离调整灵敏度
        double distance_factor = 1.0 - (static_cast<double>(bottom) / OBSTACLE_IMAGE_HEIGHT);
        double sensitivity = 1.0 + (2.0 * distance_factor); // 障碍物越近，灵敏度越高
        
        // 计算新的角速度
        double new_angular_z;
        if (force_right_return_params_) {
            new_angular_z = test3_avoid_angular_ratio_ * sensitivity * 700.0 / temp;
        }
        else {
            new_angular_z = avoid_angular_ratio_ * sensitivity * 700.0 / temp;
        }
        new_angular_z = std::clamp(static_cast<float>(new_angular_z), -max_angular_velocity_, max_angular_velocity_);
        
        // 新增：角速度变化限制
        double angular_diff = std::abs(new_angular_z - last_avoid_angular_z_);
        if (angular_diff > 4.0) {
            // 角速度变化超过3 rad/s，保持上一次的角速度
            RCLCPP_WARN(this->get_logger(), 
                       "角速度变化过大(%.2f -> %.2f, 差值=%.2f)，保持上一次角速度: %.2f",
                       last_avoid_angular_z_, new_angular_z, angular_diff, last_avoid_angular_z_);
            angular_z_ = last_avoid_angular_z_;
        } else {
            // 变化在允许范围内，使用新角速度
            angular_z_ = new_angular_z;
            // 更新记录
            last_avoid_angular_z_ = angular_z_;
        }
        
        // 修改：记录避障的角速度和方向
        if (!first_avoid_recorded_) {
            // 第一次避障，记录角速度的绝对值和方向
            first_avoid_abs_angular_ = std::abs(angular_z_);
            last_avoid_direction_ = (angular_z_ < 0) ? TurnDirection::RIGHT : TurnDirection::LEFT;
            first_avoid_recorded_ = true;
            RCLCPP_INFO(this->get_logger(), "记录首次避障: 角速大小=%.2f, 方向=%s",
                       first_avoid_abs_angular_, 
                       (last_avoid_direction_ == TurnDirection::LEFT) ? "左" : "右");
        } else {
            // 后续避障，只更新方向
            last_avoid_direction_ = (angular_z_ < 0) ? TurnDirection::RIGHT : TurnDirection::LEFT;
            RCLCPP_DEBUG(this->get_logger(), "更新避障方向: %s", 
                        (last_avoid_direction_ == TurnDirection::LEFT) ? "左" : "右");
        }
        
        // 设置控制指令
        if (force_right_return_params_) {
            twist_msg.linear.x = test3_avoid_linear_speed_ * (1.0 - distance_factor * 0.5); // 障碍物越近，速度越慢
        }
        else {
            twist_msg.linear.x = avoid_linear_speed_ * (1.0 - distance_factor * 0.5); // 障碍物越近，速度越慢
        }
        twist_msg.angular.z = angular_z_;
        
        // 发布控制指令
        cmd_vel_pub_->publish(twist_msg);
        
        // 计算障碍物距离指标
        double distance_ratio = static_cast<double>(bottom) / OBSTACLE_IMAGE_HEIGHT;
        const char* proximity = "";
        
        if (distance_ratio > 0.9) proximity = "非常近!";
        else if (distance_ratio > 0.7) proximity = "接近";
        else if (distance_ratio > 0.5) proximity = "中等距离";
        else proximity = "较远";
        
        // 记录避障信息
        RCLCPP_INFO(this->get_logger(), 
                   "避障控制: 障碍物中心x=%d, 底部y=%d (距离比例=%.2f, %s), 偏差=%.1f, 线速=%.2f, 角速=%.2f", 
                   center_x, bottom, distance_ratio, proximity, 
                   temp, twist_msg.linear.x, twist_msg.angular.z);
    }

    // 返回航线控制函数
    void returnToLineControl() {
        if (block_cmd_vel_ || current_state_ != RobotState::RETURN_TO_LINE) return;
        
        auto twist_msg = geometry_msgs::msg::Twist();
        float return_angular_ratio = 0.0;
        float current_return_duration = 0.0;
        
        // 根据最后一次避障的方向选择返航参数
        // 新增：根据是否强制使用右转参数选择返航参数
        if (force_right_return_params_) {
            if (last_avoid_direction_ == TurnDirection::LEFT) {
                return_angular_ratio = test3_return_angular_speed_left_;
                current_return_duration = test3_return_duration_left_;
                RCLCPP_INFO(this->get_logger(), "使用左转避障后的返航参数: 角速比例=%.2f, 持续时间=%.2f秒", 
                        return_angular_ratio, current_return_duration);
            } else {
                return_angular_ratio = test3_return_angular_speed_right_;
                current_return_duration = test3_return_duration_right_;
                RCLCPP_INFO(this->get_logger(), "使用右转避障后的返航参数: 角速比例=%.2f, 持续时间=%.2f秒", 
                        return_angular_ratio, current_return_duration);
            }
        }
        else {
            if (last_avoid_direction_ == TurnDirection::LEFT) {
                return_angular_ratio = return_angular_speed_left_;
                current_return_duration = return_duration_left_;
                RCLCPP_INFO(this->get_logger(), "使用左转避障后的返航参数: 角速比例=%.2f, 持续时间=%.2f秒", 
                        return_angular_ratio, current_return_duration);
            } else {
                return_angular_ratio = return_angular_speed_right_;
                current_return_duration = return_duration_right_;
                RCLCPP_INFO(this->get_logger(), "使用右转避障后的返航参数: 角速比例=%.2f, 持续时间=%.2f秒", 
                        return_angular_ratio, current_return_duration);
            }
        }     
        
        // 计算返航角速度 - 使用第一次避障的大小，但方向与最后一次避障相反
        double return_angular_z = 0.0;
        if (last_avoid_direction_ == TurnDirection::LEFT) {
            // 最后一次避障是左转，返航需要右转（负角速度）
            return_angular_z = -first_avoid_abs_angular_ * return_angular_ratio;
        } else {
            // 最后一次避障是右转，返航需要左转（正角速度）
            return_angular_z = first_avoid_abs_angular_ * return_angular_ratio;
        }
        
        RCLCPP_INFO(this->get_logger(), "返航角速度: 大小=%.2f * %.2f = %.2f, 方向=%s", 
                first_avoid_abs_angular_, return_angular_ratio, return_angular_z,
                (return_angular_z < 0) ? "右转" : "左转");
        
        // 设置控制指令
        if (force_right_return_params_) {
            twist_msg.linear.x = test3_linear_speed_;
        }
        else {
            twist_msg.linear.x = return_linear_speed_;
        }
        twist_msg.angular.z = return_angular_z;
        
        // 发布控制指令
        cmd_vel_pub_->publish(twist_msg);
        
        // 计算剩余返回时间
        auto elapsed = (this->now() - return_start_time_).seconds();
        double remaining = current_return_duration - elapsed;
        
        // 记录返回航线信息
        RCLCPP_INFO(this->get_logger(), 
                "返回航线: 线速=%.2f, 角速=%.2f, 剩余时间=%.2f秒", 
                twist_msg.linear.x, twist_msg.angular.z, remaining);

        // 返航时间结束后回到线路跟踪
        if (elapsed >= current_return_duration) {
            current_state_ = RobotState::LINE_FOLLOWING;
            first_avoid_recorded_ = false; // 重置首次避障记录
            last_avoid_direction_ = TurnDirection::UNKNOWN; // 重置方向
            RCLCPP_INFO(this->get_logger(), "返航完成，回到线路跟踪状态");
        }
    }

    // 停车点导航控制函数
    void parkingControl() {
        if (block_cmd_vel_) return;
        
        auto twist_msg = geometry_msgs::msg::Twist();
        
        // 计算停车点中心坐标
        int center_x = parking_target_.rois[0].rect.x_offset + parking_target_.rois[0].rect.width / 2;
        int center_y = parking_target_.rois[0].rect.y_offset + parking_target_.rois[0].rect.height / 2;
        
        // 计算与图像中心的偏差
        double x_deviation = center_x - (OBSTACLE_IMAGE_WIDTH / 2.0);
        if (std::abs(x_deviation) < 40 )
            x_deviation = 0;
        
        // 角速度控制：转向停车点
        double angular_z = -parking_angular_ratio_ * x_deviation;
        
        // 线速度控制：使用固定值
        double linear_x = parking_linear_speed_;
        
        // 设置控制指令
        twist_msg.linear.x = linear_x;
        twist_msg.angular.z = angular_z;
        
        // 发布控制指令
        cmd_vel_pub_->publish(twist_msg);
        
        // 记录停车导航信息
        RCLCPP_INFO(this->get_logger(), 
                "停车导航: 中心(%d, %d), X偏差=%.1f, 尺寸: %d, 线速: %.2f, 角速: %.2f", 
                center_x, center_y, x_deviation, 
                parking_target_size_, linear_x, angular_z);
    }

    // 二维码追踪控制函数
    void qrTrackingControl() {
        if (block_cmd_vel_) return;
        
        // 检查二维码是否达到停止大小
        if (qr_detected_ && qr_target_size_ >= qr_stop_size_) {
            auto twist_msg = geometry_msgs::msg::Twist();
            twist_msg.linear.x = 0.0;
            twist_msg.angular.z = 0.0;
            cmd_vel_pub_->publish(twist_msg);
            RCLCPP_INFO(this->get_logger(), 
                    "全局检测：二维码大小达到阈值%d，发布停止指令", 
                    qr_stop_size_);
            return;
        }
        
        auto twist_msg = geometry_msgs::msg::Twist();
        
        // 计算二维码中心坐标
        int center_x = qr_target_.rois[0].rect.x_offset + qr_target_.rois[0].rect.width / 2;
        int image_center_x = OBSTACLE_IMAGE_WIDTH / 2;
        double error = image_center_x - center_x;
        
        // 计算角速度
        double angular = qr_angular_ratio_ * error;
        angular = std::clamp(static_cast<float>(angular), -max_angular_velocity_, max_angular_velocity_);
        
        // 根据距离调整线速度（越近越慢）
        double speed_factor = 1.0;
        if (qr_target_size_ > qr_size_threshold_) {
            speed_factor = qr_approach_slowdown_;
        }
        
        // 设置控制指令
        twist_msg.linear.x = qr_linear_speed_ * speed_factor;
        twist_msg.angular.z = angular;
        
        // 发布控制指令
        cmd_vel_pub_->publish(twist_msg);
        
        RCLCPP_INFO(this->get_logger(), 
                "二维码追踪: 中心x=%d, 偏差=%.1f, 线速=%.2f, 角速=%.2f, 尺寸=%d", 
                center_x, error, twist_msg.linear.x, twist_msg.angular.z, qr_target_size_);
    }

    // 消息处理线程函数
    void messageProcess() {
        while (!process_stop_.load()) {
            // 状态机处理
            switch (current_state_) {
                case RobotState::LINE_FOLLOWING:
                    // 检查是否检测到"tong"障碍物、底部位置超过阈值且在有效区域内
                    if (obstacle_detected_ && 
                        current_max_bottom_ > bottom_threshold_ &&
                        isObstacleInEffectiveArea(current_closest_obstacle_)) 
                    {
                        current_state_ = RobotState::OBSTACLE_AVOIDING;
                        last_avoid_angular_z_ = 0.0; // 重置上一次避障角速度
                        in_safety_buffer_ = false; // 确保安全缓冲期标志重置
                        RCLCPP_INFO(this->get_logger(), "检测到有效区域内的障碍物(底部位置%d > 阈值%d)，进入避障状态", 
                                  current_max_bottom_, bottom_threshold_);
                    }
                    // 检查是否检测到二维码（优先级高于停车点）
                    else if (qr_detected_) {
                        current_state_ = RobotState::QR_TRACKING;
                        RCLCPP_INFO(this->get_logger(), "检测到二维码，进入二维码追踪状态");
                    }
                    // 检查是否检测到停车点
                    else if (parking_detected_) {
                        current_state_ = RobotState::PARKING;
                        RCLCPP_INFO(this->get_logger(), "检测到停车点，进入停车状态");
                    }
                    // 正常线路跟踪
                    else if (sub_line_point_) {
                        lineFollowingControl(line_point_center_x_);
                    }
                    break;

                case RobotState::OBSTACLE_AVOIDING:
                    // 如果不在安全缓冲期，检查是否应该退出避障状态
                    if (!in_safety_buffer_) {
                        // 检查是否应该退出避障状态（障碍物消失/位置无效/底部低于阈值）
                        if (!obstacle_detected_ || 
                            current_max_bottom_ < bottom_threshold_ ||
                            !isObstacleInEffectiveArea(current_closest_obstacle_)) 
                        {
                            // 进入安全缓冲期
                            in_safety_buffer_ = true;
                            safety_buffer_start_time_ = this->now();
                            RCLCPP_INFO(this->get_logger(), 
                                      "退出避障状态(底部:%d 阈值:%d 位置有效:%d)，进入安全缓冲期",
                                      current_max_bottom_, bottom_threshold_,
                                      isObstacleInEffectiveArea(current_closest_obstacle_));
                        }
                    }
                    
                    // 安全缓冲期处理
                    if (in_safety_buffer_) {
                        // 计算安全缓冲期是否结束
                        auto elapsed = (this->now() - safety_buffer_start_time_).seconds();
                        if (force_right_return_params_) {
                            // 使用测试3的安全持续时间
                            if (elapsed >= safe_duration_obstacle_test3_) {
                                // 安全缓冲期结束，进入返航状态
                                current_state_ = RobotState::RETURN_TO_LINE;
                                return_start_time_ = this->now();
                                in_safety_buffer_ = false;  // 重置安全缓冲期标志
                                RCLCPP_INFO(this->get_logger(), "避障安全缓冲期结束(%.2fs)，进入返航状态", elapsed);
                            } else {
                                RCLCPP_INFO(this->get_logger(), "避障安全缓冲中，剩余%.2f秒 (忽略新障碍物)", 
                                           safe_duration_obstacle_test3_ - elapsed);
                            }
                        } else {
                            // 使用默认安全持续时间
                            if (elapsed >= safe_duration_obstacle_) {
                                // 安全缓冲期结束，进入返航状态
                                current_state_ = RobotState::RETURN_TO_LINE;
                                return_start_time_ = this->now();
                                in_safety_buffer_ = false;  // 重置安全缓冲期标志
                                RCLCPP_INFO(this->get_logger(), "避障安全缓冲期结束(%.2fs)，进入返航状态", elapsed);
                            } else {
                                RCLCPP_INFO(this->get_logger(), "避障安全缓冲中，剩余%.2f秒 (忽略新障碍物)", 
                                           safe_duration_obstacle_ - elapsed);
                            }
                        }
                        
                        // 缓冲期内保持低速直行
                        if (!block_cmd_vel_) {
                            auto twist_msg = geometry_msgs::msg::Twist();
                            if (force_right_return_params_) {
                                twist_msg.linear.x = test3_return_angular_speed_;
                            }
                            else {
                                twist_msg.linear.x = avoid_linear_speed_;
                            }
                            twist_msg.angular.z = 0.0;
                            cmd_vel_pub_->publish(twist_msg);
                        }
                    } 
                    // 不在安全缓冲期且有有效障碍物，继续避障
                    else if (obstacle_detected_ && 
                             current_max_bottom_ >= bottom_threshold_ &&
                             isObstacleInEffectiveArea(current_closest_obstacle_)) 
                    {
                        obstaclesAvoiding(current_closest_obstacle_, current_max_bottom_);
                    }
                    break;

                case RobotState::RETURN_TO_LINE:
                    // 检查是否应该切换到避障状态（最高优先级）
                    if (obstacle_detected_ && 
                        current_max_bottom_ > bottom_threshold_ &&
                        isObstacleInEffectiveArea(current_closest_obstacle_)) 
                    {
                        current_state_ = RobotState::OBSTACLE_AVOIDING;
                        in_safety_buffer_ = false; // 重置安全缓冲期标志
                        RCLCPP_INFO(this->get_logger(), "返航中检测到障碍物，切换到避障状态");
                    }
                    // 检查是否检测到二维码（次高优先级）
                    else if (qr_detected_) {
                        current_state_ = RobotState::QR_TRACKING;
                        RCLCPP_INFO(this->get_logger(), "返航中检测到二维码，切换到二维码追踪状态");
                    }
                    // 检查是否检测到停车点
                    else if (parking_detected_) {
                        current_state_ = RobotState::PARKING;
                        RCLCPP_INFO(this->get_logger(), "返航中检测到停车点，切换到停车状态");
                    }
                    else {
                        // 没有更高优先级的事件，则执行返航控制
                        returnToLineControl();
                    }
                    break;

                case RobotState::PARKING:
                    {  // 添加代码块解决变量初始化问题
                        // 检查停车点是否消失超过安全时间
                        auto parking_elapsed = (this->now() - last_parking_time_).seconds();
                        if (parking_elapsed > safe_duration_parking_) {
                            RCLCPP_INFO(this->get_logger(), "停车点消失超过%.2fs，返回线路跟踪", parking_elapsed);
                            resetParkingState();
                            current_state_ = RobotState::LINE_FOLLOWING;
                        }
                        // 检查是否检测到二维码（高优先级）
                        else if (qr_detected_) {
                            current_state_ = RobotState::QR_TRACKING;
                            RCLCPP_INFO(this->get_logger(), "检测到二维码，切换到二维码追踪状态");
                        }
                        // 检查障碍物（最高优先级）
                        else if (obstacle_detected_ && 
                                 current_max_bottom_ > bottom_threshold_ &&
                                 isObstacleInEffectiveArea(current_closest_obstacle_)) 
                        {
                            current_state_ = RobotState::OBSTACLE_AVOIDING;
                            in_safety_buffer_ = false; // 确保安全缓冲期标志重置
                            last_avoid_angular_z_ = 0.0; // 重置上一次避障角速度
                            RCLCPP_INFO(this->get_logger(), "检测到有效区域内的障碍物(底部位置%d > 阈值%d)，切换到避障状态", 
                                      current_max_bottom_, bottom_threshold_);
                        }
                        else {
                            parkingControl();
                        }
                    }
                    break;

                case RobotState::QR_TRACKING:
                    {
                        // 检查二维码是否消失超过安全时间
                        auto qr_elapsed = (this->now() - last_qr_time_).seconds();
                        if (qr_elapsed > safe_duration_qr_) {
                            RCLCPP_INFO(this->get_logger(), "二维码消失超过%.2fs，返回线路跟踪", qr_elapsed);
                            resetQRState();
                            current_state_ = RobotState::LINE_FOLLOWING;
                        }
                        // 检查障碍物（最高优先级）
                        else if (obstacle_detected_ && 
                                 current_max_bottom_ > bottom_threshold_ &&
                                 isObstacleInEffectiveArea(current_closest_obstacle_)) 
                        {
                            current_state_ = RobotState::OBSTACLE_AVOIDING;
                            in_safety_buffer_ = false; // 确保安全缓冲期标志重置
                            last_avoid_angular_z_ = 0.0; // 重置上一次避障角速度
                            RCLCPP_INFO(this->get_logger(), "检测到有效区域内的障碍物(底部位置%d > 阈值%d)，切换到避障状态", 
                                      current_max_bottom_, bottom_threshold_);
                        }
                        else {
                            qrTrackingControl();
                        }
                    }
                    break;

                case RobotState::STOPPED:
                    // 停止状态不发布速度指令
                    break;
            }

            // 短暂休眠，降低CPU占用
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
    }

    // 发布器和订阅器
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
    rclcpp::Subscription<ai_msgs::msg::PerceptionTargets>::SharedPtr target_subscriber_;
    rclcpp::Subscription<std_msgs::msg::Int32>::SharedPtr sign_subscription_;

    // 消息队列和互斥锁
    std::queue<ai_msgs::msg::PerceptionTargets::SharedPtr> targets_queue_;
    std::queue<ai_msgs::msg::Target::SharedPtr> point_queue_;
    std::mutex point_target_mutex_;
    std::shared_ptr<std::thread> msg_process_;
    std::atomic<bool> process_stop_;

    // 状态标记
    bool sub_target_;
    bool sub_parking_;
    bool sub_line_point_;
    bool block_cmd_vel_;
    RobotState current_state_;
    bool in_safety_buffer_; // 新增：安全缓冲期标志

    // 有效区域边界
    int effective_area_left_;
    int effective_area_right_;

    // 控制参数
    float avoid_angular_ratio_;
    float avoid_linear_speed_;

    float test3_avoid_angular_ratio_;
    float test3_avoid_linear_speed_;
    float test3_follow_linear_speed_;
    float test3_linear_speed_;
    float test3_return_angular_speed_;

    int bottom_threshold_;
    float follow_linear_speed_;
    float follow_angular_ratio_;
    
    float confidence_threshold_;
    float max_angular_velocity_;
    float return_duration_left_;
    float return_duration_right_;

    float test3_return_duration_right_;
    float test3_return_duration_left_;

    float return_linear_speed_;
    double safe_duration_obstacle_;
    double safe_duration_obstacle_test3_;
    double safe_duration_parking_;
    double safe_duration_line_;
    double safe_duration_qr_;  // 二维码安全持续时间
    float return_angular_speed_left_;
    float return_angular_speed_right_;
    float test3_return_angular_speed_left_;
    float test3_return_angular_speed_right_;

    float parking_linear_speed_;
    float parking_angular_ratio_;
    int parking_size_threshold_;
    float parking_approach_slowdown_;
    float qr_linear_speed_;     // 二维码追踪线速度
    float qr_angular_ratio_;    // 二维码追踪角度比例
    int qr_size_threshold_;     // 二维码大小阈值
    float qr_approach_slowdown_;// 接近二维码时减速比例
    int qr_stop_size_;  // 二维码停止大小阈值

    // 检测数据
    bool obstacle_detected_;
    bool parking_detected_;
    bool qr_detected_;          // 是否检测到二维码
    ai_msgs::msg::Target parking_target_;
    ai_msgs::msg::Target qr_target_;    // 二维码目标
    int parking_target_size_;
    int qr_target_size_;        // 二维码目标大小
    int line_point_center_x_;
    ai_msgs::msg::Target current_closest_obstacle_;
    int current_max_bottom_;
    rclcpp::Time last_obstacle_time_;
    rclcpp::Time last_parking_time_;
    rclcpp::Time last_line_point_time_;
    rclcpp::Time last_qr_time_; // 上次检测到二维码的时间
    rclcpp::Time last_time_;
    rclcpp::Time return_start_time_;  // 返航开始时间
    rclcpp::Time safety_buffer_start_time_; // 安全缓冲期开始时间

    // 避障记录
    int last_max_bottom_;
    double first_avoid_abs_angular_;  // 记录首次避障角速度的绝对值
    TurnDirection last_avoid_direction_; // 记录最后一次避障的转向方向
    bool first_avoid_recorded_;
    float last_avoid_angular_z_;
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<TrackFollower>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
