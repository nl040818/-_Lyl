/*
 * fusion_nav_yellow_point_state_machine_fast
 *
 * 功能说明:
 * - 前半段沿用 fusion_nav_yellow_state_machine 的流程:
 *   视觉巡线 -> 二维码靠近识别 -> 多点导航 -> 关闭 Nav2 -> 黄色通道。
 * - 黄色通道阶段额外监听两个条件:
 *   1. yellow_channel 通过参数 red_text_trigger.last_trigger 标记红色已经触发。
 *   2. YOLO/AI 感知结果话题中出现 point 标签。
 * - 两个条件同时满足后，立即停止 yellow_channel 子进程，切换到 pure_line_follower。
 * - 切回的 pure_line_follower 使用独立参数文件 pure_line_follower_after_yellow.yaml，
 *   该阶段作为终态，不再根据 /odom 进入二维码或导航流程。
 */

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <csignal>
#include <cstdlib>
#include <exception>
#include <functional>
#include <memory>
#include <string>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>

#include "ai_msgs/msg/perception_targets.hpp"
#include "ament_index_cpp/get_package_prefix.hpp"
#include "ament_index_cpp/get_package_share_directory.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "nav2_msgs/srv/manage_lifecycle_nodes.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "rcl_interfaces/msg/parameter_event.hpp"
#include "rcl_interfaces/msg/parameter_type.hpp"
#include "rcl_interfaces/msg/parameter_value.hpp"
#include "rcl_interfaces/srv/get_parameters.hpp"
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

using namespace std::chrono_literals;

namespace
{
std::string fallbackSourceConfigPath(const std::string &filename)
{
  return "/home/sunrise/niubi_ws/src/liu_dine/config/config/" + filename;
}

std::string packageConfigPath(const std::string &filename)
{
  try {
    return ament_index_cpp::get_package_share_directory("liu_dine") + "/config/config/" + filename;
  } catch (const std::exception &) {
    return fallbackSourceConfigPath(filename);
  }
}

std::string normalizeNodeName(const std::string &node_name)
{
  if (node_name.empty()) {
    return "/";
  }
  if (node_name.front() == '/') {
    return node_name;
  }
  return "/" + node_name;
}
}  // namespace

class FusionNavYellowPointStateMachine : public rclcpp::Node
{
public:
  using GetParameters = rcl_interfaces::srv::GetParameters;
  using ManageLifecycleNodes = nav2_msgs::srv::ManageLifecycleNodes;
  using ParameterEvent = rcl_interfaces::msg::ParameterEvent;
  using ParameterValue = rcl_interfaces::msg::ParameterValue;
  using PerceptionTargets = ai_msgs::msg::PerceptionTargets;

  FusionNavYellowPointStateMachine()
  : Node("fusion_nav_yellow_point_state_machine_fast")
  {
    loadParameters();

    status_pub_ = create_publisher<std_msgs::msg::String>(
      status_topic_,
      rclcpp::QoS(10).reliable().transient_local());
    cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);
    odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
      odom_topic_,
      10,
      std::bind(&FusionNavYellowPointStateMachine::odomCallback, this, std::placeholders::_1));
    multi_nav_status_sub_ = create_subscription<std_msgs::msg::String>(
      multi_nav_status_topic_,
      rclcpp::QoS(10).reliable().transient_local(),
      std::bind(&FusionNavYellowPointStateMachine::multiNavStatusCallback, this, std::placeholders::_1));
    yolo_targets_sub_ = create_subscription<PerceptionTargets>(
      yolo_targets_topic_,
      10,
      std::bind(&FusionNavYellowPointStateMachine::yoloTargetsCallback, this, std::placeholders::_1));
    if (use_qr_result_topic_) {
      qr_result_sub_ = create_subscription<std_msgs::msg::String>(
        qr_result_topic_,
        10,
        std::bind(&FusionNavYellowPointStateMachine::qrResultCallback, this, std::placeholders::_1));
    }
    if (use_parameter_events_for_yellow_red_) {
      parameter_events_sub_ = create_subscription<ParameterEvent>(
        "/parameter_events",
        rclcpp::ParameterEventsQoS(),
        std::bind(&FusionNavYellowPointStateMachine::parameterEventCallback, this, std::placeholders::_1));
    }

    qr_param_client_ = create_client<GetParameters>(
      normalizeNodeName(qr_node_name_) + "/get_parameters");
    yellow_param_client_ = create_client<GetParameters>(
      normalizeNodeName(yellow_node_name_) + "/get_parameters");
    for (const auto &service_name : nav_lifecycle_manager_services_) {
      nav_lifecycle_clients_.push_back({service_name, create_client<ManageLifecycleNodes>(service_name)});
    }

    const auto qr_poll_period = std::chrono::duration<double>(1.0 / poll_qr_param_hz_);
    qr_poll_timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(qr_poll_period),
      std::bind(&FusionNavYellowPointStateMachine::pollQrParameter, this));
    const auto yellow_poll_period = std::chrono::duration<double>(1.0 / poll_yellow_red_param_hz_);
    yellow_red_poll_timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(yellow_poll_period),
      std::bind(&FusionNavYellowPointStateMachine::pollYellowRedParameter, this));
    process_watch_timer_ = create_wall_timer(
      500ms,
      std::bind(&FusionNavYellowPointStateMachine::watchChildProcess, this));
    background_reap_timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::duration<double>(background_reap_interval_sec_)),
      std::bind(&FusionNavYellowPointStateMachine::reapRetiredProcesses, this));
    nav_shutdown_timer_ = create_wall_timer(
      50ms,
      std::bind(&FusionNavYellowPointStateMachine::processNavShutdown, this));
    start_timer_ = create_wall_timer(200ms, [this]() {
      start_timer_->cancel();
      enterLineFollowing();
    });

    publishStatus("starting");
    RCLCPP_INFO(get_logger(), "fusion_nav_yellow_point_state_machine_fast started");
  }

  ~FusionNavYellowPointStateMachine() override
  {
    stopAllProcesses();
    publishStopCommand();
  }

private:
  enum class State
  {
    STARTING,
    LINE_FOLLOWING,
    QR_APPROACH,
    MULTI_POINT_NAV,
    NAV_SHUTDOWN,
    YELLOW_CHANNEL,
    AFTER_YELLOW_LINE_FOLLOWING,
    ERROR
  };

  struct LifecycleClientState
  {
    std::string service_name;
    rclcpp::Client<ManageLifecycleNodes>::SharedPtr client;
    bool done{false};
    bool success{false};
  };

  struct RetiredProcess
  {
    pid_t pid{-1};
    std::string name;
    std::chrono::steady_clock::time_point sigint_sent_at{};
    std::chrono::steady_clock::time_point sigterm_sent_at{};
    bool sent_sigterm{false};
    bool sent_sigkill{false};
  };

  void loadParameters()
  {
    package_name_ = declare_parameter<std::string>("package_name", package_name_);
    ros2_executable_ = declare_parameter<std::string>("ros2_executable", ros2_executable_);
    status_topic_ = declare_parameter<std::string>("status_topic", status_topic_);
    cmd_vel_topic_ = declare_parameter<std::string>("cmd_vel_topic", cmd_vel_topic_);
    odom_topic_ = declare_parameter<std::string>("odom_topic", odom_topic_);
    line_exit_x_ = declare_parameter<double>("line_exit_x", line_exit_x_);
    qr_node_name_ = declare_parameter<std::string>("qr_node_name", qr_node_name_);
    qr_result_param_ = declare_parameter<std::string>("qr_result_param", qr_result_param_);
    poll_qr_param_hz_ = std::max(0.1, declare_parameter<double>("poll_qr_param_hz", poll_qr_param_hz_));
    use_qr_result_topic_ = declare_parameter<bool>("use_qr_result_topic", use_qr_result_topic_);
    qr_result_topic_ = declare_parameter<std::string>("qr_result_topic", qr_result_topic_);
    multi_nav_status_topic_ =
      declare_parameter<std::string>("multi_nav_status_topic", multi_nav_status_topic_);
    stop_grace_sec_ = std::max(0.1, declare_parameter<double>("stop_grace_sec", stop_grace_sec_));
    publish_stop_on_transition_ =
      declare_parameter<bool>("publish_stop_on_transition", publish_stop_on_transition_);
    stop_publish_repeats_ = std::max(
      1,
      static_cast<int>(declare_parameter<int64_t>("stop_publish_repeats", stop_publish_repeats_)));
    stop_publish_interval_sec_ =
      std::max(0.0, declare_parameter<double>("stop_publish_interval_sec", stop_publish_interval_sec_));
    nav_shutdown_timeout_sec_ =
      std::max(0.1, declare_parameter<double>("nav_shutdown_timeout_sec", nav_shutdown_timeout_sec_));
    overlap_transition_ = declare_parameter<bool>("overlap_transition", overlap_transition_);
    old_process_sigint_to_sigterm_sec_ = std::max(
      0.0, declare_parameter<double>("old_process_sigint_to_sigterm_sec", old_process_sigint_to_sigterm_sec_));
    old_process_sigterm_to_sigkill_sec_ = std::max(
      0.0, declare_parameter<double>("old_process_sigterm_to_sigkill_sec", old_process_sigterm_to_sigkill_sec_));
    background_reap_interval_sec_ = std::max(
      0.01, declare_parameter<double>("background_reap_interval_sec", background_reap_interval_sec_));
    direct_exec_ = declare_parameter<bool>("direct_exec", direct_exec_);

    line_executable_ = declare_parameter<std::string>("line_executable", line_executable_);
    qr_executable_ = declare_parameter<std::string>("qr_executable", qr_executable_);
    multi_nav_executable_ =
      declare_parameter<std::string>("multi_nav_executable", multi_nav_executable_);
    yellow_executable_ = declare_parameter<std::string>("yellow_executable", yellow_executable_);
    after_yellow_line_executable_ =
      declare_parameter<std::string>("after_yellow_line_executable", after_yellow_line_executable_);

    yellow_node_name_ = declare_parameter<std::string>("yellow_node_name", yellow_node_name_);
    yellow_red_trigger_param_ =
      declare_parameter<std::string>("yellow_red_trigger_param", yellow_red_trigger_param_);
    poll_yellow_red_param_hz_ =
      std::max(0.1, declare_parameter<double>("poll_yellow_red_param_hz", poll_yellow_red_param_hz_));
    use_parameter_events_for_yellow_red_ =
      declare_parameter<bool>("use_parameter_events_for_yellow_red", use_parameter_events_for_yellow_red_);
    yolo_targets_topic_ = declare_parameter<std::string>("yolo_targets_topic", yolo_targets_topic_);
    point_label_ = declare_parameter<std::string>("point_label", point_label_);
    point_confidence_threshold_ =
      std::max(0.0, declare_parameter<double>("point_confidence_threshold", point_confidence_threshold_));
    point_detection_timeout_sec_ =
      std::max(0.0, declare_parameter<double>("point_detection_timeout_sec", point_detection_timeout_sec_));

    nav_lifecycle_manager_services_ =
      declare_parameter<std::vector<std::string>>(
      "nav_lifecycle_manager_services",
      nav_lifecycle_manager_services_);

    line_params_file_ = declare_parameter<std::string>("line_params_file", "");
    qr_params_file_ = declare_parameter<std::string>("qr_params_file", "");
    multi_nav_params_file_ = declare_parameter<std::string>("multi_nav_params_file", "");
    yellow_params_file_ = declare_parameter<std::string>("yellow_params_file", "");
    after_yellow_line_params_file_ =
      declare_parameter<std::string>("after_yellow_line_params_file", "");
    if (line_params_file_.empty()) {
      line_params_file_ = packageConfigPath("pure_line_follower.yaml");
    }
    if (qr_params_file_.empty()) {
      qr_params_file_ = packageConfigPath("qr_approach_reader.yaml");
    }
    if (multi_nav_params_file_.empty()) {
      multi_nav_params_file_ = packageConfigPath("multi_point_nav.yaml");
    }
    if (yellow_params_file_.empty()) {
      yellow_params_file_ = packageConfigPath("yellow_channel.yaml");
    }
    if (after_yellow_line_params_file_.empty()) {
      after_yellow_line_params_file_ = packageConfigPath("pure_line_follower_after_yellow.yaml");
    }
  }

  void enterLineFollowing()
  {
    if (state_ == State::LINE_FOLLOWING) {
      return;
    }
    stopCurrentProcess();
    state_ = State::LINE_FOLLOWING;
    publishStatus("line_following");
    if (!startManagedProcess(line_executable_, line_params_file_)) {
      enterError("failed to start " + line_executable_);
    }
  }

  void enterQrApproach()
  {
    if (state_ == State::QR_APPROACH) {
      return;
    }
    stopCurrentProcess();
    state_ = State::QR_APPROACH;
    qr_param_request_pending_ = false;
    publishStatus("qr_approach");
    if (!startManagedProcess(qr_executable_, qr_params_file_)) {
      enterError("failed to start " + qr_executable_);
    }
  }

  void enterMultiPointNav()
  {
    if (state_ == State::MULTI_POINT_NAV) {
      return;
    }
    stopCurrentProcess();
    state_ = State::MULTI_POINT_NAV;
    multi_nav_became_active_ = false;
    publishStatus("multi_point_nav");
    if (!startManagedProcess(multi_nav_executable_, multi_nav_params_file_)) {
      enterError("failed to start " + multi_nav_executable_);
    }
  }

  void enterNavShutdown()
  {
    if (
      state_ == State::NAV_SHUTDOWN ||
      state_ == State::YELLOW_CHANNEL ||
      state_ == State::AFTER_YELLOW_LINE_FOLLOWING)
    {
      return;
    }
    stopCurrentProcess();
    state_ = State::NAV_SHUTDOWN;
    nav_shutdown_requests_sent_ = false;
    nav_shutdown_pending_ = 0;
    nav_shutdown_failed_ = false;
    nav_shutdown_started_at_ = std::chrono::steady_clock::now();
    for (auto &client_state : nav_lifecycle_clients_) {
      client_state.done = false;
      client_state.success = false;
    }
    publishStopCommand();
    publishStatus("nav_shutdown");
  }

  void enterYellowChannel()
  {
    if (state_ == State::YELLOW_CHANNEL) {
      return;
    }
    stopCurrentProcess();
    state_ = State::YELLOW_CHANNEL;
    yellow_red_param_request_pending_ = false;
    yellow_red_trigger_value_.clear();
    latest_point_detected_ = false;
    last_point_seen_at_ = {};
    publishStatus("yellow_channel");
    if (!startManagedProcess(yellow_executable_, yellow_params_file_)) {
      enterError("failed to start " + yellow_executable_);
    }
  }

  void enterAfterYellowLineFollowing()
  {
    if (state_ == State::AFTER_YELLOW_LINE_FOLLOWING) {
      return;
    }
    stopCurrentProcess();
    state_ = State::AFTER_YELLOW_LINE_FOLLOWING;
    publishStatus("after_yellow_line_following");
    if (!startManagedProcess(after_yellow_line_executable_, after_yellow_line_params_file_)) {
      enterError("failed to start " + after_yellow_line_executable_);
    }
  }

  void enterError(const std::string &reason)
  {
    if (state_ == State::ERROR) {
      return;
    }
    stopCurrentProcess();
    state_ = State::ERROR;
    publishStopCommand();
    publishStatus("error");
    RCLCPP_ERROR(get_logger(), "State machine entered ERROR: %s", reason.c_str());
  }

  void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    if (state_ != State::LINE_FOLLOWING) {
      return;
    }

    const double x = msg->pose.pose.position.x;
    if (x > line_exit_x_) {
      RCLCPP_INFO(
        get_logger(),
        "odom x %.3f > %.3f, switching to QR approach",
        x,
        line_exit_x_);
      enterQrApproach();
    }
  }

  void pollQrParameter()
  {
    if (state_ != State::QR_APPROACH || qr_param_request_pending_) {
      return;
    }

    if (!qr_param_client_->service_is_ready()) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "waiting for QR parameter service: %s/get_parameters",
        normalizeNodeName(qr_node_name_).c_str());
      return;
    }

    auto request = std::make_shared<GetParameters::Request>();
    request->names.push_back(qr_result_param_);
    qr_param_request_pending_ = true;

    qr_param_client_->async_send_request(
      request,
      [this](rclcpp::Client<GetParameters>::SharedFuture future) {
        qr_param_request_pending_ = false;
        if (state_ != State::QR_APPROACH) {
          return;
        }

        const auto response = future.get();
        if (response->values.empty()) {
          return;
        }

        const std::string result = response->values.front().string_value;
        if (!result.empty()) {
          RCLCPP_INFO(get_logger(), "QR result parameter is non-empty: %s", result.c_str());
          enterMultiPointNav();
        }
      });
  }

  void qrResultCallback(const std_msgs::msg::String::SharedPtr msg)
  {
    if (state_ != State::QR_APPROACH || !msg || msg->data.empty()) {
      return;
    }

    RCLCPP_INFO(get_logger(), "QR result topic is non-empty: %s", msg->data.c_str());
    enterMultiPointNav();
  }

  void multiNavStatusCallback(const std_msgs::msg::String::SharedPtr msg)
  {
    if (state_ != State::MULTI_POINT_NAV) {
      return;
    }

    const std::string &status = msg->data;
    RCLCPP_INFO(get_logger(), "multi_point_nav status=%s", status.c_str());
    if (
      status == "waiting_server" ||
      status.rfind("running:", 0) == 0 ||
      status.rfind("succeeded:", 0) == 0)
    {
      multi_nav_became_active_ = true;
      return;
    }

    if (status == "all_succeeded") {
      enterNavShutdown();
      return;
    }

    if (status.rfind("failed:", 0) == 0) {
      enterError("multi_point_nav status: " + status);
      return;
    }

    if (status == "stopped" && multi_nav_became_active_) {
      enterError("multi_point_nav stopped before all waypoints succeeded");
    }
  }

  void yoloTargetsCallback(const PerceptionTargets::SharedPtr msg)
  {
    if (!msg) {
      return;
    }

    latest_point_detected_ = messageHasPoint(*msg);
    if (latest_point_detected_) {
      last_point_seen_at_ = std::chrono::steady_clock::now();
      tryEnterAfterYellowLineFollowing("point detected");
    }
  }

  bool messageHasPoint(const PerceptionTargets &targets_msg) const
  {
    for (const auto &target : targets_msg.targets) {
      if (target.type != point_label_ || target.rois.empty()) {
        continue;
      }

      const auto &roi = target.rois.front();
      if (roi.confidence > point_confidence_threshold_) {
        return true;
      }
    }
    return false;
  }

  bool hasRecentPointDetection() const
  {
    if (!latest_point_detected_) {
      return false;
    }
    if (point_detection_timeout_sec_ <= 0.0) {
      return true;
    }
    if (last_point_seen_at_ == std::chrono::steady_clock::time_point{}) {
      return false;
    }

    const double age_sec = std::chrono::duration<double>(
      std::chrono::steady_clock::now() - last_point_seen_at_).count();
    return age_sec <= point_detection_timeout_sec_;
  }

  void pollYellowRedParameter()
  {
    if (state_ != State::YELLOW_CHANNEL || yellow_red_param_request_pending_) {
      return;
    }

    if (!yellow_param_client_->service_is_ready()) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "waiting for yellow_channel parameter service: %s/get_parameters",
        normalizeNodeName(yellow_node_name_).c_str());
      return;
    }

    auto request = std::make_shared<GetParameters::Request>();
    request->names.push_back(yellow_red_trigger_param_);
    yellow_red_param_request_pending_ = true;

    yellow_param_client_->async_send_request(
      request,
      [this](rclcpp::Client<GetParameters>::SharedFuture future) {
        yellow_red_param_request_pending_ = false;
        if (state_ != State::YELLOW_CHANNEL) {
          return;
        }

        const auto response = future.get();
        if (response->values.empty()) {
          return;
        }

        const std::string trigger = response->values.front().string_value;
        if (trigger.empty()) {
          yellow_red_trigger_value_.clear();
          return;
        }

        if (yellow_red_trigger_value_.empty()) {
          RCLCPP_INFO(
            get_logger(),
            "yellow red trigger parameter is non-empty: %s=%s",
            yellow_red_trigger_param_.c_str(),
            trigger.c_str());
        }
        yellow_red_trigger_value_ = trigger;
        tryEnterAfterYellowLineFollowing("red trigger parameter detected");
      });
  }

  void parameterEventCallback(const ParameterEvent::SharedPtr msg)
  {
    if (state_ != State::YELLOW_CHANNEL || !msg) {
      return;
    }
    if (!isYellowNodeEvent(msg->node)) {
      return;
    }

    for (const auto &parameter : msg->changed_parameters) {
      if (applyYellowRedParameterValue(parameter.name, parameter.value, "red trigger parameter event")) {
        return;
      }
    }
    for (const auto &parameter : msg->new_parameters) {
      if (applyYellowRedParameterValue(parameter.name, parameter.value, "red trigger parameter event")) {
        return;
      }
    }
  }

  bool isYellowNodeEvent(const std::string &event_node) const
  {
    return normalizeNodeName(event_node) == normalizeNodeName(yellow_node_name_);
  }

  bool applyYellowRedParameterValue(
    const std::string &name,
    const ParameterValue &value,
    const std::string &reason)
  {
    if (name != yellow_red_trigger_param_) {
      return false;
    }
    if (value.type != rcl_interfaces::msg::ParameterType::PARAMETER_STRING) {
      return false;
    }
    if (value.string_value.empty()) {
      yellow_red_trigger_value_.clear();
      return true;
    }

    if (yellow_red_trigger_value_.empty()) {
      RCLCPP_INFO(
        get_logger(),
        "yellow red trigger event is non-empty: %s=%s",
        yellow_red_trigger_param_.c_str(),
        value.string_value.c_str());
    }
    yellow_red_trigger_value_ = value.string_value;
    tryEnterAfterYellowLineFollowing(reason);
    return true;
  }

  void tryEnterAfterYellowLineFollowing(const std::string &reason)
  {
    if (state_ != State::YELLOW_CHANNEL) {
      return;
    }
    if (yellow_red_trigger_value_.empty() || !hasRecentPointDetection()) {
      return;
    }

    RCLCPP_INFO(
      get_logger(),
      "red trigger and point label are both ready (%s); switching to %s",
      reason.c_str(),
      after_yellow_line_executable_.c_str());
    enterAfterYellowLineFollowing();
  }

  void processNavShutdown()
  {
    if (state_ != State::NAV_SHUTDOWN) {
      return;
    }

    const auto elapsed = std::chrono::duration<double>(
      std::chrono::steady_clock::now() - nav_shutdown_started_at_);
    if (elapsed.count() > nav_shutdown_timeout_sec_) {
      enterError("timeout while shutting down Nav2 lifecycle managers");
      return;
    }

    if (nav_lifecycle_clients_.empty()) {
      RCLCPP_WARN(get_logger(), "No Nav2 lifecycle manager services configured; starting yellow_channel");
      enterYellowChannel();
      return;
    }

    if (!nav_shutdown_requests_sent_) {
      for (const auto &client_state : nav_lifecycle_clients_) {
        if (!client_state.client->service_is_ready()) {
          RCLCPP_WARN_THROTTLE(
            get_logger(),
            *get_clock(),
            1000,
            "waiting for Nav2 lifecycle service: %s",
            client_state.service_name.c_str());
          return;
        }
      }
      sendNavShutdownRequests();
      return;
    }

    if (nav_shutdown_pending_ == 0) {
      if (nav_shutdown_failed_) {
        enterError("Nav2 lifecycle shutdown request failed");
        return;
      }
      RCLCPP_INFO(get_logger(), "Nav2 lifecycle managers shutdown complete");
      publishStopCommand();
      enterYellowChannel();
    }
  }

  void sendNavShutdownRequests()
  {
    nav_shutdown_requests_sent_ = true;
    nav_shutdown_pending_ = nav_lifecycle_clients_.size();

    for (auto &client_state : nav_lifecycle_clients_) {
      auto request = std::make_shared<ManageLifecycleNodes::Request>();
      request->command = ManageLifecycleNodes::Request::SHUTDOWN;
      const std::string service_name = client_state.service_name;

      client_state.client->async_send_request(
        request,
        [this, service_name](rclcpp::Client<ManageLifecycleNodes>::SharedFuture future) {
          if (state_ != State::NAV_SHUTDOWN) {
            return;
          }

          bool success = false;
          try {
            success = future.get()->success;
          } catch (const std::exception &exception) {
            RCLCPP_WARN(
              get_logger(),
              "Nav2 lifecycle service %s threw exception: %s",
              service_name.c_str(),
              exception.what());
          }

          if (!success) {
            nav_shutdown_failed_ = true;
            RCLCPP_WARN(get_logger(), "Nav2 lifecycle service %s returned failure", service_name.c_str());
          } else {
            RCLCPP_INFO(get_logger(), "Nav2 lifecycle service %s shutdown succeeded", service_name.c_str());
          }

          if (nav_shutdown_pending_ > 0) {
            --nav_shutdown_pending_;
          }
        });
    }
  }

  std::vector<std::string> makeCommand(
    const std::string &executable,
    const std::string &params_file) const
  {
    std::vector<std::string> command;
    const std::string direct_executable = resolveDirectExecutable(executable);
    if (!direct_executable.empty()) {
      command.push_back(direct_executable);
    } else {
      command = {
        ros2_executable_,
        "run",
        package_name_,
        executable
      };
    }
    if (!params_file.empty()) {
      command.push_back("--ros-args");
      command.push_back("--params-file");
      command.push_back(params_file);
    }
    return command;
  }

  std::string resolveDirectExecutable(const std::string &executable) const
  {
    if (!direct_exec_) {
      return "";
    }

    try {
      const std::string candidate =
        ament_index_cpp::get_package_prefix(package_name_) + "/lib/" + package_name_ + "/" + executable;
      if (access(candidate.c_str(), X_OK) == 0) {
        return candidate;
      }
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "direct executable not found or not executable: %s; falling back to ros2 run",
        candidate.c_str());
    } catch (const std::exception &exception) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "failed to resolve package prefix for %s: %s; falling back to ros2 run",
        package_name_.c_str(),
        exception.what());
    }
    return "";
  }

  bool startManagedProcess(const std::string &executable, const std::string &params_file)
  {
    const auto command = makeCommand(executable, params_file);
    const pid_t pid = fork();
    if (pid < 0) {
      RCLCPP_ERROR(get_logger(), "fork failed while starting %s", executable.c_str());
      return false;
    }

    if (pid == 0) {
      setpgid(0, 0);
      std::vector<char *> argv;
      argv.reserve(command.size() + 1);
      for (const auto &part : command) {
        argv.push_back(const_cast<char *>(part.c_str()));
      }
      argv.push_back(nullptr);
      execvp(argv.front(), argv.data());
      std::_Exit(127);
    }

    setpgid(pid, pid);
    current_child_pid_ = pid;
    current_child_name_ = executable;
    RCLCPP_INFO(get_logger(), "Started %s with pid %d", executable.c_str(), pid);
    return true;
  }

  void stopCurrentProcess()
  {
    if (current_child_pid_ <= 0) {
      return;
    }

    const pid_t pid = current_child_pid_;
    const std::string name = current_child_name_;
    current_child_pid_ = -1;
    current_child_name_.clear();

    RCLCPP_INFO(get_logger(), "Stopping %s pid %d", name.c_str(), pid);
    kill(-pid, SIGINT);
    publishStopCommand();
    if (overlap_transition_) {
      RetiredProcess retired;
      retired.pid = pid;
      retired.name = name;
      retired.sigint_sent_at = std::chrono::steady_clock::now();
      retired_processes_.push_back(retired);
      RCLCPP_INFO(get_logger(), "Retired %s pid %d for background shutdown", name.c_str(), pid);
      return;
    }

    if (!waitForExit(pid, stop_grace_sec_)) {
      kill(-pid, SIGTERM);
      if (!waitForExit(pid, stop_grace_sec_)) {
        kill(-pid, SIGKILL);
        waitForExit(pid, stop_grace_sec_);
      }
    }
  }

  bool waitForExit(pid_t pid, double timeout_sec)
  {
    const auto start = std::chrono::steady_clock::now();
    int status = 0;
    while (std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count() < timeout_sec) {
      const pid_t result = waitpid(pid, &status, WNOHANG);
      if (result == pid) {
        return true;
      }
      if (result < 0) {
        return true;
      }
      rclcpp::sleep_for(100ms);
    }
    return false;
  }

  void watchChildProcess()
  {
    if (
      current_child_pid_ <= 0 ||
      state_ == State::NAV_SHUTDOWN ||
      state_ == State::ERROR)
    {
      return;
    }

    int status = 0;
    const pid_t result = waitpid(current_child_pid_, &status, WNOHANG);
    if (result == current_child_pid_) {
      const std::string name = current_child_name_;
      current_child_pid_ = -1;
      current_child_name_.clear();
      enterError("child process exited unexpectedly: " + name);
    }
  }

  void reapRetiredProcesses()
  {
    if (retired_processes_.empty()) {
      return;
    }

    const auto now_time = std::chrono::steady_clock::now();
    int status = 0;
    for (auto process = retired_processes_.begin(); process != retired_processes_.end();) {
      const pid_t result = waitpid(process->pid, &status, WNOHANG);
      if (result == process->pid) {
        RCLCPP_INFO(
          get_logger(),
          "Retired process %s pid %d exited",
          process->name.c_str(),
          process->pid);
        process = retired_processes_.erase(process);
        continue;
      }
      if (result < 0) {
        RCLCPP_WARN(
          get_logger(),
          "Retired process %s pid %d is no longer waitable: errno=%d",
          process->name.c_str(),
          process->pid,
          errno);
        process = retired_processes_.erase(process);
        continue;
      }

      if (!process->sent_sigterm) {
        const double age_sec = std::chrono::duration<double>(now_time - process->sigint_sent_at).count();
        if (age_sec >= old_process_sigint_to_sigterm_sec_) {
          kill(-process->pid, SIGTERM);
          process->sent_sigterm = true;
          process->sigterm_sent_at = now_time;
          RCLCPP_WARN(
            get_logger(),
            "Retired process %s pid %d did not exit after SIGINT; sent SIGTERM",
            process->name.c_str(),
            process->pid);
        }
      } else if (!process->sent_sigkill) {
        const double age_sec = std::chrono::duration<double>(now_time - process->sigterm_sent_at).count();
        if (age_sec >= old_process_sigterm_to_sigkill_sec_) {
          kill(-process->pid, SIGKILL);
          process->sent_sigkill = true;
          RCLCPP_ERROR(
            get_logger(),
            "Retired process %s pid %d did not exit after SIGTERM; sent SIGKILL",
            process->name.c_str(),
            process->pid);
        }
      }

      ++process;
    }
  }

  void stopAllProcesses()
  {
    const bool previous_overlap = overlap_transition_;
    overlap_transition_ = false;
    stopCurrentProcess();
    overlap_transition_ = previous_overlap;

    for (auto &process : retired_processes_) {
      kill(-process.pid, SIGTERM);
    }
    for (auto &process : retired_processes_) {
      if (!waitForExit(process.pid, stop_grace_sec_)) {
        kill(-process.pid, SIGKILL);
        waitForExit(process.pid, stop_grace_sec_);
      }
    }
    retired_processes_.clear();
  }

  void publishStopCommand()
  {
    if (!publish_stop_on_transition_ || !cmd_vel_pub_) {
      return;
    }

    geometry_msgs::msg::Twist stop;
    for (int i = 0; i < stop_publish_repeats_; ++i) {
      cmd_vel_pub_->publish(stop);
      if (stop_publish_interval_sec_ > 0.0 && i + 1 < stop_publish_repeats_) {
        rclcpp::sleep_for(std::chrono::duration_cast<std::chrono::nanoseconds>(
          std::chrono::duration<double>(stop_publish_interval_sec_)));
      }
    }
  }

  void publishStatus(const std::string &status)
  {
    std_msgs::msg::String msg;
    msg.data = status;
    status_pub_->publish(msg);
    RCLCPP_INFO(get_logger(), "state=%s", status.c_str());
  }

  State state_{State::STARTING};

  std::string package_name_{"liu_dine"};
  std::string ros2_executable_{"ros2"};
  std::string status_topic_{"/fusion_nav_yellow_point_state_machine_fast/status"};
  std::string cmd_vel_topic_{"/cmd_vel"};
  std::string odom_topic_{"/odom"};
  double line_exit_x_{2.4};
  std::string qr_node_name_{"/qr_approach_reader"};
  std::string qr_result_param_{"last_qr_code_result"};
  double poll_qr_param_hz_{2.0};
  bool use_qr_result_topic_{true};
  std::string qr_result_topic_{"/qr_code_result"};
  std::string multi_nav_status_topic_{"/multi_point_nav/status"};
  std::string yellow_node_name_{"/single_cetnerline_param_node"};
  std::string yellow_red_trigger_param_{"red_text_trigger.last_trigger"};
  double poll_yellow_red_param_hz_{5.0};
  bool use_parameter_events_for_yellow_red_{true};
  std::string yolo_targets_topic_{"dnn_node_sample"};
  std::string point_label_{"point"};
  double point_confidence_threshold_{0.7};
  double point_detection_timeout_sec_{0.5};
  double stop_grace_sec_{1.0};
  bool publish_stop_on_transition_{true};
  int stop_publish_repeats_{1};
  double stop_publish_interval_sec_{0.0};
  double nav_shutdown_timeout_sec_{5.0};
  bool overlap_transition_{true};
  double old_process_sigint_to_sigterm_sec_{0.2};
  double old_process_sigterm_to_sigkill_sec_{0.3};
  double background_reap_interval_sec_{0.05};
  bool direct_exec_{true};

  std::string line_executable_{"pure_line_follower"};
  std::string qr_executable_{"qr_approach_reader"};
  std::string multi_nav_executable_{"multi_point_nav"};
  std::string yellow_executable_{"yellow_channel"};
  std::string after_yellow_line_executable_{"pure_line_follower"};
  std::string line_params_file_;
  std::string qr_params_file_;
  std::string multi_nav_params_file_;
  std::string yellow_params_file_;
  std::string after_yellow_line_params_file_;
  std::vector<std::string> nav_lifecycle_manager_services_{
    "/lifecycle_manager_navigation/manage_nodes",
    "/lifecycle_manager_localization/manage_nodes"};

  pid_t current_child_pid_{-1};
  std::string current_child_name_;
  bool qr_param_request_pending_{false};
  bool multi_nav_became_active_{false};
  bool yellow_red_param_request_pending_{false};
  bool latest_point_detected_{false};
  std::string yellow_red_trigger_value_;
  bool nav_shutdown_requests_sent_{false};
  bool nav_shutdown_failed_{false};
  std::size_t nav_shutdown_pending_{0};
  std::chrono::steady_clock::time_point nav_shutdown_started_at_{};
  std::chrono::steady_clock::time_point last_point_seen_at_{};
  std::vector<LifecycleClientState> nav_lifecycle_clients_;
  std::vector<RetiredProcess> retired_processes_;

  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr status_pub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr multi_nav_status_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr qr_result_sub_;
  rclcpp::Subscription<PerceptionTargets>::SharedPtr yolo_targets_sub_;
  rclcpp::Subscription<ParameterEvent>::SharedPtr parameter_events_sub_;
  rclcpp::Client<GetParameters>::SharedPtr qr_param_client_;
  rclcpp::Client<GetParameters>::SharedPtr yellow_param_client_;
  rclcpp::TimerBase::SharedPtr qr_poll_timer_;
  rclcpp::TimerBase::SharedPtr yellow_red_poll_timer_;
  rclcpp::TimerBase::SharedPtr process_watch_timer_;
  rclcpp::TimerBase::SharedPtr background_reap_timer_;
  rclcpp::TimerBase::SharedPtr nav_shutdown_timer_;
  rclcpp::TimerBase::SharedPtr start_timer_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<FusionNavYellowPointStateMachine>());
  rclcpp::shutdown();
  return 0;
}
