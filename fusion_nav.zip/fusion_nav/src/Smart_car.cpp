/*
 * Smart_car 四阶段任务状态机
 *
 * 功能说明:
 * - 状态 1: 小车从 P 点出发，启动 pure_line_follower 视觉巡线程序；状态机订阅 /odom，
 *   当 pose.pose.position.x 大于 line_exit_x 默认 2.4 时，停止巡线并进入状态 2。
 * - 状态 2: 启动 qr_approach_reader 追踪并识别二维码；状态机轮询该节点参数
 *   last_qr_code_result，当结果非空时，停止二维码程序并进入状态 3。
 * - 状态 3: 启动 multi_point_nav 多点导航程序；状态机订阅 /multi_point_nav/status，
 *   当收到 all_succeeded 时认为到达多点最后/指定点，停止多点程序。
 * - 状态 4: 通过 Nav2 lifecycle manager 只关闭导航生命周期节点，但不杀
 *   navigation2.launch.py，保留小车底盘控制；同时尽快启动 yellow_channel 黄色通道巡线程序。
 * - 正常状态切换采用短等待、少停车的丝滑模式；异常/退出时采用保守停车模式。
 */

#include <algorithm>
#include <chrono>
#include <csignal>
#include <cstddef>
#include <cstdlib>
#include <exception>
#include <functional>
#include <memory>
#include <string>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>

#include "ament_index_cpp/get_package_share_directory.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "nav2_msgs/srv/manage_lifecycle_nodes.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "rcl_interfaces/srv/get_parameters.hpp"
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

using namespace std::chrono_literals;

namespace
{
std::string joinPath(const std::string &left, const std::string &right)
{
  if (left.empty()) {
    return right;
  }
  if (right.empty()) {
    return left;
  }
  if (left.back() == '/') {
    return left + right;
  }
  return left + "/" + right;
}

std::string trimSlashes(const std::string &path)
{
  const auto first = path.find_first_not_of('/');
  if (first == std::string::npos) {
    return "";
  }
  const auto last = path.find_last_not_of('/');
  return path.substr(first, last - first + 1);
}

std::string normalizeNodeName(const std::string &node_name)
{
  if (node_name.empty()) {
    return "/";
  }
  if (node_name.front() == '/') {
    return node_name;
  }
  return "/" + node_name;
}
}  // namespace

class SmartCarStateMachine : public rclcpp::Node
{
public:
  using ManageLifecycleNodes = nav2_msgs::srv::ManageLifecycleNodes;

  SmartCarStateMachine()
  : Node("smart_car_state_machine")
  {
    loadParameters();

    status_pub_ = create_publisher<std_msgs::msg::String>(
      status_topic_,
      rclcpp::QoS(10).reliable().transient_local());
    cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);
    odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
      odom_topic_,
      10,
      std::bind(&SmartCarStateMachine::odomCallback, this, std::placeholders::_1));
    multi_nav_status_sub_ = create_subscription<std_msgs::msg::String>(
      multi_nav_status_topic_,
      rclcpp::QoS(10).reliable().transient_local(),
      std::bind(&SmartCarStateMachine::multiNavStatusCallback, this, std::placeholders::_1));

    qr_param_client_ = create_client<rcl_interfaces::srv::GetParameters>(
      normalizeNodeName(qr_node_name_) + "/get_parameters");
    for (const auto &service_name : nav_lifecycle_manager_services_) {
      nav_lifecycle_clients_.push_back({service_name, create_client<ManageLifecycleNodes>(service_name)});
    }

    const auto poll_period = std::chrono::duration<double>(1.0 / poll_qr_param_hz_);
    qr_poll_timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(poll_period),
      std::bind(&SmartCarStateMachine::pollQrParameter, this));
    process_watch_timer_ = create_wall_timer(
      500ms,
      std::bind(&SmartCarStateMachine::watchChildProcess, this));
    nav_shutdown_timer_ = create_wall_timer(
      200ms,
      std::bind(&SmartCarStateMachine::processNavShutdown, this));
    start_timer_ = create_wall_timer(200ms, [this]() {
      start_timer_->cancel();
      enterLineFollowing();
    });

    publishStatus("starting");
    RCLCPP_INFO(get_logger(), "Smart_car state machine started");
  }

  ~SmartCarStateMachine() override
  {
    stopCurrentProcess(StopMode::ERROR_OR_EXIT);
    publishStopCommand(StopMode::ERROR_OR_EXIT);
  }

private:
  enum class State
  {
    STARTING,
    LINE_FOLLOWING,
    QR_APPROACH,
    MULTI_POINT_NAV,
    NAV_SHUTDOWN,
    YELLOW_CHANNEL,
    ERROR
  };

  enum class StopMode
  {
    NORMAL_TRANSITION,
    ERROR_OR_EXIT
  };

  struct LifecycleClientState
  {
    std::string service_name;
    rclcpp::Client<ManageLifecycleNodes>::SharedPtr client;
  };

  void loadParameters()
  {
    package_name_ = declare_parameter<std::string>("package_name", package_name_);
    config_relative_dir_ =
      declare_parameter<std::string>("config_relative_dir", config_relative_dir_);
    ros2_executable_ = declare_parameter<std::string>("ros2_executable", ros2_executable_);
    status_topic_ = declare_parameter<std::string>("status_topic", status_topic_);
    cmd_vel_topic_ = declare_parameter<std::string>("cmd_vel_topic", cmd_vel_topic_);
    odom_topic_ = declare_parameter<std::string>("odom_topic", odom_topic_);
    line_exit_x_ = declare_parameter<double>("line_exit_x", line_exit_x_);
    qr_node_name_ = declare_parameter<std::string>("qr_node_name", qr_node_name_);
    qr_result_param_ = declare_parameter<std::string>("qr_result_param", qr_result_param_);
    poll_qr_param_hz_ = std::max(0.1, declare_parameter<double>("poll_qr_param_hz", poll_qr_param_hz_));
    multi_nav_status_topic_ =
      declare_parameter<std::string>("multi_nav_status_topic", multi_nav_status_topic_);
    const double legacy_stop_grace_sec =
      std::max(0.0, declare_parameter<double>("stop_grace_sec", error_stop_grace_sec_));
    normal_stop_grace_sec_ =
      std::max(0.0, declare_parameter<double>("normal_stop_grace_sec", normal_stop_grace_sec_));
    error_stop_grace_sec_ =
      std::max(0.0, declare_parameter<double>("error_stop_grace_sec", legacy_stop_grace_sec));

    const bool legacy_publish_stop =
      declare_parameter<bool>("publish_stop_on_transition", publish_stop_on_error_);
    publish_stop_on_normal_transition_ =
      declare_parameter<bool>(
      "publish_stop_on_normal_transition",
      publish_stop_on_normal_transition_);
    publish_stop_on_error_ =
      declare_parameter<bool>("publish_stop_on_error", legacy_publish_stop);

    const int legacy_stop_publish_repeats = std::max(
      0,
      static_cast<int>(declare_parameter<int64_t>("stop_publish_repeats", error_stop_publish_repeats_)));
    normal_stop_publish_repeats_ = std::max(
      0,
      static_cast<int>(
        declare_parameter<int64_t>(
          "normal_stop_publish_repeats",
          normal_stop_publish_repeats_)));
    error_stop_publish_repeats_ = std::max(
      0,
      static_cast<int>(
        declare_parameter<int64_t>(
          "error_stop_publish_repeats",
          legacy_stop_publish_repeats)));
    stop_publish_interval_sec_ =
      std::max(0.0, declare_parameter<double>("stop_publish_interval_sec", stop_publish_interval_sec_));
    nav_shutdown_timeout_sec_ =
      std::max(0.1, declare_parameter<double>("nav_shutdown_timeout_sec", nav_shutdown_timeout_sec_));
    start_yellow_before_nav_shutdown_done_ =
      declare_parameter<bool>(
      "start_yellow_before_nav_shutdown_done",
      start_yellow_before_nav_shutdown_done_);

    line_executable_ = declare_parameter<std::string>("line_executable", line_executable_);
    qr_executable_ = declare_parameter<std::string>("qr_executable", qr_executable_);
    multi_nav_executable_ =
      declare_parameter<std::string>("multi_nav_executable", multi_nav_executable_);
    yellow_executable_ = declare_parameter<std::string>("yellow_executable", yellow_executable_);

    nav_lifecycle_manager_services_ =
      declare_parameter<std::vector<std::string>>(
      "nav_lifecycle_manager_services",
      nav_lifecycle_manager_services_);

    line_params_file_ = declare_parameter<std::string>("line_params_file", "");
    qr_params_file_ = declare_parameter<std::string>("qr_params_file", "");
    multi_nav_params_file_ = declare_parameter<std::string>("multi_nav_params_file", "");
    yellow_params_file_ = declare_parameter<std::string>("yellow_params_file", "");
    if (line_params_file_.empty()) {
      line_params_file_ = packageConfigPath("pure_line_follower.yaml");
    }
    if (qr_params_file_.empty()) {
      qr_params_file_ = packageConfigPath("qr_approach_reader.yaml");
    }
    if (multi_nav_params_file_.empty()) {
      multi_nav_params_file_ = packageConfigPath("multi_point_nav.yaml");
    }
    if (yellow_params_file_.empty()) {
      yellow_params_file_ = packageConfigPath("yellow_channel.yaml");
    }
  }

  std::string packageConfigPath(const std::string &filename) const
  {
    try {
      return joinPath(
        joinPath(ament_index_cpp::get_package_share_directory(package_name_), trimSlashes(config_relative_dir_)),
        filename);
    } catch (const std::exception &) {
      return joinPath(
        joinPath("/home/wc/CH1/yellow_channel_ws/src/fusion_nav", trimSlashes(config_relative_dir_)),
        filename);
    }
  }

  void enterLineFollowing()
  {
    if (state_ == State::LINE_FOLLOWING) {
      return;
    }
    stopCurrentProcess(StopMode::NORMAL_TRANSITION);
    state_ = State::LINE_FOLLOWING;
    publishStatus("line_following");
    if (!startManagedProcess(line_executable_, line_params_file_)) {
      enterError("failed to start " + line_executable_);
    }
  }

  void enterQrApproach()
  {
    if (state_ == State::QR_APPROACH) {
      return;
    }
    stopCurrentProcess(StopMode::NORMAL_TRANSITION);
    state_ = State::QR_APPROACH;
    qr_param_request_pending_ = false;
    publishStatus("qr_approach");
    if (!startManagedProcess(qr_executable_, qr_params_file_)) {
      enterError("failed to start " + qr_executable_);
    }
  }

  void enterMultiPointNav()
  {
    if (state_ == State::MULTI_POINT_NAV) {
      return;
    }
    stopCurrentProcess(StopMode::NORMAL_TRANSITION);
    state_ = State::MULTI_POINT_NAV;
    multi_nav_became_active_ = false;
    publishStatus("multi_point_nav");
    if (!startManagedProcess(multi_nav_executable_, multi_nav_params_file_)) {
      enterError("failed to start " + multi_nav_executable_);
    }
  }

  void enterNavShutdown()
  {
    if (state_ == State::NAV_SHUTDOWN || state_ == State::YELLOW_CHANNEL) {
      return;
    }
    stopCurrentProcess(StopMode::NORMAL_TRANSITION);
    state_ = State::NAV_SHUTDOWN;
    nav_shutdown_requests_sent_ = false;
    nav_shutdown_pending_ = 0;
    nav_shutdown_failed_ = false;
    nav_shutdown_complete_ = false;
    nav_shutdown_started_at_ = std::chrono::steady_clock::now();
    publishStatus("nav_shutdown");
    if (start_yellow_before_nav_shutdown_done_) {
      processNavShutdown();
      enterYellowChannel();
    }
  }

  void enterYellowChannel()
  {
    if (state_ == State::YELLOW_CHANNEL) {
      return;
    }
    stopCurrentProcess(StopMode::NORMAL_TRANSITION);
    state_ = State::YELLOW_CHANNEL;
    publishStatus("yellow_channel");
    if (!startManagedProcess(yellow_executable_, yellow_params_file_)) {
      enterError("failed to start " + yellow_executable_);
    }
  }

  void enterError(const std::string &reason)
  {
    if (state_ == State::ERROR) {
      return;
    }
    stopCurrentProcess(StopMode::ERROR_OR_EXIT);
    state_ = State::ERROR;
    publishStopCommand(StopMode::ERROR_OR_EXIT);
    publishStatus("error");
    RCLCPP_ERROR(get_logger(), "State machine entered ERROR: %s", reason.c_str());
  }

  void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    if (state_ != State::LINE_FOLLOWING) {
      return;
    }

    const double x = msg->pose.pose.position.x;
    if (x > line_exit_x_) {
      RCLCPP_INFO(
        get_logger(),
        "odom x %.3f > %.3f, switching to QR approach",
        x,
        line_exit_x_);
      enterQrApproach();
    }
  }

  void pollQrParameter()
  {
    if (state_ != State::QR_APPROACH || qr_param_request_pending_) {
      return;
    }

    if (!qr_param_client_->service_is_ready()) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "waiting for QR parameter service: %s/get_parameters",
        normalizeNodeName(qr_node_name_).c_str());
      return;
    }

    auto request = std::make_shared<rcl_interfaces::srv::GetParameters::Request>();
    request->names.push_back(qr_result_param_);
    qr_param_request_pending_ = true;

    qr_param_client_->async_send_request(
      request,
      [this](rclcpp::Client<rcl_interfaces::srv::GetParameters>::SharedFuture future) {
        qr_param_request_pending_ = false;
        if (state_ != State::QR_APPROACH) {
          return;
        }

        const auto response = future.get();
        if (response->values.empty()) {
          return;
        }

        const std::string result = response->values.front().string_value;
        if (!result.empty()) {
          RCLCPP_INFO(get_logger(), "QR result parameter is non-empty: %s", result.c_str());
          enterMultiPointNav();
        }
      });
  }

  void multiNavStatusCallback(const std_msgs::msg::String::SharedPtr msg)
  {
    if (state_ != State::MULTI_POINT_NAV) {
      return;
    }

    const std::string &status = msg->data;
    RCLCPP_INFO(get_logger(), "multi_point_nav status=%s", status.c_str());
    if (
      status == "waiting_server" ||
      status.rfind("running:", 0) == 0 ||
      status.rfind("succeeded:", 0) == 0)
    {
      multi_nav_became_active_ = true;
      return;
    }

    if (status == "all_succeeded") {
      enterNavShutdown();
      return;
    }

    if (status.rfind("failed:", 0) == 0) {
      enterError("multi_point_nav status: " + status);
      return;
    }

    if (status == "stopped" && multi_nav_became_active_) {
      enterError("multi_point_nav stopped before all waypoints succeeded");
    }
  }

  void processNavShutdown()
  {
    if (state_ != State::NAV_SHUTDOWN && state_ != State::YELLOW_CHANNEL) {
      return;
    }
    if (nav_shutdown_complete_) {
      return;
    }

    const auto elapsed = std::chrono::duration<double>(
      std::chrono::steady_clock::now() - nav_shutdown_started_at_);
    if (elapsed.count() > nav_shutdown_timeout_sec_) {
      enterError("timeout while shutting down Nav2 lifecycle managers");
      return;
    }

    if (nav_lifecycle_clients_.empty()) {
      nav_shutdown_complete_ = true;
      if (state_ == State::NAV_SHUTDOWN) {
        RCLCPP_WARN(get_logger(), "No Nav2 lifecycle manager services configured; starting yellow_channel");
        enterYellowChannel();
      }
      return;
    }

    if (!nav_shutdown_requests_sent_) {
      for (const auto &client_state : nav_lifecycle_clients_) {
        if (!client_state.client->service_is_ready()) {
          RCLCPP_WARN_THROTTLE(
            get_logger(),
            *get_clock(),
            1000,
            "waiting for Nav2 lifecycle service: %s",
            client_state.service_name.c_str());
          return;
        }
      }
      sendNavShutdownRequests();
      return;
    }

    if (nav_shutdown_pending_ == 0) {
      if (nav_shutdown_failed_) {
        enterError("Nav2 lifecycle shutdown request failed");
        return;
      }
      nav_shutdown_complete_ = true;
      RCLCPP_INFO(get_logger(), "Nav2 lifecycle managers shutdown complete");
      if (state_ == State::NAV_SHUTDOWN) {
        enterYellowChannel();
      }
    }
  }

  void sendNavShutdownRequests()
  {
    nav_shutdown_requests_sent_ = true;
    nav_shutdown_pending_ = nav_lifecycle_clients_.size();

    for (const auto &client_state : nav_lifecycle_clients_) {
      auto request = std::make_shared<ManageLifecycleNodes::Request>();
      request->command = ManageLifecycleNodes::Request::SHUTDOWN;
      const std::string service_name = client_state.service_name;

      client_state.client->async_send_request(
        request,
        [this, service_name](rclcpp::Client<ManageLifecycleNodes>::SharedFuture future) {
          if (state_ != State::NAV_SHUTDOWN && state_ != State::YELLOW_CHANNEL) {
            return;
          }

          bool success = false;
          try {
            success = future.get()->success;
          } catch (const std::exception &exception) {
            RCLCPP_WARN(
              get_logger(),
              "Nav2 lifecycle service %s threw exception: %s",
              service_name.c_str(),
              exception.what());
          }

          if (!success) {
            nav_shutdown_failed_ = true;
            RCLCPP_WARN(get_logger(), "Nav2 lifecycle service %s returned failure", service_name.c_str());
          } else {
            RCLCPP_INFO(get_logger(), "Nav2 lifecycle service %s shutdown succeeded", service_name.c_str());
          }

          if (nav_shutdown_pending_ > 0) {
            --nav_shutdown_pending_;
          }
        });
    }
  }

  std::vector<std::string> makeCommand(
    const std::string &executable,
    const std::string &params_file) const
  {
    std::vector<std::string> command{
      ros2_executable_,
      "run",
      package_name_,
      executable
    };
    if (!params_file.empty()) {
      command.push_back("--ros-args");
      command.push_back("--params-file");
      command.push_back(params_file);
    }
    return command;
  }

  bool startManagedProcess(const std::string &executable, const std::string &params_file)
  {
    const auto command = makeCommand(executable, params_file);
    const pid_t pid = fork();
    if (pid < 0) {
      RCLCPP_ERROR(get_logger(), "fork failed while starting %s", executable.c_str());
      return false;
    }

    if (pid == 0) {
      setpgid(0, 0);
      std::vector<char *> argv;
      argv.reserve(command.size() + 1);
      for (const auto &part : command) {
        argv.push_back(const_cast<char *>(part.c_str()));
      }
      argv.push_back(nullptr);
      execvp(argv.front(), argv.data());
      std::_Exit(127);
    }

    setpgid(pid, pid);
    current_child_pid_ = pid;
    current_child_name_ = executable;
    RCLCPP_INFO(get_logger(), "Started %s with pid %d", executable.c_str(), pid);
    return true;
  }

  void stopCurrentProcess(StopMode mode)
  {
    if (current_child_pid_ <= 0) {
      return;
    }

    const pid_t pid = current_child_pid_;
    const std::string name = current_child_name_;
    current_child_pid_ = -1;
    current_child_name_.clear();

    const double grace_sec =
      mode == StopMode::NORMAL_TRANSITION ? normal_stop_grace_sec_ : error_stop_grace_sec_;
    const double escalation_grace_sec =
      mode == StopMode::NORMAL_TRANSITION ? std::min(0.05, grace_sec) : grace_sec;

    RCLCPP_INFO(
      get_logger(),
      "Stopping %s pid %d (%s)",
      name.c_str(),
      pid,
      mode == StopMode::NORMAL_TRANSITION ? "normal transition" : "error/exit");
    kill(-pid, SIGINT);
    if (!waitForExit(pid, grace_sec)) {
      kill(-pid, SIGTERM);
      if (!waitForExit(pid, escalation_grace_sec)) {
        kill(-pid, SIGKILL);
        waitForExit(pid, escalation_grace_sec);
      }
    }
    publishStopCommand(mode);
  }

  bool waitForExit(pid_t pid, double timeout_sec)
  {
    const auto start = std::chrono::steady_clock::now();
    int status = 0;
    while (std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count() < timeout_sec) {
      const pid_t result = waitpid(pid, &status, WNOHANG);
      if (result == pid) {
        return true;
      }
      if (result < 0) {
        return true;
      }
      rclcpp::sleep_for(20ms);
    }
    return false;
  }

  void watchChildProcess()
  {
    if (
      current_child_pid_ <= 0 ||
      state_ == State::NAV_SHUTDOWN ||
      state_ == State::ERROR)
    {
      return;
    }

    int status = 0;
    const pid_t result = waitpid(current_child_pid_, &status, WNOHANG);
    if (result == current_child_pid_) {
      const std::string name = current_child_name_;
      current_child_pid_ = -1;
      current_child_name_.clear();
      enterError("child process exited unexpectedly: " + name);
    }
  }

  void publishStopCommand(StopMode mode)
  {
    if (!cmd_vel_pub_) {
      return;
    }

    const bool should_publish =
      mode == StopMode::NORMAL_TRANSITION ?
      publish_stop_on_normal_transition_ :
      publish_stop_on_error_;
    const int repeats =
      mode == StopMode::NORMAL_TRANSITION ?
      normal_stop_publish_repeats_ :
      error_stop_publish_repeats_;

    if (!should_publish || repeats <= 0) {
      return;
    }

    geometry_msgs::msg::Twist stop;
    for (int i = 0; i < repeats; ++i) {
      cmd_vel_pub_->publish(stop);
      if (stop_publish_interval_sec_ > 0.0 && i + 1 < repeats) {
        rclcpp::sleep_for(std::chrono::duration_cast<std::chrono::nanoseconds>(
          std::chrono::duration<double>(stop_publish_interval_sec_)));
      }
    }
  }

  void publishStatus(const std::string &status)
  {
    std_msgs::msg::String msg;
    msg.data = status;
    status_pub_->publish(msg);
    RCLCPP_INFO(get_logger(), "state=%s", status.c_str());
  }

  State state_{State::STARTING};

  std::string package_name_{"fusion_nav"};
  std::string config_relative_dir_{"config"};
  std::string ros2_executable_{"ros2"};
  std::string status_topic_{"/smart_car_state_machine/status"};
  std::string cmd_vel_topic_{"/cmd_vel"};
  std::string odom_topic_{"/odom"};
  double line_exit_x_{2.4};
  std::string qr_node_name_{"/qr_approach_reader"};
  std::string qr_result_param_{"last_qr_code_result"};
  double poll_qr_param_hz_{2.0};
  std::string multi_nav_status_topic_{"/multi_point_nav/status"};
  double normal_stop_grace_sec_{0.15};
  double error_stop_grace_sec_{1.0};
  bool publish_stop_on_normal_transition_{false};
  bool publish_stop_on_error_{true};
  int normal_stop_publish_repeats_{0};
  int error_stop_publish_repeats_{3};
  double stop_publish_interval_sec_{0.05};
  double nav_shutdown_timeout_sec_{5.0};
  bool start_yellow_before_nav_shutdown_done_{true};

  std::string line_executable_{"pure_line_follower"};
  std::string qr_executable_{"qr_approach_reader"};
  std::string multi_nav_executable_{"multi_point_nav"};
  std::string yellow_executable_{"yellow_channel"};
  std::string line_params_file_;
  std::string qr_params_file_;
  std::string multi_nav_params_file_;
  std::string yellow_params_file_;
  std::vector<std::string> nav_lifecycle_manager_services_{
    "/lifecycle_manager_navigation/manage_nodes"};

  pid_t current_child_pid_{-1};
  std::string current_child_name_;
  bool qr_param_request_pending_{false};
  bool multi_nav_became_active_{false};
  bool nav_shutdown_requests_sent_{false};
  bool nav_shutdown_failed_{false};
  bool nav_shutdown_complete_{false};
  std::size_t nav_shutdown_pending_{0};
  std::chrono::steady_clock::time_point nav_shutdown_started_at_{};
  std::vector<LifecycleClientState> nav_lifecycle_clients_;

  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr status_pub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr multi_nav_status_sub_;
  rclcpp::Client<rcl_interfaces::srv::GetParameters>::SharedPtr qr_param_client_;
  rclcpp::TimerBase::SharedPtr qr_poll_timer_;
  rclcpp::TimerBase::SharedPtr process_watch_timer_;
  rclcpp::TimerBase::SharedPtr nav_shutdown_timer_;
  rclcpp::TimerBase::SharedPtr start_timer_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<SmartCarStateMachine>());
  rclcpp::shutdown();
  return 0;
}
