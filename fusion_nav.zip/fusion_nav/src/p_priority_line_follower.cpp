/*
 * p_priority_line_follower

 * 功能说明:
 * - 订阅 YOLO/AI 感知结果话题，默认 dnn_node_sample。
 * - 默认启用 P 点优先: 同一帧有有效 P 时，使用面积最大的 P 框中心做 PID 控制。
 * - 没有有效 P 时，回退到原 pure_line_follower 的 point 巡线逻辑。
 * - P 标签、point 标签、置信度阈值、是否启用 P 优先均可由 YAML 控制。
 */

#include <algorithm>
#include <chrono>
#include <cmath>
#include <functional>
#include <memory>
#include <string>

#include "ai_msgs/msg/perception_targets.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"

namespace
{
geometry_msgs::msg::Twist makeStoppedTwist()
{
  geometry_msgs::msg::Twist twist;
  twist.linear.x = 0.0;
  twist.angular.z = 0.0;
  return twist;
}
}  // namespace

class PPriorityLineFollower : public rclcpp::Node
{
public:
  PPriorityLineFollower()
  : Node("p_priority_line_follower")
  {
    loadParameters();

    cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);
    target_sub_ = create_subscription<ai_msgs::msg::PerceptionTargets>(
      input_topic_,
      10,
      std::bind(&PPriorityLineFollower::targetCallback, this, std::placeholders::_1));
    const auto publish_period = std::chrono::duration<double>(1.0 / cmd_vel_publish_hz_);
    cmd_timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(publish_period),
      std::bind(&PPriorityLineFollower::cmdTimerCallback, this));

    RCLCPP_INFO(
      get_logger(),
      "p_priority_line_follower started: input_topic=%s cmd_vel_topic=%s image_width=%d "
      "publish_hz=%.1f p_priority=%s p_label=%s point_label=%s",
      input_topic_.c_str(),
      cmd_vel_topic_.c_str(),
      image_width_,
      cmd_vel_publish_hz_,
      enable_p_priority_ ? "true" : "false",
      p_label_.c_str(),
      point_label_.c_str());
  }

private:
  struct FollowTarget
  {
    int center_x{0};
    int center_y{0};
    int area{0};
    float confidence{0.0F};
    std::string label;
  };

  void loadParameters()
  {
    input_topic_ = declare_parameter<std::string>("input_topic", input_topic_);
    cmd_vel_topic_ = declare_parameter<std::string>("cmd_vel_topic", cmd_vel_topic_);
    image_width_ = std::max(1, static_cast<int>(declare_parameter<int>("image_width", image_width_)));
    confidence_threshold_ = declare_parameter<double>("confidence_threshold", confidence_threshold_);
    point_label_ = declare_parameter<std::string>("point_label", point_label_);
    point_confidence_threshold_ =
      declare_parameter<double>("point_confidence_threshold", confidence_threshold_);
    enable_p_priority_ = declare_parameter<bool>("enable_p_priority", enable_p_priority_);
    p_label_ = declare_parameter<std::string>("p_label", p_label_);
    p_confidence_threshold_ =
      declare_parameter<double>("p_confidence_threshold", p_confidence_threshold_);
    linear_speed_ = std::max(0.0, declare_parameter<double>("linear_speed", linear_speed_));
    angular_ratio_ = std::max(0.0, declare_parameter<double>("angular_ratio", angular_ratio_));
    max_angular_velocity_ = std::max(
      0.0, declare_parameter<double>("max_angular_velocity", max_angular_velocity_));
    cmd_vel_publish_hz_ = std::max(1.0, declare_parameter<double>("cmd_vel_publish_hz", cmd_vel_publish_hz_));
    dead_zone_px_ = std::max(0, static_cast<int>(declare_parameter<int>("dead_zone_px", dead_zone_px_)));
    kp_ = declare_parameter<double>("Kp", kp_);
    ki_ = declare_parameter<double>("Ki", ki_);
    kd_ = declare_parameter<double>("Kd", kd_);
    stop_on_lost_ = declare_parameter<bool>("stop_on_lost", stop_on_lost_);
  }

  void targetCallback(const ai_msgs::msg::PerceptionTargets::SharedPtr msg)
  {
    FollowTarget best_p;
    FollowTarget best_point;
    bool found_p = false;
    bool found_point = false;

    for (const auto &target : msg->targets) {
      if (target.rois.empty()) {
        continue;
      }

      const auto &roi = target.rois.front();
      const auto &rect = roi.rect;
      const int center_x = rect.x_offset + rect.width / 2;
      const int center_y = rect.y_offset + rect.height / 2;
      const int area = static_cast<int>(rect.width) * static_cast<int>(rect.height);

      if (enable_p_priority_ && target.type == p_label_) {
        if (roi.confidence <= p_confidence_threshold_) {
          continue;
        }
        if (!found_p || area > best_p.area) {
          best_p.center_x = center_x;
          best_p.center_y = center_y;
          best_p.area = area;
          best_p.confidence = roi.confidence;
          best_p.label = target.type;
          found_p = true;
        }
        continue;
      }

      if (target.type == point_label_) {
        if (roi.confidence <= point_confidence_threshold_) {
          continue;
        }
        if (!found_point || center_y < best_point.center_y) {
          best_point.center_x = center_x;
          best_point.center_y = center_y;
          best_point.area = area;
          best_point.confidence = roi.confidence;
          best_point.label = target.type;
          found_point = true;
        }
      }
    }

    if (found_p) {
      latest_target_ = best_p;
      has_latest_target_ = true;
      return;
    }

    if (found_point) {
      latest_target_ = best_point;
      has_latest_target_ = true;
      return;
    }

    has_latest_target_ = false;
  }

  void cmdTimerCallback()
  {
    if (!has_latest_target_) {
      handleLostTarget();
      return;
    }

    publishLineCommand(latest_target_);
  }

  void handleLostTarget()
  {
    resetPid();
    if (stop_on_lost_) {
      cmd_vel_pub_->publish(makeStoppedTwist());
    }

    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      1000,
      "no valid %s/%s target; %s",
      enable_p_priority_ ? p_label_.c_str() : "",
      point_label_.c_str(),
      stop_on_lost_ ? "publishing stop" : "keeping previous command");
  }

  void publishLineCommand(const FollowTarget &target)
  {
    const double image_center_x = static_cast<double>(image_width_) / 2.0;
    double error_px = image_center_x - static_cast<double>(target.center_x);
    if (std::abs(error_px) < static_cast<double>(dead_zone_px_)) {
      error_px = 0.0;
    }

    const double pid_error = angular_ratio_ * error_px / std::max(1.0, image_center_x);
    const rclcpp::Time now = get_clock()->now();
    double dt = pid_initialized_ ? (now - last_time_).seconds() : 0.05;
    if (dt <= 1e-6) {
      dt = 0.05;
    }

    error_sum_ += pid_error * dt;
    const double error_diff = pid_initialized_ ? (pid_error - last_error_) / dt : 0.0;
    const double output = kp_ * pid_error + ki_ * error_sum_ + kd_ * error_diff;
    const double angular_z = std::clamp(output, -max_angular_velocity_, max_angular_velocity_);

    last_error_ = pid_error;
    last_time_ = now;
    pid_initialized_ = true;

    geometry_msgs::msg::Twist twist;
    twist.linear.x = linear_speed_;
    twist.angular.z = angular_z;
    cmd_vel_pub_->publish(twist);

    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      500,
      "line follow: target=%s center=(%d,%d) area=%d conf=%.2f error_px=%.1f "
      "pid=%.3f linear=%.2f angular=%.2f",
      target.label.c_str(),
      target.center_x,
      target.center_y,
      target.area,
      target.confidence,
      error_px,
      pid_error,
      twist.linear.x,
      twist.angular.z);
  }

  void resetPid()
  {
    last_error_ = 0.0;
    error_sum_ = 0.0;
    pid_initialized_ = false;
  }

  std::string input_topic_{"dnn_node_sample"};
  std::string cmd_vel_topic_{"/cmd_vel"};
  int image_width_{640};
  double confidence_threshold_{0.7};
  std::string point_label_{"point"};
  double point_confidence_threshold_{0.7};
  bool enable_p_priority_{true};
  std::string p_label_{"P"};
  double p_confidence_threshold_{0.7};
  double linear_speed_{0.6};
  double angular_ratio_{0.8};
  double max_angular_velocity_{0.8};
  double cmd_vel_publish_hz_{20.0};
  int dead_zone_px_{30};
  double kp_{0.8};
  double ki_{0.0};
  double kd_{0.7};
  bool stop_on_lost_{true};

  double last_error_{0.0};
  double error_sum_{0.0};
  rclcpp::Time last_time_{0, 0, RCL_ROS_TIME};
  bool pid_initialized_{false};
  FollowTarget latest_target_;
  bool has_latest_target_{false};

  rclcpp::Subscription<ai_msgs::msg::PerceptionTargets>::SharedPtr target_sub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  rclcpp::TimerBase::SharedPtr cmd_timer_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<PPriorityLineFollower>());
  rclcpp::shutdown();
  return 0;
}
