/*
 * fusion_nav_state_machine
 *
 * 功能说明:
 * - 状态机启动后默认认为小车位于 P 点，立即启动 pure_line_follower 视觉巡线程序。
 * - 订阅 /odom，当 pose.pose.position.x 大于阈值时，停止巡线，启动 qr_approach_reader。
 * - 定时读取 /qr_approach_reader 节点参数 last_qr_code_result，非空时停止二维码靠近识别程序。
 * - 随后启动 multi_point_nav 多点导航程序，等待其状态话题反馈完成或失败。
 * - 每次状态切换都会停止上一阶段子进程，并发布 0 速度，避免多个程序同时抢 /cmd_vel。
 */

#include <csignal>
#include <cstdlib>
#include <string>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>

#include "ament_index_cpp/get_package_share_directory.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "rcl_interfaces/srv/get_parameters.hpp"
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

using namespace std::chrono_literals;

namespace
{
std::string fallbackSourceConfigPath(const std::string &filename)
{
  return "/home/wc/CH1/yellow_channel_ws/src/fusion_nav/config/" + filename;
}

std::string packageConfigPath(const std::string &filename)
{
  try {
    return ament_index_cpp::get_package_share_directory("fusion_nav") + "/config/" + filename;
  } catch (const std::exception &) {
    return fallbackSourceConfigPath(filename);
  }
}

std::string normalizeNodeName(const std::string &node_name)
{
  if (node_name.empty()) {
    return "/";
  }
  if (node_name.front() == '/') {
    return node_name;
  }
  return "/" + node_name;
}
}  // namespace

class FusionNavStateMachine : public rclcpp::Node
{
public:
  FusionNavStateMachine()
  : Node("fusion_nav_state_machine")
  {
    loadParameters();

    status_pub_ = create_publisher<std_msgs::msg::String>(
      status_topic_,
      rclcpp::QoS(10).reliable().transient_local());
    cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);
    odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
      odom_topic_,
      10,
      std::bind(&FusionNavStateMachine::odomCallback, this, std::placeholders::_1));
    multi_nav_status_sub_ = create_subscription<std_msgs::msg::String>(
      multi_nav_status_topic_,
      10,
      std::bind(&FusionNavStateMachine::multiNavStatusCallback, this, std::placeholders::_1));

    qr_param_client_ = create_client<rcl_interfaces::srv::GetParameters>(
      normalizeNodeName(qr_node_name_) + "/get_parameters");

    const auto poll_period = std::chrono::duration<double>(1.0 / poll_qr_param_hz_);
    qr_poll_timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(poll_period),
      std::bind(&FusionNavStateMachine::pollQrParameter, this));
    process_watch_timer_ = create_wall_timer(
      500ms,
      std::bind(&FusionNavStateMachine::watchChildProcess, this));
    start_timer_ = create_wall_timer(200ms, [this]() {
      start_timer_->cancel();
      enterLineFollowing();
    });

    publishStatus("starting");
    RCLCPP_INFO(get_logger(), "fusion_nav_state_machine started");
  }

  ~FusionNavStateMachine() override
  {
    stopCurrentProcess();
    publishStopCommand();
  }

private:
  enum class State
  {
    STARTING,
    LINE_FOLLOWING,
    QR_APPROACH,
    MULTI_POINT_NAV,
    DONE,
    ERROR
  };

  void loadParameters()
  {
    package_name_ = declare_parameter<std::string>("package_name", package_name_);
    ros2_executable_ = declare_parameter<std::string>("ros2_executable", ros2_executable_);
    status_topic_ = declare_parameter<std::string>("status_topic", status_topic_);
    cmd_vel_topic_ = declare_parameter<std::string>("cmd_vel_topic", cmd_vel_topic_);
    odom_topic_ = declare_parameter<std::string>("odom_topic", odom_topic_);
    line_exit_x_ = declare_parameter<double>("line_exit_x", line_exit_x_);
    qr_node_name_ = declare_parameter<std::string>("qr_node_name", qr_node_name_);
    qr_result_param_ = declare_parameter<std::string>("qr_result_param", qr_result_param_);
    poll_qr_param_hz_ = std::max(0.1, declare_parameter<double>("poll_qr_param_hz", poll_qr_param_hz_));
    multi_nav_status_topic_ =
      declare_parameter<std::string>("multi_nav_status_topic", multi_nav_status_topic_);
    stop_grace_sec_ = std::max(0.1, declare_parameter<double>("stop_grace_sec", stop_grace_sec_));
    publish_stop_on_transition_ =
      declare_parameter<bool>("publish_stop_on_transition", publish_stop_on_transition_);
    stop_publish_repeats_ = std::max(
      1,
      static_cast<int>(declare_parameter<int64_t>("stop_publish_repeats", stop_publish_repeats_)));
    stop_publish_interval_sec_ =
      std::max(0.0, declare_parameter<double>("stop_publish_interval_sec", stop_publish_interval_sec_));

    line_executable_ = declare_parameter<std::string>("line_executable", line_executable_);
    qr_executable_ = declare_parameter<std::string>("qr_executable", qr_executable_);
    multi_nav_executable_ =
      declare_parameter<std::string>("multi_nav_executable", multi_nav_executable_);

    line_params_file_ = declare_parameter<std::string>("line_params_file", "");
    qr_params_file_ = declare_parameter<std::string>("qr_params_file", "");
    multi_nav_params_file_ = declare_parameter<std::string>("multi_nav_params_file", "");
    if (line_params_file_.empty()) {
      line_params_file_ = packageConfigPath("pure_line_follower.yaml");
    }
    if (qr_params_file_.empty()) {
      qr_params_file_ = packageConfigPath("qr_approach_reader.yaml");
    }
    if (multi_nav_params_file_.empty()) {
      multi_nav_params_file_ = packageConfigPath("multi_point_nav.yaml");
    }
  }

  void enterLineFollowing()
  {
    if (state_ == State::LINE_FOLLOWING) {
      return;
    }
    stopCurrentProcess();
    state_ = State::LINE_FOLLOWING;
    publishStatus("line_following");
    startManagedProcess(line_executable_, line_params_file_);
  }

  void enterQrApproach()
  {
    if (state_ == State::QR_APPROACH) {
      return;
    }
    stopCurrentProcess();
    state_ = State::QR_APPROACH;
    qr_param_request_pending_ = false;
    publishStatus("qr_approach");
    startManagedProcess(qr_executable_, qr_params_file_);
  }

  void enterMultiPointNav()
  {
    if (state_ == State::MULTI_POINT_NAV) {
      return;
    }
    stopCurrentProcess();
    state_ = State::MULTI_POINT_NAV;
    publishStatus("multi_point_nav");
    startManagedProcess(multi_nav_executable_, multi_nav_params_file_);
  }

  void enterDone()
  {
    stopCurrentProcess();
    state_ = State::DONE;
    publishStopCommand();
    publishStatus("done");
  }

  void enterError(const std::string &reason)
  {
    stopCurrentProcess();
    state_ = State::ERROR;
    publishStopCommand();
    publishStatus("error");
    RCLCPP_ERROR(get_logger(), "State machine entered ERROR: %s", reason.c_str());
  }

  void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    if (state_ != State::LINE_FOLLOWING) {
      return;
    }

    const double x = msg->pose.pose.position.x;
    if (x > line_exit_x_) {
      RCLCPP_INFO(
        get_logger(),
        "odom x %.3f > %.3f, switching to QR approach",
        x,
        line_exit_x_);
      enterQrApproach();
    }
  }

  void pollQrParameter()
  {
    if (state_ != State::QR_APPROACH || qr_param_request_pending_) {
      return;
    }

    if (!qr_param_client_->service_is_ready()) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "waiting for QR parameter service: %s/get_parameters",
        normalizeNodeName(qr_node_name_).c_str());
      return;
    }

    auto request = std::make_shared<rcl_interfaces::srv::GetParameters::Request>();
    request->names.push_back(qr_result_param_);
    qr_param_request_pending_ = true;

    qr_param_client_->async_send_request(
      request,
      [this](rclcpp::Client<rcl_interfaces::srv::GetParameters>::SharedFuture future) {
        qr_param_request_pending_ = false;
        if (state_ != State::QR_APPROACH) {
          return;
        }

        const auto response = future.get();
        if (response->values.empty()) {
          return;
        }

        const std::string result = response->values.front().string_value;
        if (!result.empty()) {
          RCLCPP_INFO(get_logger(), "QR result parameter is non-empty: %s", result.c_str());
          enterMultiPointNav();
        }
      });
  }

  void multiNavStatusCallback(const std_msgs::msg::String::SharedPtr msg)
  {
    if (state_ != State::MULTI_POINT_NAV) {
      return;
    }

    const std::string &status = msg->data;
    if (status == "all_succeeded") {
      enterDone();
      return;
    }
    if (status == "stopped" || status.rfind("failed:", 0) == 0) {
      enterError("multi_point_nav status: " + status);
    }
  }

  std::vector<std::string> makeCommand(
    const std::string &executable,
    const std::string &params_file) const
  {
    std::vector<std::string> command{
      ros2_executable_,
      "run",
      package_name_,
      executable
    };
    if (!params_file.empty()) {
      command.push_back("--ros-args");
      command.push_back("--params-file");
      command.push_back(params_file);
    }
    return command;
  }

  bool startManagedProcess(const std::string &executable, const std::string &params_file)
  {
    const auto command = makeCommand(executable, params_file);
    const pid_t pid = fork();
    if (pid < 0) {
      enterError("fork failed while starting " + executable);
      return false;
    }

    if (pid == 0) {
      setpgid(0, 0);
      std::vector<char *> argv;
      argv.reserve(command.size() + 1);
      for (const auto &part : command) {
        argv.push_back(const_cast<char *>(part.c_str()));
      }
      argv.push_back(nullptr);
      execvp(argv.front(), argv.data());
      std::_Exit(127);
    }

    setpgid(pid, pid);
    current_child_pid_ = pid;
    current_child_name_ = executable;
    RCLCPP_INFO(get_logger(), "Started %s with pid %d", executable.c_str(), pid);
    return true;
  }

  void stopCurrentProcess()
  {
    if (current_child_pid_ <= 0) {
      return;
    }

    const pid_t pid = current_child_pid_;
    const std::string name = current_child_name_;
    current_child_pid_ = -1;
    current_child_name_.clear();

    RCLCPP_INFO(get_logger(), "Stopping %s pid %d", name.c_str(), pid);
    kill(-pid, SIGINT);
    if (!waitForExit(pid, stop_grace_sec_)) {
      kill(-pid, SIGTERM);
      if (!waitForExit(pid, stop_grace_sec_)) {
        kill(-pid, SIGKILL);
        waitForExit(pid, stop_grace_sec_);
      }
    }
    publishStopCommand();
  }

  bool waitForExit(pid_t pid, double timeout_sec)
  {
    const auto start = now();
    int status = 0;
    while ((now() - start).seconds() < timeout_sec) {
      const pid_t result = waitpid(pid, &status, WNOHANG);
      if (result == pid) {
        return true;
      }
      if (result < 0) {
        return true;
      }
      rclcpp::sleep_for(100ms);
    }
    return false;
  }

  void watchChildProcess()
  {
    if (current_child_pid_ <= 0 || state_ == State::DONE || state_ == State::ERROR) {
      return;
    }

    int status = 0;
    const pid_t result = waitpid(current_child_pid_, &status, WNOHANG);
    if (result == current_child_pid_) {
      const std::string name = current_child_name_;
      current_child_pid_ = -1;
      current_child_name_.clear();
      enterError("child process exited unexpectedly: " + name);
    }
  }

  void publishStopCommand()
  {
    if (!publish_stop_on_transition_ || !cmd_vel_pub_) {
      return;
    }

    geometry_msgs::msg::Twist stop;
    for (int i = 0; i < stop_publish_repeats_; ++i) {
      cmd_vel_pub_->publish(stop);
      if (stop_publish_interval_sec_ > 0.0 && i + 1 < stop_publish_repeats_) {
        rclcpp::sleep_for(std::chrono::duration_cast<std::chrono::nanoseconds>(
          std::chrono::duration<double>(stop_publish_interval_sec_)));
      }
    }
  }

  void publishStatus(const std::string &status)
  {
    std_msgs::msg::String msg;
    msg.data = status;
    status_pub_->publish(msg);
    RCLCPP_INFO(get_logger(), "state=%s", status.c_str());
  }

  State state_{State::STARTING};

  std::string package_name_{"fusion_nav"};
  std::string ros2_executable_{"ros2"};
  std::string status_topic_{"/fusion_nav_state_machine/status"};
  std::string cmd_vel_topic_{"/cmd_vel"};
  std::string odom_topic_{"/odom"};
  double line_exit_x_{2.4};
  std::string qr_node_name_{"/qr_approach_reader"};
  std::string qr_result_param_{"last_qr_code_result"};
  double poll_qr_param_hz_{2.0};
  std::string multi_nav_status_topic_{"/multi_point_nav/status"};
  double stop_grace_sec_{1.0};
  bool publish_stop_on_transition_{true};
  int stop_publish_repeats_{3};
  double stop_publish_interval_sec_{0.05};

  std::string line_executable_{"pure_line_follower"};
  std::string qr_executable_{"qr_approach_reader"};
  std::string multi_nav_executable_{"multi_point_nav"};
  std::string line_params_file_;
  std::string qr_params_file_;
  std::string multi_nav_params_file_;

  pid_t current_child_pid_{-1};
  std::string current_child_name_;
  bool qr_param_request_pending_{false};

  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr status_pub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr multi_nav_status_sub_;
  rclcpp::Client<rcl_interfaces::srv::GetParameters>::SharedPtr qr_param_client_;
  rclcpp::TimerBase::SharedPtr qr_poll_timer_;
  rclcpp::TimerBase::SharedPtr process_watch_timer_;
  rclcpp::TimerBase::SharedPtr start_timer_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<FusionNavStateMachine>());
  rclcpp::shutdown();
  return 0;
}
