/*
 * 节点功能说明：
 * 1. 下相机订阅 image_topic（默认 /nv12），识别黄色通道融合 mask，并对反相后的黑色区域按行提取左右边界。
 * 2. 中线计算沿用八邻域文档思想：l_border[y] 记录左边界，r_border[y] 记录右边界，
 *    center_line[y] = (l_border[y] + r_border[y]) >> 1。
 * 3. 使用中线前瞻点进行 PID 巡线控制，发布 geometry_msgs/msg/Twist 到 /cmd_vel。
 * 4. 上相机订阅 upper_image_topic（默认 /upper/nv12），只用于红字触发检测；检测到红字后按 course.direction
 *    执行一段固定转向，转向期间会覆盖 PID 输出。
 * 5. 节点只发布调试图像，不打开 OpenCV GUI，不使用滑条；所有阈值、PID、红字和话题参数由 YAML 配置。
 * 6. 运行本节点时请避免同时启动其它 /cmd_vel 发布巡线节点，防止速度命令互相抢占。
 */

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "cv_bridge/cv_bridge.h"
#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/image_encodings.hpp"
#include "sensor_msgs/msg/image.hpp"
#include "std_msgs/msg/header.hpp"

#include <opencv2/opencv.hpp>

namespace
{
  constexpr int kAndFusion = 0;
  constexpr int kOrFusion = 1;

  struct VisionConfig
  {
    int h_min{43};
    int h_max{179};
    int s_min{34};
    int s_max{255};
    int v_min{0};
    int v_max{255};
    int l_min{0};
    int l_max{255};
    int a_min{0};
    int a_max{255};
    int b_min{121};
    int b_max{255};
    int kernel_size{9};
    int min_area{2406};
    int dilate_iterations{3};
    int keep_largest{0};
    int fusion_mode{kOrFusion};
  };

  struct CenterlineConfig
  {
    int min_row_width_px{265};
    int row_step_px{6};
    int smooth_window{7};
    int thickness_px{2};
  };

  struct PidConfig
  {
    bool enabled{true};
    double linear_speed{0.22};
    double min_linear_speed{0.12};
    double angular_gain{0.9};
    double max_angular_z{0.8};
    int lookahead_y_px{-1};
    int lookahead_from_bottom_px{160};
    int deadband_px{8};
    double kp{0.8};
    double ki{0.0};
    double kd{0.7};
    double integral_limit{1.0};
    int min_centerline_points{5};
    bool stop_on_lost{true};
    double cmd_vel_publish_hz{30.0};
    std::string cmd_vel_topic{"/cmd_vel"};
  };

  struct CourseConfig
  {
    std::string direction{"cw"};
  };

  struct RedTextTriggerConfig
  {
    bool enabled{true};
    double start_delay_sec{3.0};
    double roi_width_ratio{0.35};
    double roi_height_ratio{0.35};
    int h1_min{0};
    int h1_max{10};
    int h2_min{160};
    int h2_max{179};
    int s_min{80};
    int s_max{255};
    int v_min{80};
    int v_max{255};
    int open_kernel{3};
    int close_kernel{5};
    int dilate_kernel{3};
    int min_red_pixels{80};
    double min_red_area_px{50.0};
    bool single_shot{true};
  };

  struct RedTurnConfig
  {
    bool enabled{true};
    double linear_speed{0.2};
    double angular_z_abs{0.6};
    double hold_sec{1.0};
  };

  struct DebugConfig
  {
    double print_interval_sec{0.5};
  };

  struct CenterlineResult
  {
    std::vector<int> l_border;
    std::vector<int> r_border;
    std::vector<int> center_line;
    std::vector<cv::Point> left_points;
    std::vector<cv::Point> right_points;
    std::vector<cv::Point> center_points;
    std::vector<cv::Point> smoothed_center_points;
    bool has_lookahead{false};
    cv::Point lookahead_point{-1, -1};
  };

  struct PidState
  {
    double last_error{0.0};
    double error_sum{0.0};
    std::chrono::steady_clock::time_point last_time{};
    bool initialized{false};
  };

  struct PidDebug
  {
    bool valid{false};
    bool stopped{true};
    int centerline_points{0};
    int target_x{-1};
    int target_y{-1};
    int error_px{0};
    double pid_error{0.0};
    double pid_p{0.0};
    double pid_i{0.0};
    double pid_d{0.0};
    double pid_output{0.0};
    double angular_z{0.0};
    double linear_x{0.0};
    std::string mode{"LOST"};
  };

  struct RedTextDebug
  {
    bool detection_allowed{false};
    bool detected{false};
    bool turn_triggered{false};
    bool turn_active{false};
    bool turn_consumed{false};
    cv::Rect roi;
    std::string direction{"cw"};
    int red_pixels{0};
    double largest_area_px{0.0};
    double turn_remaining_sec{0.0};
  };

  int makeOddKernelSize(int size)
  {
    size = std::max(size, 1);
    return size % 2 == 0 ? size + 1 : size;
  }

  int makeMedianKernelSize(int size)
  {
    return std::max(3, std::min(makeOddKernelSize(size), 7));
  }

  bool isValidCourseDirection(const std::string &direction)
  {
    return direction == "cw" || direction == "ccw";
  }

  geometry_msgs::msg::Twist makeStoppedTwist()
  {
    geometry_msgs::msg::Twist twist;
    twist.linear.x = 0.0;
    twist.angular.z = 0.0;
    return twist;
  }

  std::vector<cv::Point> pointsFromLine(const std::vector<int> &xs)
  {
    std::vector<cv::Point> points;
    points.reserve(xs.size());
    for (int y = static_cast<int>(xs.size()) - 1; y >= 0; --y)
    {
      const int x = xs[static_cast<std::size_t>(y)];
      if (x >= 0)
      {
        points.emplace_back(x, y);
      }
    }
    return points;
  }

  void drawLabel(cv::Mat &image, const std::string &text, const cv::Point &origin)
  {
    cv::putText(image, text, origin, cv::FONT_HERSHEY_SIMPLEX, 0.58, cv::Scalar(0, 0, 0), 4, cv::LINE_AA);
    cv::putText(image, text, origin, cv::FONT_HERSHEY_SIMPLEX, 0.58, cv::Scalar(255, 255, 255), 1, cv::LINE_AA);
  }
} // namespace

class YellowChannelNv12Centerline : public rclcpp::Node
{
public:
  YellowChannelNv12Centerline()
      : Node("yellow_channel_nv12_centerline")
  {
    node_start_time_ = std::chrono::steady_clock::now();
    loadParameters();
    createPublishers();
    createSubscriptions();

    RCLCPP_INFO(
        get_logger(),
        "yellow_channel_nv12_centerline started: image=%s upper=%s cmd_vel=%s debug=%s",
        image_topic_.c_str(),
        upper_image_topic_.c_str(),
        pid_config_.cmd_vel_topic.c_str(),
        centerline_image_topic_.c_str());
  }

private:
  int declareIntParameter(const std::string &name, int default_value)
  {
    const int64_t value = declare_parameter<int64_t>(name, static_cast<int64_t>(default_value));
    if (value > static_cast<int64_t>(std::numeric_limits<int>::max()))
    {
      return std::numeric_limits<int>::max();
    }
    if (value < static_cast<int64_t>(std::numeric_limits<int>::min()))
    {
      return std::numeric_limits<int>::min();
    }
    return static_cast<int>(value);
  }

  void loadParameters()
  {
    image_topic_ = declare_parameter<std::string>("image_topic", image_topic_);
    upper_image_topic_ = declare_parameter<std::string>("upper_image_topic", upper_image_topic_);
    centerline_image_topic_ =
        declare_parameter<std::string>("centerline_image_topic", centerline_image_topic_);
    frame_id_ = declare_parameter<std::string>("frame_id", frame_id_);

    vision_config_.h_min = std::clamp(declareIntParameter("h_min", vision_config_.h_min), 0, 179);
    vision_config_.h_max = std::clamp(declareIntParameter("h_max", vision_config_.h_max), 0, 179);
    vision_config_.s_min = std::clamp(declareIntParameter("s_min", vision_config_.s_min), 0, 255);
    vision_config_.s_max = std::clamp(declareIntParameter("s_max", vision_config_.s_max), 0, 255);
    vision_config_.v_min = std::clamp(declareIntParameter("v_min", vision_config_.v_min), 0, 255);
    vision_config_.v_max = std::clamp(declareIntParameter("v_max", vision_config_.v_max), 0, 255);
    vision_config_.l_min = std::clamp(declareIntParameter("l_min", vision_config_.l_min), 0, 255);
    vision_config_.l_max = std::clamp(declareIntParameter("l_max", vision_config_.l_max), 0, 255);
    vision_config_.a_min = std::clamp(declareIntParameter("a_min", vision_config_.a_min), 0, 255);
    vision_config_.a_max = std::clamp(declareIntParameter("a_max", vision_config_.a_max), 0, 255);
    vision_config_.b_min = std::clamp(declareIntParameter("b_min", vision_config_.b_min), 0, 255);
    vision_config_.b_max = std::clamp(declareIntParameter("b_max", vision_config_.b_max), 0, 255);
    vision_config_.kernel_size = std::max(
        1, declareIntParameter("kernel_size", vision_config_.kernel_size));
    vision_config_.min_area = std::max(
        0, declareIntParameter("min_area", vision_config_.min_area));
    vision_config_.dilate_iterations = std::max(
        0, declareIntParameter("dilate_iterations", vision_config_.dilate_iterations));
    vision_config_.keep_largest = std::clamp(
        declareIntParameter("keep_largest", vision_config_.keep_largest), 0, 1);
    vision_config_.fusion_mode = std::clamp(
        declareIntParameter("fusion_mode", vision_config_.fusion_mode), kAndFusion, kOrFusion);

    centerline_config_.min_row_width_px = std::max(
        1, declareIntParameter("centerline.min_row_width_px", centerline_config_.min_row_width_px));
    centerline_config_.row_step_px = std::max(
        1, declareIntParameter("centerline.row_step_px", centerline_config_.row_step_px));
    centerline_config_.smooth_window = std::max(
        1, declareIntParameter("centerline.smooth_window", centerline_config_.smooth_window));
    centerline_config_.thickness_px = std::max(
        1, declareIntParameter("centerline.thickness_px", centerline_config_.thickness_px));

    pid_config_.enabled = declare_parameter<bool>("pid.enabled", pid_config_.enabled);
    pid_config_.linear_speed = std::max(
        0.0, declare_parameter<double>("pid.linear_speed", pid_config_.linear_speed));
    pid_config_.min_linear_speed = std::clamp(
        declare_parameter<double>("pid.min_linear_speed", pid_config_.min_linear_speed),
        0.0,
        pid_config_.linear_speed);
    pid_config_.angular_gain = std::max(
        0.0, declare_parameter<double>("pid.angular_gain", pid_config_.angular_gain));
    pid_config_.max_angular_z = std::max(
        0.0, declare_parameter<double>("pid.max_angular_z", pid_config_.max_angular_z));
    pid_config_.lookahead_y_px =
        declareIntParameter("pid.lookahead_y_px", pid_config_.lookahead_y_px);
    pid_config_.lookahead_from_bottom_px = std::max(
        0, declareIntParameter("pid.lookahead_from_bottom_px", pid_config_.lookahead_from_bottom_px));
    pid_config_.deadband_px = std::max(
        0, declareIntParameter("pid.deadband_px", pid_config_.deadband_px));
    pid_config_.kp = std::max(0.0, declare_parameter<double>("pid.kp", pid_config_.kp));
    pid_config_.ki = std::max(0.0, declare_parameter<double>("pid.ki", pid_config_.ki));
    pid_config_.kd = std::max(0.0, declare_parameter<double>("pid.kd", pid_config_.kd));
    pid_config_.integral_limit = std::max(
        0.0, declare_parameter<double>("pid.integral_limit", pid_config_.integral_limit));
    pid_config_.min_centerline_points = std::max(
        1, declareIntParameter("pid.min_centerline_points", pid_config_.min_centerline_points));
    pid_config_.stop_on_lost =
        declare_parameter<bool>("pid.stop_on_lost", pid_config_.stop_on_lost);
    pid_config_.cmd_vel_publish_hz = std::max(
        0.0, declare_parameter<double>("pid.cmd_vel_publish_hz", pid_config_.cmd_vel_publish_hz));
    pid_config_.cmd_vel_topic =
        declare_parameter<std::string>("pid.cmd_vel_topic", pid_config_.cmd_vel_topic);

    course_config_.direction =
        declare_parameter<std::string>("course.direction", course_config_.direction);
    if (!isValidCourseDirection(course_config_.direction))
    {
      RCLCPP_WARN(
          get_logger(),
          "course.direction only supports cw/ccw, got '%s'; using cw",
          course_config_.direction.c_str());
      course_config_.direction = "cw";
    }

    red_text_config_.enabled =
        declare_parameter<bool>("red_text_trigger.enabled", red_text_config_.enabled);
    red_text_config_.start_delay_sec = std::max(
        0.0, declare_parameter<double>("red_text_trigger.start_delay_sec", red_text_config_.start_delay_sec));
    red_text_config_.roi_width_ratio = std::clamp(
        declare_parameter<double>("red_text_trigger.roi_width_ratio", red_text_config_.roi_width_ratio),
        0.0,
        1.0);
    red_text_config_.roi_height_ratio = std::clamp(
        declare_parameter<double>("red_text_trigger.roi_height_ratio", red_text_config_.roi_height_ratio),
        0.0,
        1.0);
    red_text_config_.h1_min = std::clamp(
        declareIntParameter("red_text_trigger.h1_min", red_text_config_.h1_min), 0, 179);
    red_text_config_.h1_max = std::clamp(
        declareIntParameter("red_text_trigger.h1_max", red_text_config_.h1_max), 0, 179);
    red_text_config_.h2_min = std::clamp(
        declareIntParameter("red_text_trigger.h2_min", red_text_config_.h2_min), 0, 179);
    red_text_config_.h2_max = std::clamp(
        declareIntParameter("red_text_trigger.h2_max", red_text_config_.h2_max), 0, 179);
    red_text_config_.s_min = std::clamp(
        declareIntParameter("red_text_trigger.s_min", red_text_config_.s_min), 0, 255);
    red_text_config_.s_max = std::clamp(
        declareIntParameter("red_text_trigger.s_max", red_text_config_.s_max), 0, 255);
    red_text_config_.v_min = std::clamp(
        declareIntParameter("red_text_trigger.v_min", red_text_config_.v_min), 0, 255);
    red_text_config_.v_max = std::clamp(
        declareIntParameter("red_text_trigger.v_max", red_text_config_.v_max), 0, 255);
    red_text_config_.open_kernel = std::max(
        0, declareIntParameter("red_text_trigger.open_kernel", red_text_config_.open_kernel));
    red_text_config_.close_kernel = std::max(
        0, declareIntParameter("red_text_trigger.close_kernel", red_text_config_.close_kernel));
    red_text_config_.dilate_kernel = std::max(
        0, declareIntParameter("red_text_trigger.dilate_kernel", red_text_config_.dilate_kernel));
    red_text_config_.min_red_pixels = std::max(
        1, declareIntParameter("red_text_trigger.min_red_pixels", red_text_config_.min_red_pixels));
    red_text_config_.min_red_area_px = std::max(
        0.0, declare_parameter<double>("red_text_trigger.min_red_area_px", red_text_config_.min_red_area_px));
    red_text_config_.single_shot =
        declare_parameter<bool>("red_text_trigger.single_shot", red_text_config_.single_shot);

    red_turn_config_.enabled =
        declare_parameter<bool>("red_turn.enabled", red_turn_config_.enabled);
    red_turn_config_.linear_speed = std::max(
        0.0, declare_parameter<double>("red_turn.linear_speed", red_turn_config_.linear_speed));
    red_turn_config_.angular_z_abs = std::max(
        0.0, declare_parameter<double>("red_turn.angular_z_abs", red_turn_config_.angular_z_abs));
    red_turn_config_.hold_sec = std::max(
        0.0, declare_parameter<double>("red_turn.hold_sec", red_turn_config_.hold_sec));

    debug_config_.print_interval_sec = std::max(
        0.0, declare_parameter<double>("debug.print_interval_sec", debug_config_.print_interval_sec));
  }

  void createPublishers()
  {
    centerline_image_pub_ = create_publisher<sensor_msgs::msg::Image>(centerline_image_topic_, 10);
    cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(pid_config_.cmd_vel_topic, 10);
  }

  void createSubscriptions()
  {
    image_sub_ = create_subscription<sensor_msgs::msg::Image>(
        image_topic_,
        rclcpp::SensorDataQoS(),
        std::bind(&YellowChannelNv12Centerline::imageCallback, this, std::placeholders::_1));
    upper_image_sub_ = create_subscription<sensor_msgs::msg::Image>(
        upper_image_topic_,
        rclcpp::SensorDataQoS(),
        std::bind(&YellowChannelNv12Centerline::upperImageCallback, this, std::placeholders::_1));
  }

  void imageCallback(const sensor_msgs::msg::Image::ConstSharedPtr msg)
  {
    cv::Mat bgr;
    try
    {
      bgr = convertImageToBgr(msg);
    }
    catch (const std::exception &error)
    {
      RCLCPP_WARN_THROTTLE(
          get_logger(),
          *get_clock(),
          1000,
          "lower image conversion failed: %s",
          error.what());
      return;
    }

    if (bgr.empty())
    {
      RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000, "empty lower image");
      publishDriveCommand(makeStoppedTwist(), PidDebug{});
      return;
    }

    cv::Mat hsv_mask;
    cv::Mat lab_inv_mask;
    cv::Mat final_mask;
    processColorMasks(bgr, hsv_mask, lab_inv_mask, final_mask);

    cv::Mat black_mask;
    cv::bitwise_not(final_mask, black_mask);
    filterMaskComponents(black_mask, vision_config_.min_area, vision_config_.keep_largest != 0);

    const CenterlineResult centerline = extractCenterline(black_mask);
    const double black_area = totalContourArea(black_mask);

    PidDebug pid_debug;
    geometry_msgs::msg::Twist cmd = makePidCommand(black_mask, centerline.smoothed_center_points, &pid_debug);
    if (pid_debug.valid && pid_debug.mode == "PID")
    {
      last_valid_pid_cmd_ = cmd;
      has_last_valid_pid_cmd_ = true;
    }

    RedTextDebug red_debug = last_red_debug_;
    cmd = applyRedTurnOverride(cmd, &pid_debug, &red_debug);

    publishDriveCommand(cmd, pid_debug);

    cv::Mat debug_image = makeDebugImage(bgr, black_mask, centerline, black_area, pid_debug, red_debug);
    publishImage(debug_image, msg->header);
    printDebugThrottled(black_area, centerline, pid_debug, red_debug);
  }

  void upperImageCallback(const sensor_msgs::msg::Image::ConstSharedPtr msg)
  {
    cv::Mat upper_bgr;
    try
    {
      upper_bgr = convertImageToBgr(msg);
    }
    catch (const std::exception &error)
    {
      RCLCPP_WARN_THROTTLE(
          get_logger(),
          *get_clock(),
          1000,
          "upper image conversion failed: %s",
          error.what());
      return;
    }

    const auto now_time = std::chrono::steady_clock::now();
    RedTextDebug debug;
    debug.direction = course_config_.direction;
    debug.turn_consumed = red_turn_consumed_;
    debug.detection_allowed =
        std::chrono::duration<double>(now_time - node_start_time_).count() >=
        red_text_config_.start_delay_sec;
    debug.turn_active = isRedTurnActive(now_time);
    if (debug.turn_active)
    {
      debug.turn_remaining_sec =
          std::max(0.0, std::chrono::duration<double>(red_turn_until_ - now_time).count());
    }

    if (!upper_bgr.empty())
    {
      debug.roi = makeRedTextRoi(upper_bgr.size());
      if (red_text_config_.enabled && debug.detection_allowed)
      {
        debug = detectRedTextLikeRegion(upper_bgr);
        debug.detection_allowed = true;
        debug.turn_consumed = red_turn_consumed_;
      }
    }

    if (
        red_turn_config_.enabled &&
        red_text_config_.enabled &&
        debug.detected &&
        red_turn_config_.hold_sec > 0.0 &&
        (!red_text_config_.single_shot || !red_turn_consumed_))
    {
      red_turn_until_ = now_time + std::chrono::duration_cast<std::chrono::steady_clock::duration>(
                                       std::chrono::duration<double>(red_turn_config_.hold_sec));
      red_turn_direction_ = course_config_.direction;
      red_turn_consumed_ = true;
      debug.turn_triggered = true;
      debug.turn_active = true;
      debug.turn_consumed = true;
      debug.turn_remaining_sec = red_turn_config_.hold_sec;
      resetPidState();
    }

    last_red_debug_ = debug;
  }

  cv::Mat convertImageToBgr(const sensor_msgs::msg::Image::ConstSharedPtr &msg) const
  {
    const std::string &encoding = msg->encoding;
    if (encoding == sensor_msgs::image_encodings::BGR8 || encoding == "bgr8")
    {
      return cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8)->image.clone();
    }

    if (encoding == sensor_msgs::image_encodings::RGB8 || encoding == "rgb8")
    {
      cv::Mat rgb = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::RGB8)->image;
      cv::Mat bgr;
      cv::cvtColor(rgb, bgr, cv::COLOR_RGB2BGR);
      return bgr;
    }

    if (
        encoding == sensor_msgs::image_encodings::MONO8 ||
        encoding == sensor_msgs::image_encodings::TYPE_8UC1 ||
        encoding == "mono8" ||
        encoding == "8UC1")
    {
      cv::Mat gray = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::MONO8)->image;
      cv::Mat bgr;
      cv::cvtColor(gray, bgr, cv::COLOR_GRAY2BGR);
      return bgr;
    }

    if (encoding == "nv12" || encoding == "yuv420_nv12")
    {
      if (msg->width == 0 || msg->height == 0 || msg->step < msg->width)
      {
        throw std::runtime_error("invalid NV12 image size or step");
      }

      const int nv12_rows = static_cast<int>(msg->height + msg->height / 2);
      const size_t required_size =
          static_cast<size_t>(msg->step) * static_cast<size_t>(nv12_rows);
      if (msg->data.size() < required_size)
      {
        throw std::runtime_error("NV12 image data is shorter than expected");
      }

      cv::Mat nv12(
          nv12_rows,
          static_cast<int>(msg->width),
          CV_8UC1,
          const_cast<uint8_t *>(msg->data.data()),
          msg->step);
      cv::Mat bgr;
      cv::cvtColor(nv12, bgr, cv::COLOR_YUV2BGR_NV12);
      return bgr;
    }

    return cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8)->image.clone();
  }

  void processColorMasks(
      const cv::Mat &frame,
      cv::Mat &hsv_mask,
      cv::Mat &lab_inv_mask,
      cv::Mat &final_mask) const
  {
    cv::Mat filtered;
    cv::bilateralFilter(frame, filtered, 5, 50, 50);

    cv::Mat hsv;
    cv::cvtColor(filtered, hsv, cv::COLOR_BGR2HSV);
    cv::inRange(
        hsv,
        cv::Scalar(
            std::min(vision_config_.h_min, vision_config_.h_max),
            std::min(vision_config_.s_min, vision_config_.s_max),
            std::min(vision_config_.v_min, vision_config_.v_max)),
        cv::Scalar(
            std::max(vision_config_.h_min, vision_config_.h_max),
            std::max(vision_config_.s_min, vision_config_.s_max),
            std::max(vision_config_.v_min, vision_config_.v_max)),
        hsv_mask);
    denoiseMask(hsv_mask, false);

    cv::Mat lab;
    cv::cvtColor(filtered, lab, cv::COLOR_BGR2Lab);
    cv::inRange(
        lab,
        cv::Scalar(
            std::min(vision_config_.l_min, vision_config_.l_max),
            std::min(vision_config_.a_min, vision_config_.a_max),
            std::min(vision_config_.b_min, vision_config_.b_max)),
        cv::Scalar(
            std::max(vision_config_.l_min, vision_config_.l_max),
            std::max(vision_config_.a_min, vision_config_.a_max),
            std::max(vision_config_.b_min, vision_config_.b_max)),
        lab_inv_mask);
    denoiseMask(lab_inv_mask, false);
    cv::bitwise_not(lab_inv_mask, lab_inv_mask);
    denoiseMask(lab_inv_mask, false);

    if (vision_config_.fusion_mode == kAndFusion)
    {
      cv::bitwise_and(hsv_mask, lab_inv_mask, final_mask);
    }
    else
    {
      cv::bitwise_or(hsv_mask, lab_inv_mask, final_mask);
    }
    denoiseMask(final_mask, true);
  }

  void denoiseMask(cv::Mat &mask, bool final_stage) const
  {
    const int kernel_size = makeOddKernelSize(vision_config_.kernel_size);
    const cv::Mat kernel =
        cv::getStructuringElement(cv::MORPH_RECT, cv::Size(kernel_size, kernel_size));

    cv::medianBlur(mask, mask, makeMedianKernelSize(kernel_size));
    cv::morphologyEx(mask, mask, cv::MORPH_OPEN, kernel);
    cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);

    if (final_stage && vision_config_.dilate_iterations > 0)
    {
      cv::dilate(mask, mask, kernel, cv::Point(-1, -1), vision_config_.dilate_iterations);
      cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);
    }

    filterMaskComponents(mask, vision_config_.min_area, final_stage && vision_config_.keep_largest != 0);
  }

  void filterMaskComponents(cv::Mat &mask, int min_area, bool keep_largest) const
  {
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(mask.clone(), contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    cv::Mat cleaned = cv::Mat::zeros(mask.size(), CV_8UC1);
    int best_index = -1;
    double best_area = 0.0;

    for (std::size_t i = 0; i < contours.size(); ++i)
    {
      const double area = cv::contourArea(contours[i]);
      if (area < static_cast<double>(std::max(0, min_area)))
      {
        continue;
      }
      if (keep_largest)
      {
        if (area > best_area)
        {
          best_area = area;
          best_index = static_cast<int>(i);
        }
      }
      else
      {
        cv::drawContours(cleaned, contours, static_cast<int>(i), cv::Scalar(255), cv::FILLED);
      }
    }

    if (keep_largest && best_index >= 0)
    {
      cv::drawContours(cleaned, contours, best_index, cv::Scalar(255), cv::FILLED);
    }
    mask = cleaned;
  }

  CenterlineResult extractCenterline(const cv::Mat &mask) const
  {
    CenterlineResult result;
    if (mask.empty() || mask.type() != CV_8UC1)
    {
      return result;
    }

    result.l_border.assign(mask.rows, -1);
    result.r_border.assign(mask.rows, -1);
    result.center_line.assign(mask.rows, -1);

    int reference_center = mask.cols / 2;
    const int row_step = std::max(1, centerline_config_.row_step_px);
    for (int y = mask.rows - 1; y >= 0; y -= row_step)
    {
      int left = -1;
      int right = -1;
      if (!findBestRowSegment(mask.ptr<uchar>(y), mask.cols, reference_center, &left, &right))
      {
        continue;
      }

      const int center = (left + right) >> 1;
      result.l_border[y] = left;
      result.r_border[y] = right;
      result.center_line[y] = center;
      result.left_points.emplace_back(left, y);
      result.right_points.emplace_back(right, y);
      result.center_points.emplace_back(center, y);
      reference_center = center;
    }

    result.smoothed_center_points = smoothCenterline(result.center_points);
    if (const cv::Point *point = selectLookaheadPoint(
            result.smoothed_center_points.empty() ? result.center_points : result.smoothed_center_points,
            mask.rows))
    {
      result.has_lookahead = true;
      result.lookahead_point = *point;
    }
    return result;
  }

  bool findBestRowSegment(
      const uchar *row,
      int width,
      int reference_center,
      int *left,
      int *right) const
  {
    int best_left = -1;
    int best_right = -1;
    int best_score = std::numeric_limits<int>::min();
    const int min_width = std::max(1, centerline_config_.min_row_width_px);

    int x = 0;
    while (x < width)
    {
      while (x < width && row[x] == 0)
      {
        ++x;
      }
      if (x >= width)
      {
        break;
      }

      const int run_left = x;
      while (x < width && row[x] > 0)
      {
        ++x;
      }
      const int run_right = x - 1;
      const int run_width = run_right - run_left + 1;
      if (run_width < min_width)
      {
        continue;
      }

      const int run_center = (run_left + run_right) >> 1;
      int score = run_width * 4 - std::abs(run_center - reference_center);
      if (reference_center >= run_left && reference_center <= run_right)
      {
        score += width * 4;
      }
      if (score > best_score)
      {
        best_score = score;
        best_left = run_left;
        best_right = run_right;
      }
    }

    if (best_left < 0 || best_right < 0)
    {
      return false;
    }
    *left = best_left;
    *right = best_right;
    return true;
  }

  std::vector<cv::Point> smoothCenterline(const std::vector<cv::Point> &points) const
  {
    if (points.size() < 3U)
    {
      return points;
    }

    const int window = makeOddKernelSize(centerline_config_.smooth_window);
    if (window <= 1)
    {
      return points;
    }

    const int half = window / 2;
    std::vector<cv::Point> smoothed;
    smoothed.reserve(points.size());
    for (int i = 0; i < static_cast<int>(points.size()); ++i)
    {
      const int begin = std::max(0, i - half);
      const int end = std::min(static_cast<int>(points.size()) - 1, i + half);
      int sum_x = 0;
      int count = 0;
      for (int j = begin; j <= end; ++j)
      {
        sum_x += points[j].x;
        ++count;
      }
      smoothed.emplace_back(
          static_cast<int>(std::lround(static_cast<double>(sum_x) / static_cast<double>(count))),
          points[i].y);
    }
    return smoothed;
  }

  const cv::Point *selectLookaheadPoint(const std::vector<cv::Point> &points, int image_height) const
  {
    if (points.empty() || image_height <= 0)
    {
      return nullptr;
    }

    const int target_y = pid_config_.lookahead_y_px >= 0 ? std::clamp(pid_config_.lookahead_y_px, 0, image_height - 1) : std::clamp(image_height - 1 - pid_config_.lookahead_from_bottom_px, 0, image_height - 1);

    const cv::Point *best = &points.front();
    int best_distance = std::abs(best->y - target_y);
    for (const auto &point : points)
    {
      const int distance = std::abs(point.y - target_y);
      if (distance < best_distance)
      {
        best = &point;
        best_distance = distance;
      }
    }
    return best;
  }

  geometry_msgs::msg::Twist makePidCommand(
      const cv::Mat &mask,
      const std::vector<cv::Point> &centerline,
      PidDebug *debug)
  {
    PidDebug local_debug;
    local_debug.mode = "PID";
    local_debug.centerline_points = static_cast<int>(centerline.size());

    auto finish = [&](geometry_msgs::msg::Twist twist)
    {
      local_debug.linear_x = twist.linear.x;
      local_debug.angular_z = twist.angular.z;
      local_debug.stopped = std::abs(twist.linear.x) < 1e-6 && std::abs(twist.angular.z) < 1e-6;
      if (local_debug.stopped)
      {
        resetPidState();
      }
      if (debug != nullptr)
      {
        *debug = local_debug;
      }
      return twist;
    };

    if (!pid_config_.enabled)
    {
      local_debug.mode = "DISABLED";
      return finish(makeStoppedTwist());
    }

    if (mask.empty() || centerline.size() < static_cast<std::size_t>(pid_config_.min_centerline_points))
    {
      local_debug.mode = "LOST";
      local_debug.valid = pid_config_.stop_on_lost;
      return finish(makeStoppedTwist());
    }

    const cv::Point *target_ptr = selectLookaheadPoint(centerline, mask.rows);
    if (target_ptr == nullptr)
    {
      local_debug.mode = "LOST";
      local_debug.valid = pid_config_.stop_on_lost;
      return finish(makeStoppedTwist());
    }

    const cv::Point target = *target_ptr;
    const double image_center_x = static_cast<double>(mask.cols) / 2.0;
    const double raw_error = image_center_x - static_cast<double>(target.x);
    const double pid_error =
        std::abs(raw_error) < static_cast<double>(pid_config_.deadband_px) ? 0.0 : pid_config_.angular_gain * raw_error / std::max(1.0, image_center_x);
    double angular_z = applyPid(pid_error, &local_debug);
    angular_z = std::clamp(angular_z, -pid_config_.max_angular_z, pid_config_.max_angular_z);

    const double turn_ratio = pid_config_.max_angular_z > 1e-6 ? std::clamp(std::abs(angular_z) / pid_config_.max_angular_z, 0.0, 1.0) : 0.0;
    const double max_speed = std::max(0.0, pid_config_.linear_speed);
    const double min_speed = std::clamp(pid_config_.min_linear_speed, 0.0, max_speed);

    geometry_msgs::msg::Twist cmd;
    cmd.linear.x = max_speed - (max_speed - min_speed) * turn_ratio;
    cmd.angular.z = angular_z;

    local_debug.valid = true;
    local_debug.stopped = false;
    local_debug.target_x = target.x;
    local_debug.target_y = target.y;
    local_debug.error_px = static_cast<int>(std::lround(raw_error));
    local_debug.angular_z = angular_z;
    local_debug.linear_x = cmd.linear.x;
    return finish(cmd);
  }

  double applyPid(double pid_error, PidDebug *debug)
  {
    const auto now_time = std::chrono::steady_clock::now();
    double dt = 0.1;
    double error_diff = 0.0;
    if (pid_state_.initialized)
    {
      dt = std::chrono::duration<double>(now_time - pid_state_.last_time).count();
      if (dt <= 1e-6)
      {
        dt = 0.1;
      }
      error_diff = (pid_error - pid_state_.last_error) / dt;
    }
    else
    {
      pid_state_.initialized = true;
    }

    pid_state_.error_sum += pid_error * dt;
    if (pid_config_.integral_limit > 0.0)
    {
      pid_state_.error_sum =
          std::clamp(pid_state_.error_sum, -pid_config_.integral_limit, pid_config_.integral_limit);
    }

    const double p = pid_config_.kp * pid_error;
    const double i = pid_config_.ki * pid_state_.error_sum;
    const double d = pid_config_.kd * error_diff;
    const double output = p + i + d;

    pid_state_.last_error = pid_error;
    pid_state_.last_time = now_time;

    if (debug != nullptr)
    {
      debug->pid_error = pid_error;
      debug->pid_p = p;
      debug->pid_i = i;
      debug->pid_d = d;
      debug->pid_output = output;
    }
    return output;
  }

  void resetPidState()
  {
    pid_state_.last_error = 0.0;
    pid_state_.error_sum = 0.0;
    pid_state_.last_time = {};
    pid_state_.initialized = false;
  }

  geometry_msgs::msg::Twist applyRedTurnOverride(
      const geometry_msgs::msg::Twist &base_cmd,
      PidDebug *pid_debug,
      RedTextDebug *red_debug)
  {
    const auto now_time = std::chrono::steady_clock::now();
    if (!isRedTurnActive(now_time))
    {
      if (red_debug != nullptr)
      {
        red_debug->turn_active = false;
        red_debug->turn_remaining_sec = 0.0;
        red_debug->turn_consumed = red_turn_consumed_;
      }
      return base_cmd;
    }

    RedTextDebug local_red = red_debug != nullptr ? *red_debug : RedTextDebug{};
    local_red.turn_active = true;
    local_red.turn_consumed = red_turn_consumed_;
    local_red.direction = red_turn_direction_.empty() ? course_config_.direction : red_turn_direction_;
    local_red.turn_remaining_sec =
        std::max(0.0, std::chrono::duration<double>(red_turn_until_ - now_time).count());
    if (red_debug != nullptr)
    {
      *red_debug = local_red;
    }

    CourseConfig turn_course = course_config_;
    turn_course.direction = local_red.direction;
    geometry_msgs::msg::Twist cmd;
    cmd.linear.x = red_turn_config_.linear_speed;
    const double sign = turn_course.direction == "cw" ? 1.0 : -1.0;
    cmd.angular.z = sign * red_turn_config_.angular_z_abs;

    if (pid_debug != nullptr)
    {
      pid_debug->valid = true;
      pid_debug->stopped = false;
      pid_debug->linear_x = cmd.linear.x;
      pid_debug->angular_z = cmd.angular.z;
      pid_debug->mode = "RED_TURN " + turn_course.direction;
    }
    return cmd;
  }

  bool isRedTurnActive(const std::chrono::steady_clock::time_point &now_time) const
  {
    return now_time < red_turn_until_ && !red_turn_direction_.empty();
  }

  cv::Rect makeRedTextRoi(const cv::Size &image_size) const
  {
    if (image_size.width <= 0 || image_size.height <= 0)
    {
      return {};
    }

    const int width = std::clamp(
        static_cast<int>(std::lround(static_cast<double>(image_size.width) * red_text_config_.roi_width_ratio)),
        1,
        image_size.width);
    const int height = std::clamp(
        static_cast<int>(std::lround(static_cast<double>(image_size.height) * red_text_config_.roi_height_ratio)),
        1,
        image_size.height);
    const int x = course_config_.direction == "cw" ? 0 : image_size.width - width;
    return cv::Rect{x, 0, width, height};
  }

  RedTextDebug detectRedTextLikeRegion(const cv::Mat &image_bgr) const
  {
    RedTextDebug debug;
    debug.direction = course_config_.direction;
    debug.turn_consumed = red_turn_consumed_;
    debug.roi = makeRedTextRoi(image_bgr.size());
    if (image_bgr.empty() || debug.roi.empty())
    {
      return debug;
    }

    cv::Mat hsv;
    cv::cvtColor(image_bgr(debug.roi), hsv, cv::COLOR_BGR2HSV);

    cv::Mat mask_low;
    cv::Mat mask_high;
    cv::inRange(
        hsv,
        cv::Scalar(
            std::min(red_text_config_.h1_min, red_text_config_.h1_max),
            std::min(red_text_config_.s_min, red_text_config_.s_max),
            std::min(red_text_config_.v_min, red_text_config_.v_max)),
        cv::Scalar(
            std::max(red_text_config_.h1_min, red_text_config_.h1_max),
            std::max(red_text_config_.s_min, red_text_config_.s_max),
            std::max(red_text_config_.v_min, red_text_config_.v_max)),
        mask_low);
    cv::inRange(
        hsv,
        cv::Scalar(
            std::min(red_text_config_.h2_min, red_text_config_.h2_max),
            std::min(red_text_config_.s_min, red_text_config_.s_max),
            std::min(red_text_config_.v_min, red_text_config_.v_max)),
        cv::Scalar(
            std::max(red_text_config_.h2_min, red_text_config_.h2_max),
            std::max(red_text_config_.s_min, red_text_config_.s_max),
            std::max(red_text_config_.v_min, red_text_config_.v_max)),
        mask_high);

    cv::Mat red_mask;
    cv::bitwise_or(mask_low, mask_high, red_mask);
    red_mask = filterRedTextMask(red_mask);

    debug.red_pixels = cv::countNonZero(red_mask);
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(red_mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    for (const auto &contour : contours)
    {
      debug.largest_area_px = std::max(debug.largest_area_px, cv::contourArea(contour));
    }

    debug.detected =
        debug.red_pixels >= red_text_config_.min_red_pixels &&
        debug.largest_area_px >= red_text_config_.min_red_area_px;
    return debug;
  }

  cv::Mat filterRedTextMask(const cv::Mat &mask) const
  {
    cv::Mat filtered = mask.clone();
    const cv::Mat open_kernel = makeOptionalMorphKernel(red_text_config_.open_kernel);
    const cv::Mat close_kernel = makeOptionalMorphKernel(red_text_config_.close_kernel);
    const cv::Mat dilate_kernel = makeOptionalMorphKernel(red_text_config_.dilate_kernel);

    if (!open_kernel.empty())
    {
      cv::morphologyEx(filtered, filtered, cv::MORPH_OPEN, open_kernel);
    }
    if (!close_kernel.empty())
    {
      cv::morphologyEx(filtered, filtered, cv::MORPH_CLOSE, close_kernel);
    }
    if (!dilate_kernel.empty())
    {
      cv::dilate(filtered, filtered, dilate_kernel);
    }
    return filtered;
  }

  cv::Mat makeOptionalMorphKernel(int size) const
  {
    if (size <= 1)
    {
      return {};
    }
    size = makeOddKernelSize(size);
    return cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(size, size));
  }

  double totalContourArea(const cv::Mat &mask) const
  {
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(mask.clone(), contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    double area = 0.0;
    for (const auto &contour : contours)
    {
      area += cv::contourArea(contour);
    }
    return area;
  }

  cv::Mat makeDebugImage(
      const cv::Mat &bgr,
      const cv::Mat &black_mask,
      const CenterlineResult &centerline,
      double black_area,
      const PidDebug &pid_debug,
      const RedTextDebug &red_debug) const
  {
    cv::Mat output = bgr.clone();
    cv::Mat overlay = output.clone();
    overlay.setTo(cv::Scalar(0, 180, 180), black_mask);
    cv::addWeighted(overlay, 0.30, output, 0.70, 0.0, output);

    drawPolyline(output, pointsFromLine(centerline.l_border), cv::Scalar(0, 0, 255), 2);
    drawPolyline(output, pointsFromLine(centerline.r_border), cv::Scalar(255, 0, 0), 2);
    drawPolyline(output, centerline.center_points, cv::Scalar(0, 255, 0), 2);
    drawPolyline(output, centerline.smoothed_center_points, cv::Scalar(0, 220, 0), centerline_config_.thickness_px);

    if (centerline.has_lookahead)
    {
      cv::circle(output, centerline.lookahead_point, 8, cv::Scalar(255, 0, 255), 2, cv::LINE_AA);
    }
    if (pid_debug.target_x >= 0 && pid_debug.target_y >= 0)
    {
      cv::circle(output, cv::Point(pid_debug.target_x, pid_debug.target_y), 6, cv::Scalar(0, 255, 255), -1, cv::LINE_AA);
    }
    cv::line(
        output,
        cv::Point(output.cols / 2, 0),
        cv::Point(output.cols / 2, output.rows - 1),
        cv::Scalar(128, 128, 128),
        1,
        cv::LINE_AA);

    drawLabel(
        output,
        "black_area=" + std::to_string(static_cast<int>(black_area)) +
            " rows=" + std::to_string(centerline.center_points.size()),
        {18, 32});
    drawLabel(
        output,
        "mode=" + pid_debug.mode +
            " err=" + std::to_string(pid_debug.error_px) +
            " vx=" + std::to_string(pid_debug.linear_x).substr(0, 5) +
            " wz=" + std::to_string(pid_debug.angular_z).substr(0, 5),
        {18, 60});
    drawLabel(
        output,
        "red allowed=" + std::string(red_debug.detection_allowed ? "Y" : "N") +
            " detected=" + std::string(red_debug.detected ? "Y" : "N") +
            " px=" + std::to_string(red_debug.red_pixels) +
            " area=" + std::to_string(red_debug.largest_area_px).substr(0, 6),
        {18, 88});
    drawLabel(
        output,
        "red_turn=" + std::string(red_debug.turn_active ? "Y" : "N") +
            " dir=" + red_debug.direction +
            " remain=" + std::to_string(red_debug.turn_remaining_sec).substr(0, 4) +
            " consumed=" + std::string(red_debug.turn_consumed ? "Y" : "N"),
        {18, 116});
    return output;
  }

  void drawPolyline(
      cv::Mat &image,
      const std::vector<cv::Point> &points,
      const cv::Scalar &color,
      int thickness) const
  {
    if (points.size() >= 2U)
    {
      cv::polylines(
          image,
          std::vector<std::vector<cv::Point>>{points},
          false,
          color,
          thickness,
          cv::LINE_AA);
    }
    for (const auto &point : points)
    {
      cv::circle(image, point, 2, color, cv::FILLED, cv::LINE_AA);
    }
  }

  void publishImage(const cv::Mat &image, const std_msgs::msg::Header &input_header)
  {
    std_msgs::msg::Header header = input_header;
    header.stamp = now();
    if (header.frame_id.empty())
    {
      header.frame_id = frame_id_;
    }
    centerline_image_pub_->publish(
        *cv_bridge::CvImage(header, sensor_msgs::image_encodings::BGR8, image).toImageMsg());
  }

  void publishDriveCommand(const geometry_msgs::msg::Twist &cmd, const PidDebug &debug)
  {
    if (!debug.valid && !pid_config_.stop_on_lost)
    {
      return;
    }

    const auto now_time = std::chrono::steady_clock::now();
    if (pid_config_.cmd_vel_publish_hz > 0.0)
    {
      const auto min_period = std::chrono::duration<double>(1.0 / pid_config_.cmd_vel_publish_hz);
      if (
          last_cmd_vel_publish_ != std::chrono::steady_clock::time_point{} &&
          now_time - last_cmd_vel_publish_ <
              std::chrono::duration_cast<std::chrono::steady_clock::duration>(min_period))
      {
        return;
      }
    }
    last_cmd_vel_publish_ = now_time;
    cmd_vel_pub_->publish(cmd);
  }

  void printDebugThrottled(
      double black_area,
      const CenterlineResult &centerline,
      const PidDebug &pid_debug,
      const RedTextDebug &red_debug)
  {
    if (debug_config_.print_interval_sec <= 0.0)
    {
      return;
    }

    const auto now_time = std::chrono::steady_clock::now();
    const auto interval = std::chrono::duration_cast<std::chrono::steady_clock::duration>(
        std::chrono::duration<double>(debug_config_.print_interval_sec));
    if (last_debug_print_ != std::chrono::steady_clock::time_point{} &&
        now_time - last_debug_print_ < interval)
    {
      return;
    }
    last_debug_print_ = now_time;

    RCLCPP_INFO(
        get_logger(),
        "mode=%s black_area=%.0f rows=%zu target=(%d,%d) err=%d vx=%.2f wz=%.2f red_allowed=%s red_detected=%s red_px=%d red_area=%.1f red_turn=%s remain=%.2f",
        pid_debug.mode.c_str(),
        black_area,
        centerline.center_points.size(),
        pid_debug.target_x,
        pid_debug.target_y,
        pid_debug.error_px,
        pid_debug.linear_x,
        pid_debug.angular_z,
        red_debug.detection_allowed ? "true" : "false",
        red_debug.detected ? "true" : "false",
        red_debug.red_pixels,
        red_debug.largest_area_px,
        red_debug.turn_active ? "true" : "false",
        red_debug.turn_remaining_sec);
  }

  std::string image_topic_{"/nv12"};
  std::string upper_image_topic_{"/upper/nv12"};
  std::string centerline_image_topic_{"/yellow_channel_nv12_centerline/centerline_image"};
  std::string frame_id_{"camera"};

  VisionConfig vision_config_;
  CenterlineConfig centerline_config_;
  PidConfig pid_config_;
  CourseConfig course_config_;
  RedTextTriggerConfig red_text_config_;
  RedTurnConfig red_turn_config_;
  DebugConfig debug_config_;

  PidState pid_state_;
  geometry_msgs::msg::Twist last_valid_pid_cmd_;
  bool has_last_valid_pid_cmd_{false};

  RedTextDebug last_red_debug_;
  bool red_turn_consumed_{false};
  std::string red_turn_direction_;
  std::chrono::steady_clock::time_point red_turn_until_{};
  std::chrono::steady_clock::time_point node_start_time_{};
  std::chrono::steady_clock::time_point last_cmd_vel_publish_{};
  std::chrono::steady_clock::time_point last_debug_print_{};

  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr image_sub_;
  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr upper_image_sub_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr centerline_image_pub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
};

int main(int argc, char *argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<YellowChannelNv12Centerline>());
  rclcpp::shutdown();
  return 0;
}
