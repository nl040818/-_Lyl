/*
 * qr_approach_reader
 *
 * 功能说明:
 * - 订阅相机图像话题，默认 /nv12，支持 NV12/NV21/Mono/BGR/RGB/BGRA/RGBA 输入。
 * - 使用 WeChatQRCode 检测二维码角点，计算二维码中心位置。
 * - 未解码成功但已检测到二维码位置时，按固定频率发布 /cmd_vel，让小车低速朝二维码方向靠近。
 * - 二维码解码成功后，发布字符串到 /qr_code_result，写入参数服务器 last_qr_code_result，并在终端打印解码内容。
 * - 解码成功后持续发布 0 速度，保证小车停止。
 * - 不依赖 YOLO 二维码框，不做巡线、避障、返航。
 */

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cctype>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "ament_index_cpp/get_package_share_directory.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/image.hpp"
#include "std_msgs/msg/string.hpp"

#include <opencv2/opencv.hpp>
#include <opencv2/wechat_qrcode.hpp>

#ifdef QR_APPROACH_HAS_ZBAR
#include <zbar.h>
#endif

namespace
{
geometry_msgs::msg::Twist makeStoppedTwist()
{
  geometry_msgs::msg::Twist twist;
  twist.linear.x = 0.0;
  twist.angular.z = 0.0;
  return twist;
}
}  // namespace

class QrApproachReader : public rclcpp::Node
{
public:
  QrApproachReader()
  : Node("qr_approach_reader")
  {
    loadParameters();
    initWeChatModel();
    initZBarScanner();

    result_pub_ = create_publisher<std_msgs::msg::String>(output_topic_, 1);
    cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);
    image_sub_ = create_subscription<sensor_msgs::msg::Image>(
      input_topic_,
      rclcpp::SensorDataQoS(),
      std::bind(&QrApproachReader::imageCallback, this, std::placeholders::_1));

    const auto cmd_period = std::chrono::duration<double>(1.0 / cmd_vel_publish_hz_);
    cmd_timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(cmd_period),
      std::bind(&QrApproachReader::cmdTimerCallback, this));

    processing_thread_ = std::thread(&QrApproachReader::processingLoop, this);

    RCLCPP_INFO(
      get_logger(),
      "qr_approach_reader started: input=%s result=%s cmd_vel=%s publish_hz=%.1f",
      input_topic_.c_str(),
      output_topic_.c_str(),
      cmd_vel_topic_.c_str(),
      cmd_vel_publish_hz_);
  }

  ~QrApproachReader() override
  {
    {
      std::lock_guard<std::mutex> lock(queue_mutex_);
      stop_processing_ = true;
    }
    queue_cv_.notify_all();

    if (processing_thread_.joinable()) {
      processing_thread_.join();
    }
  }

private:
  struct QrLocation
  {
    bool valid{false};
    double center_x{0.0};
    double center_y{0.0};
    int image_width{0};
    int image_height{0};
  };

  struct DecodeResult
  {
    bool decoded{false};
    bool located{false};
    std::string text;
    QrLocation location;
  };

  void loadParameters()
  {
    model_path_ = declare_parameter<std::string>("model_path", model_path_);
    if (model_path_.empty()) {
      model_path_ = defaultModelPath();
    }

    input_topic_ = declare_parameter<std::string>("input_topic", input_topic_);
    output_topic_ = declare_parameter<std::string>("output_topic", output_topic_);
    cmd_vel_topic_ = declare_parameter<std::string>("cmd_vel_topic", cmd_vel_topic_);
    declare_parameter<std::string>("last_qr_code_result", "");

    process_interval_s_ = std::max(0.0, declare_parameter<double>("process_interval_s", process_interval_s_));
    cmd_vel_publish_hz_ = std::max(1.0, declare_parameter<double>("cmd_vel_publish_hz", cmd_vel_publish_hz_));
    linear_speed_ = std::max(0.0, declare_parameter<double>("linear_speed", linear_speed_));
    angular_gain_ = std::max(0.0, declare_parameter<double>("angular_gain", angular_gain_));
    max_angular_z_ = std::max(0.0, declare_parameter<double>("max_angular_z", max_angular_z_));
    deadband_px_ = std::max(0, static_cast<int>(declare_parameter<int>("deadband_px", deadband_px_)));
    stop_on_lost_ = declare_parameter<bool>("stop_on_lost", stop_on_lost_);
    stop_after_decode_ = declare_parameter<bool>("stop_after_decode", stop_after_decode_);
    wechat_scale_ = declare_parameter<double>("wechat_scale", wechat_scale_);
    if (wechat_scale_ <= 0.0) {
      wechat_scale_ = 1.0;
    }
    wechat_full_resolution_retry_ =
      declare_parameter<bool>("wechat_full_resolution_retry", wechat_full_resolution_retry_);
    zbar_qrcode_only_ = declare_parameter<bool>("zbar_qrcode_only", zbar_qrcode_only_);
  }

  std::string defaultModelPath() const
  {
    try {
      return ament_index_cpp::get_package_share_directory("fusion_nav") + "/model";
    } catch (const std::exception &) {
      return "/home/wc/CH1/yellow_channel_ws/src/fusion_nav/model";
    }
  }

  void initWeChatModel()
  {
    std::string path = model_path_;
    if (!path.empty() && path.back() != '/') {
      path += '/';
    }

    const std::string detect_prototxt = path + "detect.prototxt";
    const std::string detect_caffe_model = path + "detect.caffemodel";
    const std::string sr_prototxt = path + "sr.prototxt";
    const std::string sr_caffe_model = path + "sr.caffemodel";

    try {
      wechat_detector_ = cv::makePtr<cv::wechat_qrcode::WeChatQRCode>(
        detect_prototxt, detect_caffe_model, sr_prototxt, sr_caffe_model);
      RCLCPP_INFO(get_logger(), "WeChatQRCode model loaded from %s", model_path_.c_str());
    } catch (const cv::Exception &error) {
      RCLCPP_ERROR(get_logger(), "WeChatQRCode model load failed: %s", error.what());
    } catch (const std::exception &error) {
      RCLCPP_ERROR(get_logger(), "WeChatQRCode model load failed: %s", error.what());
    }
  }

  void initZBarScanner()
  {
#ifdef QR_APPROACH_HAS_ZBAR
    try {
      if (zbar_qrcode_only_) {
        zbar_scanner_.set_config(zbar::ZBAR_NONE, zbar::ZBAR_CFG_ENABLE, 0);
        zbar_scanner_.set_config(zbar::ZBAR_QRCODE, zbar::ZBAR_CFG_ENABLE, 1);
      } else {
        zbar_scanner_.set_config(zbar::ZBAR_NONE, zbar::ZBAR_CFG_ENABLE, 1);
      }
      RCLCPP_INFO(get_logger(), "ZBar scanner enabled");
    } catch (const std::exception &error) {
      RCLCPP_ERROR(get_logger(), "ZBar initialization failed: %s", error.what());
    }
#else
    RCLCPP_WARN(get_logger(), "ZBar development files not found at build time; using WeChatQRCode only");
#endif
  }

  void imageCallback(const sensor_msgs::msg::Image::SharedPtr msg)
  {
    if (stop_after_decode_ && decoded_.load()) {
      return;
    }

    const auto now = this->now();
    if ((now - last_image_time_).seconds() < process_interval_s_) {
      return;
    }
    last_image_time_ = now;

    {
      std::lock_guard<std::mutex> lock(queue_mutex_);
      latest_frame_ = msg;
      has_new_frame_ = true;
    }
    queue_cv_.notify_one();
  }

  void processingLoop()
  {
    while (true) {
      sensor_msgs::msg::Image::SharedPtr frame;
      {
        std::unique_lock<std::mutex> lock(queue_mutex_);
        queue_cv_.wait(lock, [this] {
          return has_new_frame_ || stop_processing_;
        });

        if (stop_processing_) {
          return;
        }

        frame = latest_frame_;
        has_new_frame_ = false;
      }

      if (frame) {
        processImage(frame);
      }
    }
  }

  void processImage(const sensor_msgs::msg::Image::SharedPtr &msg)
  {
    cv::Mat gray;
    if (!extractGrayImage(msg, gray)) {
      clearLocation();
      return;
    }

    DecodeResult result = decodeWithZBar(gray);
    if (!result.decoded) {
      result = decodeWithWeChat(gray);
    }

    if (
      !result.decoded &&
      wechat_full_resolution_retry_ &&
      std::abs(wechat_scale_ - 1.0) > 1e-6)
    {
      result = decodeWithWeChat(gray, 1.0);
    }

    if (result.located) {
      updateLocation(result.location);
    } else {
      clearLocation();
    }

    if (result.decoded) {
      publishDecodedResult(result.text);
    }
  }

  std::string normalizeEncoding(std::string encoding) const
  {
    std::transform(
      encoding.begin(),
      encoding.end(),
      encoding.begin(),
      [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return encoding;
  }

  bool extractGrayImage(const sensor_msgs::msg::Image::SharedPtr &msg, cv::Mat &gray)
  {
    if (!msg) {
      return false;
    }

    const std::string encoding = normalizeEncoding(msg->encoding);
    const int width = static_cast<int>(msg->width);
    const int height = static_cast<int>(msg->height);
    const size_t step = msg->step > 0 ? msg->step : msg->width;

    if (width <= 0 || height <= 0 || step < static_cast<size_t>(width)) {
      RCLCPP_ERROR(get_logger(), "invalid image size: %dx%d step=%zu", width, height, step);
      return false;
    }

    if (encoding == "nv12" || encoding == "nv21" || encoding == "mono8" || encoding == "8uc1") {
      const size_t required_size = step * static_cast<size_t>(height);
      if (msg->data.size() < required_size) {
        RCLCPP_ERROR(
          get_logger(),
          "invalid %s image data size: %zu, expected at least %zu",
          msg->encoding.c_str(),
          msg->data.size(),
          required_size);
        return false;
      }

      cv::Mat gray_view(height, width, CV_8UC1, const_cast<uint8_t *>(msg->data.data()), step);
      gray = gray_view.clone();
      return true;
    }

    if (encoding == "bgr8" || encoding == "rgb8" || encoding == "bgra8" || encoding == "rgba8") {
      const int channels = (encoding == "bgr8" || encoding == "rgb8") ? 3 : 4;
      const size_t min_step = static_cast<size_t>(width) * static_cast<size_t>(channels);
      const size_t required_size = step * static_cast<size_t>(height);
      if (step < min_step || msg->data.size() < required_size) {
        RCLCPP_ERROR(get_logger(), "invalid %s image buffer", msg->encoding.c_str());
        return false;
      }

      const int type = channels == 3 ? CV_8UC3 : CV_8UC4;
      cv::Mat color(height, width, type, const_cast<uint8_t *>(msg->data.data()), step);
      int code = cv::COLOR_BGR2GRAY;
      if (encoding == "rgb8") {
        code = cv::COLOR_RGB2GRAY;
      } else if (encoding == "bgra8") {
        code = cv::COLOR_BGRA2GRAY;
      } else if (encoding == "rgba8") {
        code = cv::COLOR_RGBA2GRAY;
      }
      cv::cvtColor(color, gray, code);
      return true;
    }

    RCLCPP_ERROR(get_logger(), "unsupported image encoding: %s", msg->encoding.c_str());
    return false;
  }

  DecodeResult decodeWithZBar(const cv::Mat &gray)
  {
    DecodeResult result;
#ifdef QR_APPROACH_HAS_ZBAR
    try {
      zbar::Image zbar_image(gray.cols, gray.rows, "Y800", gray.data, gray.cols * gray.rows);
      const int count = zbar_scanner_.scan(zbar_image);
      if (count <= 0) {
        return result;
      }

      for (zbar::Image::SymbolIterator symbol = zbar_image.symbol_begin();
        symbol != zbar_image.symbol_end();
        ++symbol)
      {
        result.text = symbol->get_data();
        result.decoded = !result.text.empty();

        const unsigned int location_size = symbol->get_location_size();
        if (location_size > 0U) {
          double sum_x = 0.0;
          double sum_y = 0.0;
          for (unsigned int i = 0; i < location_size; ++i) {
            sum_x += static_cast<double>(symbol->get_location_x(i));
            sum_y += static_cast<double>(symbol->get_location_y(i));
          }
          result.located = true;
          result.location.valid = true;
          result.location.center_x = sum_x / static_cast<double>(location_size);
          result.location.center_y = sum_y / static_cast<double>(location_size);
          result.location.image_width = gray.cols;
          result.location.image_height = gray.rows;
        }
        return result;
      }
    } catch (const std::exception &error) {
      RCLCPP_ERROR(get_logger(), "ZBar decode failed: %s", error.what());
    }
#else
    (void)gray;
#endif
    return result;
  }

  DecodeResult decodeWithWeChat(const cv::Mat &gray, double scale = -1.0)
  {
    DecodeResult result;
    if (!wechat_detector_) {
      return result;
    }

    const double active_scale = scale > 0.0 ? scale : wechat_scale_;
    cv::Mat decode_image;
    if (std::abs(active_scale - 1.0) > 1e-6) {
      const int resized_width = std::max(1, static_cast<int>(std::lround(gray.cols * active_scale)));
      const int resized_height = std::max(1, static_cast<int>(std::lround(gray.rows * active_scale)));
      cv::resize(
        gray,
        decode_image,
        cv::Size(resized_width, resized_height),
        0,
        0,
        active_scale < 1.0 ? cv::INTER_AREA : cv::INTER_LINEAR);
    } else {
      decode_image = gray;
    }

    try {
      std::vector<cv::Mat> points;
      const std::vector<cv::String> decoded_info =
        wechat_detector_->detectAndDecode(decode_image, points);

      for (std::size_t i = 0; i < points.size(); ++i) {
        QrLocation location = locationFromPoints(points[i], active_scale, gray.cols, gray.rows);
        if (location.valid && !result.located) {
          result.located = true;
          result.location = location;
        }

        if (i < decoded_info.size() && !decoded_info[i].empty()) {
          result.decoded = true;
          result.text = decoded_info[i];
          if (location.valid) {
            result.located = true;
            result.location = location;
          }
          return result;
        }
      }

      for (const auto &info : decoded_info) {
        if (!info.empty()) {
          result.decoded = true;
          result.text = info;
          return result;
        }
      }
    } catch (const cv::Exception &error) {
      RCLCPP_ERROR(get_logger(), "WeChatQRCode decode failed: %s", error.what());
    }

    return result;
  }

  QrLocation locationFromPoints(
    const cv::Mat &points,
    double scale,
    int image_width,
    int image_height) const
  {
    QrLocation location;
    if (points.empty()) {
      return location;
    }

    cv::Mat point_matrix;
    points.convertTo(point_matrix, CV_32F);

    std::vector<cv::Point2f> extracted;
    if (point_matrix.channels() == 2) {
      for (int r = 0; r < point_matrix.rows; ++r) {
        for (int c = 0; c < point_matrix.cols; ++c) {
          extracted.push_back(point_matrix.at<cv::Point2f>(r, c));
        }
      }
    } else if (point_matrix.cols >= 2) {
      for (int r = 0; r < point_matrix.rows; ++r) {
        extracted.emplace_back(point_matrix.at<float>(r, 0), point_matrix.at<float>(r, 1));
      }
    } else if (point_matrix.rows >= 2) {
      for (int c = 0; c < point_matrix.cols; ++c) {
        extracted.emplace_back(point_matrix.at<float>(0, c), point_matrix.at<float>(1, c));
      }
    }

    if (extracted.empty()) {
      return location;
    }

    double sum_x = 0.0;
    double sum_y = 0.0;
    const double safe_scale = scale > 1e-6 ? scale : 1.0;
    for (const auto &point : extracted) {
      sum_x += static_cast<double>(point.x) / safe_scale;
      sum_y += static_cast<double>(point.y) / safe_scale;
    }

    location.valid = true;
    location.center_x = sum_x / static_cast<double>(extracted.size());
    location.center_y = sum_y / static_cast<double>(extracted.size());
    location.image_width = image_width;
    location.image_height = image_height;
    return location;
  }

  void updateLocation(const QrLocation &location)
  {
    std::lock_guard<std::mutex> lock(state_mutex_);
    latest_location_ = location;
    has_location_ = location.valid;
  }

  void clearLocation()
  {
    std::lock_guard<std::mutex> lock(state_mutex_);
    has_location_ = false;
  }

  void publishDecodedResult(const std::string &text)
  {
    if (text.empty()) {
      return;
    }

    bool first_decode = false;
    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      if (decoded_text_ != text) {
        first_decode = true;
      }
      decoded_text_ = text;
      if (stop_after_decode_) {
        decoded_.store(true);
      }
    }

    set_parameter(rclcpp::Parameter("last_qr_code_result", text));

    std_msgs::msg::String result_msg;
    result_msg.data = text;
    result_pub_->publish(result_msg);

    if (first_decode) {
      RCLCPP_INFO(get_logger(), "QR decoded successfully: %s", text.c_str());
    }

    cmd_vel_pub_->publish(makeStoppedTwist());
  }

  void cmdTimerCallback()
  {
    QrLocation location;
    bool has_location = false;
    const bool decoded = decoded_.load();

    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      location = latest_location_;
      has_location = has_location_;
    }

    if (decoded) {
      cmd_vel_pub_->publish(makeStoppedTwist());
      return;
    }

    if (!has_location || !location.valid || location.image_width <= 0) {
      if (stop_on_lost_) {
        cmd_vel_pub_->publish(makeStoppedTwist());
      }
      return;
    }

    const double image_center_x = static_cast<double>(location.image_width) / 2.0;
    double error_px = image_center_x - location.center_x;
    if (std::abs(error_px) < static_cast<double>(deadband_px_)) {
      error_px = 0.0;
    }

    const double normalized_error = error_px / std::max(1.0, image_center_x);
    const double angular_z = std::clamp(
      angular_gain_ * normalized_error,
      -max_angular_z_,
      max_angular_z_);

    geometry_msgs::msg::Twist twist;
    twist.linear.x = linear_speed_;
    twist.angular.z = angular_z;
    cmd_vel_pub_->publish(twist);
  }

  std::string model_path_;
  std::string input_topic_{"/nv12"};
  std::string output_topic_{"/qr_code_result"};
  std::string cmd_vel_topic_{"/cmd_vel"};
  double process_interval_s_{0.05};
  double cmd_vel_publish_hz_{20.0};
  double linear_speed_{0.12};
  double angular_gain_{0.6};
  double max_angular_z_{0.5};
  int deadband_px_{30};
  bool stop_on_lost_{true};
  bool stop_after_decode_{true};
  double wechat_scale_{0.5};
  bool wechat_full_resolution_retry_{true};
  bool zbar_qrcode_only_{true};

  rclcpp::Time last_image_time_{0, 0, RCL_ROS_TIME};
  std::atomic<bool> decoded_{false};
  std::string decoded_text_;

  std::mutex queue_mutex_;
  std::condition_variable queue_cv_;
  sensor_msgs::msg::Image::SharedPtr latest_frame_;
  bool has_new_frame_{false};
  bool stop_processing_{false};
  std::thread processing_thread_;

  std::mutex state_mutex_;
  QrLocation latest_location_;
  bool has_location_{false};

  cv::Ptr<cv::wechat_qrcode::WeChatQRCode> wechat_detector_;
#ifdef QR_APPROACH_HAS_ZBAR
  zbar::ImageScanner zbar_scanner_;
#endif

  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr image_sub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr result_pub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  rclcpp::TimerBase::SharedPtr cmd_timer_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<QrApproachReader>());
  rclcpp::shutdown();
  return 0;
}
