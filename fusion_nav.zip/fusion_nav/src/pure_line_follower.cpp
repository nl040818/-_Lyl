/*
 * pure_line_follower
 *
 * 功能说明:
 * - 订阅 YOLO/AI 感知结果话题，默认 dnn_node_sample。
 * - 只读取 type == "point" 的目标框，沿用 x5go.cpp 中的巡线目标来源。
 * - 多个 point 同时存在时，选择画面中最上方的 point 作为巡线目标。
 * - 根据 point 中心 x 与图像中心的偏差做 PID 控制，发布 /cmd_vel。
 * - /cmd_vel 按固定频率定时发布，默认 20Hz，与 x5go.cpp 中 50ms 控制循环保持一致。
 * - 不包含 tong 避障、P 停车点、qr 二维码、返航、sign4return、状态机和消息处理线程。
 */

#include <algorithm>
#include <chrono>
#include <cmath>
#include <functional>
#include <memory>
#include <string>

#include "ai_msgs/msg/perception_targets.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"

namespace
{
geometry_msgs::msg::Twist makeStoppedTwist()
{
  geometry_msgs::msg::Twist twist;
  twist.linear.x = 0.0;
  twist.angular.z = 0.0;
  return twist;
}
}  // namespace

class PureLineFollower : public rclcpp::Node
{
public:
  PureLineFollower()
  : Node("pure_line_follower")
  {
    loadParameters();

    cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);
    target_sub_ = create_subscription<ai_msgs::msg::PerceptionTargets>(
      input_topic_,
      10,
      std::bind(&PureLineFollower::targetCallback, this, std::placeholders::_1));
    const auto publish_period = std::chrono::duration<double>(1.0 / cmd_vel_publish_hz_);
    cmd_timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(publish_period),
      std::bind(&PureLineFollower::cmdTimerCallback, this));

    RCLCPP_INFO(
      get_logger(),
      "pure_line_follower started: input_topic=%s cmd_vel_topic=%s image_width=%d publish_hz=%.1f",
      input_topic_.c_str(),
      cmd_vel_topic_.c_str(),
      image_width_,
      cmd_vel_publish_hz_);
  }

private:
  struct PointTarget
  {
    int center_x{0};
    int center_y{0};
    float confidence{0.0F};
  };

  void loadParameters()
  {
    input_topic_ = declare_parameter<std::string>("input_topic", input_topic_);
    cmd_vel_topic_ = declare_parameter<std::string>("cmd_vel_topic", cmd_vel_topic_);
    image_width_ = std::max(1, static_cast<int>(declare_parameter<int>("image_width", image_width_)));
    confidence_threshold_ = declare_parameter<double>("confidence_threshold", confidence_threshold_);
    linear_speed_ = std::max(0.0, declare_parameter<double>("linear_speed", linear_speed_));
    angular_ratio_ = std::max(0.0, declare_parameter<double>("angular_ratio", angular_ratio_));
    max_angular_velocity_ = std::max(
      0.0, declare_parameter<double>("max_angular_velocity", max_angular_velocity_));
    cmd_vel_publish_hz_ = std::max(1.0, declare_parameter<double>("cmd_vel_publish_hz", cmd_vel_publish_hz_));
    dead_zone_px_ = std::max(0, static_cast<int>(declare_parameter<int>("dead_zone_px", dead_zone_px_)));
    kp_ = declare_parameter<double>("Kp", kp_);
    ki_ = declare_parameter<double>("Ki", ki_);
    kd_ = declare_parameter<double>("Kd", kd_);
    stop_on_lost_ = declare_parameter<bool>("stop_on_lost", stop_on_lost_);
  }

  void targetCallback(const ai_msgs::msg::PerceptionTargets::SharedPtr msg)
  {
    PointTarget best_point;
    bool found_point = false;

    for (const auto &target : msg->targets) {
      if (target.type != "point" || target.rois.empty()) {
        continue;
      }

      const auto &rect = target.rois.front().rect;
      const float confidence = target.rois.front().confidence;
      if (confidence <= confidence_threshold_) {
        continue;
      }

      const int center_x = rect.x_offset + rect.width / 2;
      const int center_y = rect.y_offset + rect.height / 2;
      if (!found_point || center_y < best_point.center_y) {
        best_point.center_x = center_x;
        best_point.center_y = center_y;
        best_point.confidence = confidence;
        found_point = true;
      }
    }

    if (!found_point) {
      has_latest_point_ = false;
      return;
    }

    latest_point_ = best_point;
    has_latest_point_ = true;
  }

  void cmdTimerCallback()
  {
    if (!has_latest_point_) {
      handleLostPoint();
      return;
    }

    publishLineCommand(latest_point_);
  }

  void handleLostPoint()
  {
    resetPid();
    if (stop_on_lost_) {
      cmd_vel_pub_->publish(makeStoppedTwist());
    }

    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      1000,
      "no valid point target; %s",
      stop_on_lost_ ? "publishing stop" : "keeping previous command");
  }

  void publishLineCommand(const PointTarget &point)
  {
    const double image_center_x = static_cast<double>(image_width_) / 2.0;
    double error_px = image_center_x - static_cast<double>(point.center_x);
    if (std::abs(error_px) < static_cast<double>(dead_zone_px_)) {
      error_px = 0.0;
    }

    const double pid_error = angular_ratio_ * error_px / std::max(1.0, image_center_x);
    const rclcpp::Time now = get_clock()->now();
    double dt = pid_initialized_ ? (now - last_time_).seconds() : 0.05;
    if (dt <= 1e-6) {
      dt = 0.05;
    }

    error_sum_ += pid_error * dt;
    const double error_diff = pid_initialized_ ? (pid_error - last_error_) / dt : 0.0;
    const double output = kp_ * pid_error + ki_ * error_sum_ + kd_ * error_diff;
    const double angular_z = std::clamp(output, -max_angular_velocity_, max_angular_velocity_);

    last_error_ = pid_error;
    last_time_ = now;
    pid_initialized_ = true;

    geometry_msgs::msg::Twist twist;
    twist.linear.x = linear_speed_;
    twist.angular.z = angular_z;
    cmd_vel_pub_->publish(twist);

    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      500,
      "line follow: point=(%d,%d) conf=%.2f error_px=%.1f pid=%.3f linear=%.2f angular=%.2f",
      point.center_x,
      point.center_y,
      point.confidence,
      error_px,
      pid_error,
      twist.linear.x,
      twist.angular.z);
  }

  void resetPid()
  {
    last_error_ = 0.0;
    error_sum_ = 0.0;
    pid_initialized_ = false;
  }

  std::string input_topic_{"dnn_node_sample"};
  std::string cmd_vel_topic_{"/cmd_vel"};
  int image_width_{640};
  double confidence_threshold_{0.7};
  double linear_speed_{0.6};
  double angular_ratio_{0.8};
  double max_angular_velocity_{0.8};
  double cmd_vel_publish_hz_{20.0};
  int dead_zone_px_{30};
  double kp_{0.8};
  double ki_{0.0};
  double kd_{0.7};
  bool stop_on_lost_{true};

  double last_error_{0.0};
  double error_sum_{0.0};
  rclcpp::Time last_time_{0, 0, RCL_ROS_TIME};
  bool pid_initialized_{false};
  PointTarget latest_point_;
  bool has_latest_point_{false};

  rclcpp::Subscription<ai_msgs::msg::PerceptionTargets>::SharedPtr target_sub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  rclcpp::TimerBase::SharedPtr cmd_timer_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<PureLineFollower>());
  rclcpp::shutdown();
  return 0;
}
