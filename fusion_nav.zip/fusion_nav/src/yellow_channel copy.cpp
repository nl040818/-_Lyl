/*
 * single_cetnerline_param_node
 *
 * 功能说明:
 * - 订阅相机图像话题，默认 /nv12，支持 BGR/RGB/Mono/NV12 输入。
 * - 在 ROI 内进行 HSV 与 Lab 阈值分割，融合得到最终 mask，再提取通道边线和中线。
 * - 使用中线目标点进行 PID 巡线控制，发布 geometry_msgs/Twist 到 /cmd_vel。
 * - 只发布轻量调试图像: track_mask 与 dashboard，不发布 raw/crop/hsv/lab/final/result 等中间图像话题。
 * - 通过 ROS2 参数服务器读取 course.direction 等参数，在启动前期给中线加入一次入口偏置:
 *   cw 表示顺时针，目标中线左偏；ccw 表示逆时针，目标中线右偏。
 */

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "cv_bridge/cv_bridge.h"
#include "geometry_msgs/msg/twist.hpp"
#include "rcl_interfaces/msg/set_parameters_result.hpp"
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/image_encodings.hpp"
#include "sensor_msgs/msg/image.hpp"
#include "std_msgs/msg/header.hpp"

#include <opencv2/opencv.hpp>

using namespace std::chrono_literals;

namespace
{
constexpr int kAndFusion = 0;
constexpr int kOrFusion = 1;

struct TrackConfig
{
  bool dark_region{true};
  int dark_threshold{128};
  double min_area{2621.0};
  int min_width_px{30};
  int min_height_px{20};
  int line_thickness_px{2};
};

struct CenterlineConfig
{
  int row_step_px{4};
  int min_row_width_px{30};
  int smooth_window{7};
  int thickness_px{3};
  bool cross_guard_enabled{true};
  int cross_min_rows{1};
  bool hold_last_cmd_on_cross{true};
};

struct PidConfig
{
  bool enabled{true};
  double linear_speed{0.22};
  double min_linear_speed{0.12};
  double angular_gain{0.9};
  double max_angular_z{0.8};
  int lookahead_y_px{-1};
  int lookahead_from_bottom_px{120};
  int deadband_px{8};
  double kp{0.8};
  double ki{0.0};
  double kd{0.7};
  double integral_limit{1.0};
  int min_centerline_points{5};
  bool stop_on_lost{true};
  double cmd_vel_publish_hz{30.0};
  std::string cmd_vel_topic{"/cmd_vel"};
};

struct DebugConfig
{
  bool publish_images{true};
  bool publish_dashboard{true};
  double print_interval_sec{0.5};
};

struct CourseConfig
{
  std::string direction{"cw"};
  int entry_bias_offset_px{10};
  double entry_bias_duration_sec{1.5};
  bool entry_bias_enabled{true};
};

struct PidState
{
  double last_error{0.0};
  double error_sum{0.0};
  std::chrono::steady_clock::time_point last_time{};
  bool initialized{false};
};

struct PidDebug
{
  bool valid{false};
  bool stopped{true};
  int centerline_points{0};
  int target_x{-1};
  int target_y{-1};
  int error_px{0};
  double pid_error{0.0};
  double pid_p{0.0};
  double pid_i{0.0};
  double pid_d{0.0};
  double pid_output{0.0};
  double angular_z{0.0};
  double linear_x{0.0};
  std::string mode{"LOST"};
};

struct LineTrackResult
{
  std::vector<int> left_boundary;
  std::vector<int> right_boundary;
  std::vector<int> center_line;
  int target_center_x{0};
  int error{0};
  int valid_rows{0};
  int crossed_rows{0};
  bool crossed{false};
  bool lost{true};
};

int makeOddKernelSize(int size)
{
  size = std::max(size, 1);
  if (size % 2 == 0) {
    ++size;
  }
  return size;
}

int makeMedianKernelSize(int size)
{
  return std::max(3, std::min(makeOddKernelSize(size), 7));
}

void drawLabel(cv::Mat &image, const std::string &text, const cv::Point &origin)
{
  cv::putText(image, text, origin, cv::FONT_HERSHEY_SIMPLEX, 0.58, cv::Scalar(0, 0, 0), 4, cv::LINE_AA);
  cv::putText(image, text, origin, cv::FONT_HERSHEY_SIMPLEX, 0.58, cv::Scalar(255, 255, 255), 1, cv::LINE_AA);
}

geometry_msgs::msg::Twist makeStoppedTwist()
{
  geometry_msgs::msg::Twist twist;
  twist.linear.x = 0.0;
  twist.angular.z = 0.0;
  return twist;
}
}  // namespace

class SingleCetnerlineParam : public rclcpp::Node
{
public:
  SingleCetnerlineParam()
  : Node("single_cetnerline_param_node")
  {
    loadParameters();
    entry_bias_start_time_ = std::chrono::steady_clock::now();
    setupParameterCallback();
    createPublishers();
    createImageSubscription();

    const CourseConfig course_config = readCourseConfigFromParameterServer();
    RCLCPP_INFO(
      get_logger(),
      "single cetnerline param started: image_topic=%s crop=(%d,%d,%d,%d) cmd_vel=%s",
      image_topic_.c_str(),
      crop_x_,
      crop_y_,
      crop_width_,
      crop_height_,
      pid_config_.cmd_vel_topic.c_str());
    RCLCPP_INFO(
      get_logger(),
      "entry bias: enabled=%s direction=%s offset=%dpx duration=%.2fs",
      course_config.entry_bias_enabled ? "true" : "false",
      course_config.direction.c_str(),
      course_config.entry_bias_offset_px,
      course_config.entry_bias_duration_sec);
  }

private:
  int declareIntParameter(const std::string &name, int default_value)
  {
    const int64_t value = declare_parameter<int64_t>(name, static_cast<int64_t>(default_value));
    if (value > static_cast<int64_t>(std::numeric_limits<int>::max())) {
      return std::numeric_limits<int>::max();
    }
    if (value < static_cast<int64_t>(std::numeric_limits<int>::min())) {
      return std::numeric_limits<int>::min();
    }
    return static_cast<int>(value);
  }

  void loadParameters()
  {
    image_topic_ = declare_parameter<std::string>("image_topic", image_topic_);
    frame_id_ = declare_parameter<std::string>("frame_id", frame_id_);

    crop_x_ = declareIntParameter("crop_x", crop_x_);
    crop_y_ = declareIntParameter("crop_y", crop_y_);
    crop_width_ = declareIntParameter("crop_width", crop_width_);
    crop_height_ = declareIntParameter("crop_height", crop_height_);

    h_min_ = declareIntParameter("h_min", h_min_);
    h_max_ = declareIntParameter("h_max", h_max_);
    s_min_ = declareIntParameter("s_min", s_min_);
    s_max_ = declareIntParameter("s_max", s_max_);
    v_min_ = declareIntParameter("v_min", v_min_);
    v_max_ = declareIntParameter("v_max", v_max_);
    l_min_ = declareIntParameter("l_min", l_min_);
    l_max_ = declareIntParameter("l_max", l_max_);
    a_min_ = declareIntParameter("a_min", a_min_);
    a_max_ = declareIntParameter("a_max", a_max_);
    b_min_ = declareIntParameter("b_min", b_min_);
    b_max_ = declareIntParameter("b_max", b_max_);
    kernel_size_ = declareIntParameter("kernel_size", kernel_size_);
    min_area_ = declareIntParameter("min_area", min_area_);
    dilate_iterations_ = declareIntParameter("dilate_iterations", dilate_iterations_);
    keep_largest_ = declareIntParameter("keep_largest", keep_largest_);
    fusion_mode_ = declareIntParameter("fusion_mode", fusion_mode_);

    track_config_.dark_region = declare_parameter<bool>("track.dark_region", track_config_.dark_region);
    track_config_.dark_threshold = std::clamp(
      declareIntParameter("track.dark_threshold", track_config_.dark_threshold), 0, 255);
    track_config_.min_area = std::max(
      0.0, declare_parameter<double>("track.min_area", track_config_.min_area));
    track_config_.min_width_px = std::max(
      1, declareIntParameter("track.min_width_px", track_config_.min_width_px));
    track_config_.min_height_px = std::max(
      1, declareIntParameter("track.min_height_px", track_config_.min_height_px));
    track_config_.line_thickness_px = std::max(
      1, declareIntParameter("track.line_thickness_px", track_config_.line_thickness_px));

    centerline_config_.row_step_px = std::max(
      1, declareIntParameter("centerline.row_step_px", centerline_config_.row_step_px));
    centerline_config_.min_row_width_px = std::max(
      1, declareIntParameter("centerline.min_row_width_px", centerline_config_.min_row_width_px));
    centerline_config_.smooth_window = std::max(
      1, declareIntParameter("centerline.smooth_window", centerline_config_.smooth_window));
    centerline_config_.thickness_px = std::max(
      1, declareIntParameter("centerline.thickness_px", centerline_config_.thickness_px));
    centerline_config_.cross_guard_enabled =
      declare_parameter<bool>("centerline.cross_guard_enabled", centerline_config_.cross_guard_enabled);
    centerline_config_.cross_min_rows = std::max(
      1, declareIntParameter("centerline.cross_min_rows", centerline_config_.cross_min_rows));
    centerline_config_.hold_last_cmd_on_cross =
      declare_parameter<bool>("centerline.hold_last_cmd_on_cross", centerline_config_.hold_last_cmd_on_cross);

    pid_config_.enabled = declare_parameter<bool>("pid.enabled", pid_config_.enabled);
    pid_config_.linear_speed = std::max(
      0.0, declare_parameter<double>("pid.linear_speed", pid_config_.linear_speed));
    pid_config_.min_linear_speed = std::clamp(
      declare_parameter<double>("pid.min_linear_speed", pid_config_.min_linear_speed),
      0.0,
      pid_config_.linear_speed);
    pid_config_.angular_gain = std::max(
      0.0, declare_parameter<double>("pid.angular_gain", pid_config_.angular_gain));
    pid_config_.max_angular_z = std::max(
      0.0, declare_parameter<double>("pid.max_angular_z", pid_config_.max_angular_z));
    pid_config_.lookahead_y_px = declareIntParameter("pid.lookahead_y_px", pid_config_.lookahead_y_px);
    pid_config_.lookahead_from_bottom_px = std::max(
      0, declareIntParameter("pid.lookahead_from_bottom_px", pid_config_.lookahead_from_bottom_px));
    pid_config_.deadband_px = std::max(
      0, declareIntParameter("pid.deadband_px", pid_config_.deadband_px));
    pid_config_.kp = std::max(0.0, declare_parameter<double>("pid.kp", pid_config_.kp));
    pid_config_.ki = std::max(0.0, declare_parameter<double>("pid.ki", pid_config_.ki));
    pid_config_.kd = std::max(0.0, declare_parameter<double>("pid.kd", pid_config_.kd));
    pid_config_.integral_limit = std::max(
      0.0, declare_parameter<double>("pid.integral_limit", pid_config_.integral_limit));
    pid_config_.min_centerline_points = std::max(
      1, declareIntParameter("pid.min_centerline_points", pid_config_.min_centerline_points));
    pid_config_.stop_on_lost = declare_parameter<bool>("pid.stop_on_lost", pid_config_.stop_on_lost);
    pid_config_.cmd_vel_publish_hz = std::max(
      0.0, declare_parameter<double>("pid.cmd_vel_publish_hz", pid_config_.cmd_vel_publish_hz));
    pid_config_.cmd_vel_topic = declare_parameter<std::string>("pid.cmd_vel_topic", pid_config_.cmd_vel_topic);

    debug_config_.publish_images = declare_parameter<bool>("debug.publish_images", debug_config_.publish_images);
    debug_config_.publish_dashboard = declare_parameter<bool>("debug.publish_dashboard", debug_config_.publish_dashboard);
    debug_config_.print_interval_sec = std::max(
      0.0, declare_parameter<double>("debug.print_interval_sec", debug_config_.print_interval_sec));

    course_config_.direction =
      declare_parameter<std::string>("course.direction", course_config_.direction);
    if (!isValidCourseDirection(course_config_.direction)) {
      RCLCPP_WARN(
        get_logger(),
        "course.direction only supports cw/ccw, got '%s'; using cw",
        course_config_.direction.c_str());
      course_config_.direction = "cw";
    }
    course_config_.entry_bias_offset_px = std::max(
      0, declareIntParameter("course.entry_bias_offset_px", course_config_.entry_bias_offset_px));
    course_config_.entry_bias_duration_sec = std::max(
      0.0,
      declare_parameter<double>(
        "course.entry_bias_duration_sec", course_config_.entry_bias_duration_sec));
    course_config_.entry_bias_enabled =
      declare_parameter<bool>("course.entry_bias_enabled", course_config_.entry_bias_enabled);
  }

  bool isValidCourseDirection(const std::string &direction) const
  {
    return direction == "cw" || direction == "ccw";
  }

  CourseConfig readCourseConfigFromParameterServer() const
  {
    CourseConfig config = course_config_;
    rclcpp::Parameter parameter;

    if (
      get_parameter("course.direction", parameter) &&
      parameter.get_type() == rclcpp::ParameterType::PARAMETER_STRING)
    {
      const std::string direction = parameter.as_string();
      config.direction = isValidCourseDirection(direction) ? direction : "cw";
    }

    if (
      get_parameter("course.entry_bias_offset_px", parameter) &&
      parameter.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
    {
      const int64_t value = parameter.as_int();
      config.entry_bias_offset_px = static_cast<int>(
        std::clamp<int64_t>(value, 0, static_cast<int64_t>(std::numeric_limits<int>::max())));
    }

    if (get_parameter("course.entry_bias_duration_sec", parameter)) {
      if (parameter.get_type() == rclcpp::ParameterType::PARAMETER_DOUBLE) {
        config.entry_bias_duration_sec = std::max(0.0, parameter.as_double());
      } else if (parameter.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER) {
        config.entry_bias_duration_sec = std::max(0.0, static_cast<double>(parameter.as_int()));
      }
    }

    if (
      get_parameter("course.entry_bias_enabled", parameter) &&
      parameter.get_type() == rclcpp::ParameterType::PARAMETER_BOOL)
    {
      config.entry_bias_enabled = parameter.as_bool();
    }

    return config;
  }

  void setupParameterCallback()
  {
    parameter_callback_handle_ = add_on_set_parameters_callback(
      [this](const std::vector<rclcpp::Parameter> &parameters) {
        return onParameterUpdate(parameters);
      });
  }

  rcl_interfaces::msg::SetParametersResult onParameterUpdate(
    const std::vector<rclcpp::Parameter> &parameters)
  {
    rcl_interfaces::msg::SetParametersResult result;
    result.successful = true;

    for (const auto &parameter : parameters) {
      const std::string &name = parameter.get_name();
      if (name == "course.direction") {
        if (parameter.get_type() != rclcpp::ParameterType::PARAMETER_STRING) {
          result.successful = false;
          result.reason = "course.direction must be a string";
          return result;
        }
        const std::string direction = parameter.as_string();
        if (!isValidCourseDirection(direction)) {
          result.successful = false;
          result.reason = "course.direction only supports cw or ccw";
          return result;
        }
      } else if (name == "course.entry_bias_offset_px") {
        if (parameter.get_type() != rclcpp::ParameterType::PARAMETER_INTEGER) {
          result.successful = false;
          result.reason = "course.entry_bias_offset_px must be an integer";
          return result;
        }
        if (parameter.as_int() < 0) {
          result.successful = false;
          result.reason = "course.entry_bias_offset_px must be >= 0";
          return result;
        }
      } else if (name == "course.entry_bias_duration_sec") {
        if (
          parameter.get_type() != rclcpp::ParameterType::PARAMETER_DOUBLE &&
          parameter.get_type() != rclcpp::ParameterType::PARAMETER_INTEGER)
        {
          result.successful = false;
          result.reason = "course.entry_bias_duration_sec must be numeric";
          return result;
        }
        const double duration = parameter.get_type() == rclcpp::ParameterType::PARAMETER_DOUBLE ?
          parameter.as_double() : static_cast<double>(parameter.as_int());
        if (duration < 0.0) {
          result.successful = false;
          result.reason = "course.entry_bias_duration_sec must be >= 0";
          return result;
        }
      } else if (name == "course.entry_bias_enabled") {
        if (parameter.get_type() != rclcpp::ParameterType::PARAMETER_BOOL) {
          result.successful = false;
          result.reason = "course.entry_bias_enabled must be a bool";
          return result;
        }
      }
    }

    bool reset_entry_bias_timer = false;
    for (const auto &parameter : parameters) {
      const std::string &name = parameter.get_name();
      if (name == "course.direction") {
        course_config_.direction = parameter.as_string();
      } else if (name == "course.entry_bias_offset_px") {
        course_config_.entry_bias_offset_px = static_cast<int>(parameter.as_int());
      } else if (name == "course.entry_bias_duration_sec") {
        course_config_.entry_bias_duration_sec =
          parameter.get_type() == rclcpp::ParameterType::PARAMETER_DOUBLE ?
          parameter.as_double() : static_cast<double>(parameter.as_int());
      } else if (name == "course.entry_bias_enabled") {
        const bool previous = course_config_.entry_bias_enabled;
        course_config_.entry_bias_enabled = parameter.as_bool();
        if (!previous && course_config_.entry_bias_enabled) {
          reset_entry_bias_timer = true;
        }
      }
    }

    if (reset_entry_bias_timer) {
      entry_bias_start_time_ = std::chrono::steady_clock::now();
      RCLCPP_INFO(get_logger(), "entry bias re-enabled; timer reset");
    }

    return result;
  }

  void createPublishers()
  {
    track_mask_pub_ = create_publisher<sensor_msgs::msg::Image>("/single_cetnerline_param/track_mask", 10);
    dashboard_pub_ = create_publisher<sensor_msgs::msg::Image>("/single_cetnerline_param/dashboard", 10);
    cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(pid_config_.cmd_vel_topic, 10);
  }

  void createImageSubscription()
  {
    image_sub_ = create_subscription<sensor_msgs::msg::Image>(
      image_topic_,
      rclcpp::SensorDataQoS(),
      std::bind(&SingleCetnerlineParam::imageCallback, this, std::placeholders::_1));
  }

  void imageCallback(const sensor_msgs::msg::Image::ConstSharedPtr msg)
  {
    cv::Mat full_bgr;
    try {
      full_bgr = convertImageToBgr(msg);
    } catch (const std::exception &error) {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 1000, "image conversion failed: %s", error.what());
      return;
    }

    if (full_bgr.empty()) {
      RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000, "empty /nv12 image");
      publishDriveCommand(makeStoppedTwist(), PidDebug{});
      return;
    }
    processBgrFrame(full_bgr, msg->header);
  }

  cv::Mat convertImageToBgr(const sensor_msgs::msg::Image::ConstSharedPtr &msg) const
  {
    const std::string encoding = msg->encoding;
    if (encoding == sensor_msgs::image_encodings::BGR8 || encoding == "bgr8") {
      return cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8)->image.clone();
    }

    if (encoding == sensor_msgs::image_encodings::RGB8 || encoding == "rgb8") {
      cv::Mat rgb = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::RGB8)->image;
      cv::Mat bgr;
      cv::cvtColor(rgb, bgr, cv::COLOR_RGB2BGR);
      return bgr;
    }

    if (
      encoding == sensor_msgs::image_encodings::MONO8 ||
      encoding == sensor_msgs::image_encodings::TYPE_8UC1 ||
      encoding == "mono8" ||
      encoding == "8UC1")
    {
      cv::Mat gray = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::MONO8)->image;
      cv::Mat bgr;
      cv::cvtColor(gray, bgr, cv::COLOR_GRAY2BGR);
      return bgr;
    }

    if (encoding == "nv12" || encoding == "yuv420_nv12") {
      if (msg->width == 0 || msg->height == 0 || msg->step < msg->width) {
        throw std::runtime_error("invalid NV12 image size or step");
      }

      const int nv12_rows = static_cast<int>(msg->height + msg->height / 2);
      const size_t required_size =
        static_cast<size_t>(msg->step) * static_cast<size_t>(nv12_rows);
      if (msg->data.size() < required_size) {
        throw std::runtime_error("NV12 image data is shorter than expected");
      }

      cv::Mat nv12(
        nv12_rows,
        static_cast<int>(msg->width),
        CV_8UC1,
        const_cast<uint8_t *>(msg->data.data()),
        msg->step);
      cv::Mat bgr;
      cv::cvtColor(nv12, bgr, cv::COLOR_YUV2BGR_NV12);
      return bgr;
    }

    return cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8)->image.clone();
  }

  void processBgrFrame(const cv::Mat &full_bgr, const std_msgs::msg::Header &input_header)
  {
    const cv::Rect crop_rect = makeCropRect(full_bgr);
    const cv::Mat crop_bgr = full_bgr(crop_rect).clone();

    cv::Mat hsv_mask;
    cv::Mat lab_inv_mask;
    cv::Mat final_mask;
    processColorMasks(crop_bgr, hsv_mask, lab_inv_mask, final_mask);

    const cv::Mat track_mask = makeTrackMask(final_mask);
    const LineTrackResult line = trackCenterline(track_mask);
    const bool centerline_invalid = isCenterlineInvalid(line);
    std::vector<cv::Point> centerline =
      centerline_invalid ? std::vector<cv::Point>() : smoothCenterline(pointsFromLine(line.center_line));
    centerline = applyEntryBiasIfActive(centerline, track_mask.size());

    cv::Mat result = crop_bgr.clone();
    drawTrackedBoundary(result, line);
    drawCenterline(result, centerline, cv::Scalar(255, 0, 0));

    PidDebug debug;
    geometry_msgs::msg::Twist cmd;
    if (centerline_invalid) {
      cmd = makeCrossInvalidCommand(&debug, line);
    } else {
      cmd = makePidCommand(track_mask, centerline, &debug);
      rememberLastValidCommand(cmd, debug);
    }
    drawPidDebug(result, debug);
    publishDriveCommand(cmd, debug);

    if (debug_config_.publish_images) {
      const cv::Mat dashboard = debug_config_.publish_dashboard ? makeDashboard(full_bgr, result) : cv::Mat();
      publishImages(input_header, track_mask, dashboard);
    }
    printDebugThrottled(crop_rect, debug, line);
  }

  cv::Rect makeCropRect(const cv::Mat &frame) const
  {
    const int max_x = std::max(frame.cols - 1, 0);
    const int max_y = std::max(frame.rows - 1, 0);
    const int x = std::max(0, std::min(crop_x_, max_x));
    const int y = std::max(0, std::min(crop_y_, max_y));
    const int width = std::max(1, std::min(crop_width_, frame.cols - x));
    const int height = std::max(1, std::min(crop_height_, frame.rows - y));
    return cv::Rect(x, y, width, height);
  }

  void processColorMasks(
    const cv::Mat &frame,
    cv::Mat &hsv_mask,
    cv::Mat &lab_inv_mask,
    cv::Mat &final_mask)
  {
    cv::Mat filtered;
    cv::bilateralFilter(frame, filtered, 5, 50, 50);

    cv::Mat hsv;
    cv::cvtColor(filtered, hsv, cv::COLOR_BGR2HSV);
    cv::inRange(
      hsv,
      cv::Scalar(std::min(h_min_, h_max_), std::min(s_min_, s_max_), std::min(v_min_, v_max_)),
      cv::Scalar(std::max(h_min_, h_max_), std::max(s_min_, s_max_), std::max(v_min_, v_max_)),
      hsv_mask);
    denoiseMask(hsv_mask, false);

    cv::Mat lab;
    cv::cvtColor(filtered, lab, cv::COLOR_BGR2Lab);
    cv::inRange(
      lab,
      cv::Scalar(std::min(l_min_, l_max_), std::min(a_min_, a_max_), std::min(b_min_, b_max_)),
      cv::Scalar(std::max(l_min_, l_max_), std::max(a_min_, a_max_), std::max(b_min_, b_max_)),
      lab_inv_mask);
    denoiseMask(lab_inv_mask, false);
    cv::bitwise_not(lab_inv_mask, lab_inv_mask);
    denoiseMask(lab_inv_mask, false);

    if (fusion_mode_ == kAndFusion) {
      cv::bitwise_and(hsv_mask, lab_inv_mask, final_mask);
    } else {
      cv::bitwise_or(hsv_mask, lab_inv_mask, final_mask);
    }
    denoiseMask(final_mask, true);
  }

  void denoiseMask(cv::Mat &mask, bool final_stage)
  {
    const int kernel_size = makeOddKernelSize(kernel_size_);
    const cv::Mat kernel =
      cv::getStructuringElement(cv::MORPH_RECT, cv::Size(kernel_size, kernel_size));

    cv::medianBlur(mask, mask, makeMedianKernelSize(kernel_size));
    cv::morphologyEx(mask, mask, cv::MORPH_OPEN, kernel);
    cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);

    if (final_stage && dilate_iterations_ > 0) {
      cv::dilate(mask, mask, kernel, cv::Point(-1, -1), dilate_iterations_);
      cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);
    }

    filterMaskComponents(mask, min_area_, final_stage && keep_largest_ != 0);
  }

  void filterMaskComponents(cv::Mat &mask, int min_area, bool keep_largest) const
  {
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(mask.clone(), contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    cv::Mat cleaned = cv::Mat::zeros(mask.size(), CV_8UC1);
    int best_index = -1;
    double best_area = 0.0;

    for (std::size_t i = 0; i < contours.size(); ++i) {
      const double area = cv::contourArea(contours[i]);
      if (area < static_cast<double>(std::max(0, min_area))) {
        continue;
      }
      if (keep_largest) {
        if (area > best_area) {
          best_area = area;
          best_index = static_cast<int>(i);
        }
      } else {
        cv::drawContours(cleaned, contours, static_cast<int>(i), cv::Scalar(255), cv::FILLED);
      }
    }

    if (keep_largest && best_index >= 0) {
      cv::drawContours(cleaned, contours, best_index, cv::Scalar(255), cv::FILLED);
    }
    mask = cleaned;
  }

  cv::Mat makeTrackMask(const cv::Mat &final_mask) const
  {
    cv::Mat track_mask;
    cv::threshold(
      final_mask,
      track_mask,
      track_config_.dark_threshold,
      255,
      track_config_.dark_region ? cv::THRESH_BINARY_INV : cv::THRESH_BINARY);

    const int kernel_size = makeOddKernelSize(kernel_size_);
    const cv::Mat kernel =
      cv::getStructuringElement(cv::MORPH_RECT, cv::Size(kernel_size, kernel_size));
    cv::medianBlur(track_mask, track_mask, makeMedianKernelSize(kernel_size));
    cv::morphologyEx(track_mask, track_mask, cv::MORPH_OPEN, kernel);
    cv::morphologyEx(track_mask, track_mask, cv::MORPH_CLOSE, kernel);

    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(track_mask.clone(), contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    cv::Mat filtered = cv::Mat::zeros(track_mask.size(), CV_8UC1);
    for (std::size_t i = 0; i < contours.size(); ++i) {
      const double area = cv::contourArea(contours[i]);
      const cv::Rect rect = cv::boundingRect(contours[i]);
      if (
        area >= track_config_.min_area &&
        rect.width >= track_config_.min_width_px &&
        rect.height >= track_config_.min_height_px)
      {
        cv::drawContours(filtered, contours, static_cast<int>(i), cv::Scalar(255), cv::FILLED);
      }
    }
    return filtered;
  }

  bool findRowSegment(
    const uchar *row,
    int width,
    int reference_center,
    int *left,
    int *right) const
  {
    int x = 0;
    int best_left = -1;
    int best_right = -1;
    int best_score = std::numeric_limits<int>::min();
    const int min_width = std::max(1, centerline_config_.min_row_width_px);

    while (x < width) {
      while (x < width && row[x] == 0) {
        ++x;
      }
      if (x >= width) {
        break;
      }

      const int run_left = x;
      while (x < width && row[x] > 0) {
        ++x;
      }
      const int run_right = x - 1;
      const int run_width = run_right - run_left + 1;
      if (run_width < min_width) {
        continue;
      }

      const int run_center = (run_left + run_right) / 2;
      int score = run_width * 4 - std::abs(run_center - reference_center);
      if (reference_center >= run_left && reference_center <= run_right) {
        score += width * 4;
      }
      if (score > best_score) {
        best_score = score;
        best_left = run_left;
        best_right = run_right;
      }
    }

    if (best_left < 0 || best_right < 0) {
      return false;
    }
    *left = best_left;
    *right = best_right;
    return true;
  }

  LineTrackResult trackCenterline(const cv::Mat &mask) const
  {
    LineTrackResult result;
    if (mask.empty() || mask.type() != CV_8UC1) {
      return result;
    }

    const int width = mask.cols;
    const int height = mask.rows;
    const int row_step = std::max(1, centerline_config_.row_step_px);
    int reference_center = width / 2;
    int weighted_center_sum = 0;
    int weight_sum = 0;
    int lost_rows = 0;
    const int max_lost_rows = std::max(4, height / 8);
    const int min_valid_rows = std::max(6, height / 8);

    result.left_boundary.assign(height, -1);
    result.right_boundary.assign(height, -1);
    result.center_line.assign(height, -1);
    result.target_center_x = width / 2;

    for (int y = height - 1; y >= 0; y -= row_step) {
      int left = -1;
      int right = -1;
      const uchar *row = mask.ptr<uchar>(y);

      if (findRowSegment(row, width, reference_center, &left, &right)) {
        if (left >= right) {
          ++result.crossed_rows;
        }
        const int center = (left + right) / 2;
        const int weight = height - y + 1;
        result.left_boundary[y] = left;
        result.right_boundary[y] = right;
        result.center_line[y] = center;
        reference_center = center;
        weighted_center_sum += center * weight;
        weight_sum += weight;
        ++result.valid_rows;
        lost_rows = 0;
      } else if (result.valid_rows > 0) {
        ++lost_rows;
        if (lost_rows > max_lost_rows) {
          break;
        }
      }
    }

    result.crossed = result.crossed_rows >= centerline_config_.cross_min_rows;

    if (result.valid_rows < min_valid_rows || weight_sum == 0) {
      result.lost = true;
      result.error = 0;
      result.target_center_x = width / 2;
      return result;
    }

    result.lost = false;
    result.target_center_x = weighted_center_sum / weight_sum;
    result.error = result.target_center_x - width / 2;
    return result;
  }

  bool isCenterlineInvalid(const LineTrackResult &line) const
  {
    if (!centerline_config_.cross_guard_enabled) {
      return false;
    }
    return line.crossed && line.valid_rows > 0;
  }

  std::vector<cv::Point> pointsFromLine(const std::vector<int> &xs) const
  {
    std::vector<cv::Point> points;
    points.reserve(xs.size());
    for (int y = static_cast<int>(xs.size()) - 1; y >= 0; --y) {
      if (xs[static_cast<std::size_t>(y)] >= 0) {
        points.emplace_back(xs[static_cast<std::size_t>(y)], y);
      }
    }
    return points;
  }

  std::vector<cv::Point> smoothCenterline(const std::vector<cv::Point> &points) const
  {
    if (points.size() < 3U) {
      return points;
    }

    const int window = makeOddKernelSize(centerline_config_.smooth_window);
    const int half = window / 2;
    std::vector<cv::Point> smoothed;
    smoothed.reserve(points.size());
    for (int i = 0; i < static_cast<int>(points.size()); ++i) {
      const int begin = std::max(0, i - half);
      const int end = std::min(static_cast<int>(points.size()) - 1, i + half);
      int x_sum = 0;
      int count = 0;
      for (int j = begin; j <= end; ++j) {
        x_sum += points[j].x;
        ++count;
      }
      smoothed.emplace_back(
        static_cast<int>(std::lround(static_cast<double>(x_sum) / static_cast<double>(count))),
        points[i].y);
    }
    return smoothed;
  }

  bool isEntryBiasActive(const CourseConfig &course_config) const
  {
    if (
      !course_config.entry_bias_enabled ||
      course_config.entry_bias_offset_px <= 0 ||
      course_config.entry_bias_duration_sec <= 0.0)
    {
      return false;
    }

    const auto elapsed = std::chrono::duration<double>(
      std::chrono::steady_clock::now() - entry_bias_start_time_);
    return elapsed.count() <= course_config.entry_bias_duration_sec;
  }

  std::vector<cv::Point> applyEntryBiasIfActive(
    const std::vector<cv::Point> &points,
    const cv::Size &image_size) const
  {
    const CourseConfig course_config = readCourseConfigFromParameterServer();
    if (points.empty() || image_size.width <= 0 || !isEntryBiasActive(course_config)) {
      return points;
    }

    const int sign = course_config.direction == "cw" ? -1 : 1;
    const int offset = sign * course_config.entry_bias_offset_px;
    std::vector<cv::Point> shifted;
    shifted.reserve(points.size());
    for (const auto &point : points) {
      shifted.emplace_back(std::clamp(point.x + offset, 0, image_size.width - 1), point.y);
    }
    return shifted;
  }

  cv::Point selectLookaheadPoint(const std::vector<cv::Point> &centerline, int image_height) const
  {
    const int target_y = pid_config_.lookahead_y_px >= 0 ?
      std::clamp(pid_config_.lookahead_y_px, 0, std::max(0, image_height - 1)) :
      std::clamp(
        image_height - 1 - pid_config_.lookahead_from_bottom_px,
        0,
        std::max(0, image_height - 1));

    cv::Point best = centerline.front();
    int best_distance = std::abs(best.y - target_y);
    for (const auto &point : centerline) {
      const int distance = std::abs(point.y - target_y);
      if (distance < best_distance) {
        best = point;
        best_distance = distance;
      }
    }
    return best;
  }

  double applyPid(double pid_error, PidDebug *debug)
  {
    const auto now_time = std::chrono::steady_clock::now();
    double dt = 0.1;
    double error_diff = 0.0;
    if (pid_state_.initialized) {
      dt = std::chrono::duration<double>(now_time - pid_state_.last_time).count();
      if (dt <= 1e-6) {
        dt = 0.1;
      }
      error_diff = (pid_error - pid_state_.last_error) / dt;
    } else {
      pid_state_.initialized = true;
    }

    pid_state_.error_sum += pid_error * dt;
    const double integral_limit = std::max(0.0, pid_config_.integral_limit);
    if (integral_limit > 0.0) {
      pid_state_.error_sum = std::clamp(pid_state_.error_sum, -integral_limit, integral_limit);
    }

    const double p = pid_config_.kp * pid_error;
    const double i = pid_config_.ki * pid_state_.error_sum;
    const double d = pid_config_.kd * error_diff;
    const double output = p + i + d;
    pid_state_.last_error = pid_error;
    pid_state_.last_time = now_time;

    if (debug != nullptr) {
      debug->pid_error = pid_error;
      debug->pid_p = p;
      debug->pid_i = i;
      debug->pid_d = d;
      debug->pid_output = output;
    }
    return output;
  }

  void resetPidState()
  {
    pid_state_.last_error = 0.0;
    pid_state_.error_sum = 0.0;
    pid_state_.last_time = {};
    pid_state_.initialized = false;
  }

  geometry_msgs::msg::Twist finishPidCommand(const geometry_msgs::msg::Twist &cmd, PidDebug *debug)
  {
    if (std::abs(cmd.linear.x) < 1e-6 && std::abs(cmd.angular.z) < 1e-6) {
      resetPidState();
    }
    if (debug != nullptr) {
      debug->stopped = std::abs(cmd.linear.x) < 1e-6 && std::abs(cmd.angular.z) < 1e-6;
      debug->linear_x = cmd.linear.x;
      debug->angular_z = cmd.angular.z;
    }
    return cmd;
  }

  geometry_msgs::msg::Twist makePidCommand(
    const cv::Mat &track_mask,
    const std::vector<cv::Point> &centerline,
    PidDebug *debug)
  {
    PidDebug local_debug;
    local_debug.mode = "PID";
    local_debug.centerline_points = static_cast<int>(centerline.size());

    if (!pid_config_.enabled) {
      local_debug.mode = "DISABLED";
      if (debug != nullptr) {
        *debug = local_debug;
      }
      return finishPidCommand(makeStoppedTwist(), debug);
    }

    if (
      track_mask.empty() ||
      centerline.size() < static_cast<std::size_t>(pid_config_.min_centerline_points))
    {
      local_debug.mode = "LOST";
      if (debug != nullptr) {
        *debug = local_debug;
      }
      return finishPidCommand(makeStoppedTwist(), debug);
    }

    const cv::Point target = selectLookaheadPoint(centerline, track_mask.rows);
    const double image_center_x = static_cast<double>(track_mask.cols) / 2.0;
    const double raw_error = image_center_x - static_cast<double>(target.x);
    const double pid_error =
      std::abs(raw_error) < static_cast<double>(pid_config_.deadband_px) ?
      0.0 :
      pid_config_.angular_gain * raw_error / std::max(1.0, image_center_x);
    double angular_z = applyPid(pid_error, &local_debug);
    angular_z = std::clamp(angular_z, -pid_config_.max_angular_z, pid_config_.max_angular_z);

    const double turn_ratio = pid_config_.max_angular_z > 1e-6 ?
      std::clamp(std::abs(angular_z) / pid_config_.max_angular_z, 0.0, 1.0) : 0.0;
    const double max_speed = std::max(0.0, pid_config_.linear_speed);
    const double min_speed = std::clamp(pid_config_.min_linear_speed, 0.0, max_speed);
    const double linear_x = max_speed - (max_speed - min_speed) * turn_ratio;

    geometry_msgs::msg::Twist cmd;
    cmd.linear.x = linear_x;
    cmd.angular.z = angular_z;

    local_debug.valid = true;
    local_debug.stopped = false;
    local_debug.target_x = target.x;
    local_debug.target_y = target.y;
    local_debug.error_px = static_cast<int>(std::lround(raw_error));
    local_debug.angular_z = angular_z;
    local_debug.linear_x = linear_x;
    if (debug != nullptr) {
      *debug = local_debug;
    }
    return finishPidCommand(cmd, debug);
  }

  geometry_msgs::msg::Twist makeCrossInvalidCommand(PidDebug *debug, const LineTrackResult &line)
  {
    geometry_msgs::msg::Twist cmd;
    if (centerline_config_.hold_last_cmd_on_cross && has_last_valid_cmd_) {
      cmd = last_valid_cmd_;
    } else {
      cmd = makeStoppedTwist();
    }

    if (debug != nullptr) {
      debug->valid = true;
      debug->stopped = std::abs(cmd.linear.x) < 1e-6 && std::abs(cmd.angular.z) < 1e-6;
      debug->centerline_points = 0;
      debug->target_x = -1;
      debug->target_y = -1;
      debug->error_px = 0;
      debug->linear_x = cmd.linear.x;
      debug->angular_z = cmd.angular.z;
      debug->mode = "CROSS_INVALID rows=" + std::to_string(line.crossed_rows);
    }

    return cmd;
  }

  void rememberLastValidCommand(const geometry_msgs::msg::Twist &cmd, const PidDebug &debug)
  {
    if (!debug.valid || debug.mode != "PID") {
      return;
    }
    last_valid_cmd_ = cmd;
    has_last_valid_cmd_ = true;
  }

  void publishDriveCommand(const geometry_msgs::msg::Twist &cmd, const PidDebug &debug)
  {
    if (!debug.valid && !pid_config_.stop_on_lost) {
      return;
    }

    const auto now_time = std::chrono::steady_clock::now();
    if (pid_config_.cmd_vel_publish_hz > 0.0) {
      const auto min_period = std::chrono::duration<double>(1.0 / pid_config_.cmd_vel_publish_hz);
      if (
        last_cmd_vel_publish_ != std::chrono::steady_clock::time_point{} &&
        now_time - last_cmd_vel_publish_ <
        std::chrono::duration_cast<std::chrono::steady_clock::duration>(min_period))
      {
        return;
      }
    }
    last_cmd_vel_publish_ = now_time;
    cmd_vel_pub_->publish(cmd);
  }

  void drawTrackedBoundary(cv::Mat &output, const LineTrackResult &line) const
  {
    const std::vector<cv::Point> left_points = pointsFromLine(line.left_boundary);
    const std::vector<cv::Point> right_points = pointsFromLine(line.right_boundary);
    if (left_points.size() >= 2U) {
      cv::polylines(
        output,
        std::vector<std::vector<cv::Point>>{left_points},
        false,
        cv::Scalar(0, 0, 255),
        track_config_.line_thickness_px,
        cv::LINE_AA);
    }
    if (right_points.size() >= 2U) {
      cv::polylines(
        output,
        std::vector<std::vector<cv::Point>>{right_points},
        false,
        cv::Scalar(0, 255, 0),
        track_config_.line_thickness_px,
        cv::LINE_AA);
    }
  }

  void drawCenterline(cv::Mat &output, const std::vector<cv::Point> &centerline, const cv::Scalar &color) const
  {
    if (centerline.size() >= 2U) {
      cv::polylines(
        output,
        std::vector<std::vector<cv::Point>>{centerline},
        false,
        color,
        centerline_config_.thickness_px,
        cv::LINE_AA);
    } else if (centerline.size() == 1U) {
      cv::circle(output, centerline.front(), 3, color, cv::FILLED, cv::LINE_AA);
    }
  }

  void drawPidDebug(cv::Mat &result, const PidDebug &debug) const
  {
    if (debug.target_x >= 0 && debug.target_y >= 0) {
      cv::circle(result, cv::Point(debug.target_x, debug.target_y), 6, cv::Scalar(0, 255, 255), -1);
    }
    const int image_center_x = result.cols / 2;
    cv::line(result, cv::Point(image_center_x, 0), cv::Point(image_center_x, result.rows - 1), cv::Scalar(128, 128, 128), 1, cv::LINE_AA);
    drawLabel(result, "mode: " + debug.mode, cv::Point(12, 28));
    drawLabel(result, "points: " + std::to_string(debug.centerline_points), cv::Point(12, 56));
    drawLabel(
      result,
      "err: " + std::to_string(debug.error_px) + " wz: " + std::to_string(debug.angular_z).substr(0, 5),
      cv::Point(12, 84));
    drawLabel(result, "vx: " + std::to_string(debug.linear_x).substr(0, 5), cv::Point(12, 112));
    if (debug.mode.find("CROSS_INVALID") != std::string::npos) {
      drawLabel(result, "centerline invalid: boundary crossed", cv::Point(12, 140));
    }
  }

  cv::Mat resizeToWidth(const cv::Mat &image, int width) const
  {
    const double scale = static_cast<double>(width) / static_cast<double>(image.cols);
    cv::Mat output;
    cv::resize(image, output, cv::Size(width, std::max(1, static_cast<int>(image.rows * scale))));
    return output;
  }

  cv::Mat padToHeight(const cv::Mat &image, int target_height) const
  {
    if (image.rows >= target_height) {
      return image;
    }
    cv::Mat padded(target_height, image.cols, image.type(), cv::Scalar::all(0));
    image.copyTo(padded(cv::Rect(0, 0, image.cols, image.rows)));
    return padded;
  }

  cv::Mat makeDashboard(const cv::Mat &raw, const cv::Mat &result) const
  {
    constexpr int panel_width = 560;
    cv::Mat raw_view = resizeToWidth(raw, panel_width);
    cv::Mat result_view = resizeToWidth(result, panel_width);
    drawLabel(raw_view, "USB Raw", cv::Point(12, 30));
    drawLabel(result_view, "Fusion PID", cv::Point(12, 30));
    const int target_height = std::max(raw_view.rows, result_view.rows);
    raw_view = padToHeight(raw_view, target_height);
    result_view = padToHeight(result_view, target_height);
    cv::Mat dashboard;
    cv::hconcat(raw_view, result_view, dashboard);
    return dashboard;
  }

  void publishImages(
    const std_msgs::msg::Header &input_header,
    const cv::Mat &track_mask,
    const cv::Mat &dashboard)
  {
    std_msgs::msg::Header header = input_header;
    if (header.frame_id.empty()) {
      header.frame_id = frame_id_;
    }
    if (header.stamp.sec == 0 && header.stamp.nanosec == 0) {
      header.stamp = now();
    }

    track_mask_pub_->publish(*cv_bridge::CvImage(header, sensor_msgs::image_encodings::MONO8, track_mask).toImageMsg());
    if (debug_config_.publish_dashboard && !dashboard.empty()) {
      dashboard_pub_->publish(*cv_bridge::CvImage(header, sensor_msgs::image_encodings::BGR8, dashboard).toImageMsg());
    }
  }

  void printDebugThrottled(const cv::Rect &crop_rect, const PidDebug &debug, const LineTrackResult &line)
  {
    if (debug_config_.print_interval_sec <= 0.0) {
      return;
    }
    const auto now_time = std::chrono::steady_clock::now();
    const auto interval = std::chrono::duration_cast<std::chrono::steady_clock::duration>(
      std::chrono::duration<double>(debug_config_.print_interval_sec));
    if (now_time - last_debug_print_ < interval) {
      return;
    }
    RCLCPP_INFO(
      get_logger(),
      "crop=(%d,%d,%d,%d) mode=%s points=%d valid_rows=%d crossed_rows=%d line_lost=%s target=(%d,%d) err=%d v=%.2f wz=%.2f",
      crop_rect.x,
      crop_rect.y,
      crop_rect.width,
      crop_rect.height,
      debug.mode.c_str(),
      debug.centerline_points,
      line.valid_rows,
      line.crossed_rows,
      line.lost ? "true" : "false",
      debug.target_x,
      debug.target_y,
      debug.error_px,
      debug.linear_x,
      debug.angular_z);
    last_debug_print_ = now_time;
  }

  std::string image_topic_{"/nv12"};
  std::string frame_id_{"camera"};

  int crop_x_{45};
  int crop_y_{180};
  int crop_width_{550};
  int crop_height_{300};

  int h_min_{43};
  int h_max_{179};
  int s_min_{34};
  int s_max_{255};
  int v_min_{0};
  int v_max_{255};
  int l_min_{0};
  int l_max_{255};
  int a_min_{0};
  int a_max_{255};
  int b_min_{124};
  int b_max_{255};
  int kernel_size_{7};
  int min_area_{2621};
  int dilate_iterations_{3};
  int keep_largest_{0};
  int fusion_mode_{kOrFusion};

  TrackConfig track_config_;
  CenterlineConfig centerline_config_;
  PidConfig pid_config_;
  DebugConfig debug_config_;
  CourseConfig course_config_;
  PidState pid_state_;

  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr image_sub_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr track_mask_pub_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr dashboard_pub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle_;
  std::chrono::steady_clock::time_point entry_bias_start_time_{std::chrono::steady_clock::now()};
  std::chrono::steady_clock::time_point last_cmd_vel_publish_{};
  std::chrono::steady_clock::time_point last_debug_print_{std::chrono::steady_clock::now()};
  geometry_msgs::msg::Twist last_valid_cmd_;
  bool has_last_valid_cmd_{false};
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<SingleCetnerlineParam>());
  rclcpp::shutdown();
  return 0;
}
