/*
 * qr_tracking_decoder
 *
 * 功能说明:
 * - 订阅 YOLO/AI 感知结果，使用 point 标签巡线。
 * - 检测到 tong 障碍物时优先避障，障碍物消失后安全缓冲并返航回线。
 * - 检测到 qr 标签时切换到二维码追踪控制，并同步使用相机图像解码二维码。
 * - 解码成功后将结果写入本节点参数 last_qr_code_result，并持续发布 0 速度停车。
 * - 状态四可通过 enable_qr_decode / enable_qr_tracking 关闭二维码逻辑，只保留巡线能力。
 */

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cctype>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "ai_msgs/msg/perception_targets.hpp"
#include "ament_index_cpp/get_package_share_directory.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/image.hpp"
#include "std_msgs/msg/string.hpp"

#include <opencv2/opencv.hpp>
#include <opencv2/wechat_qrcode.hpp>

#ifdef QR_TRACKING_DECODER_HAS_ZBAR
#include <zbar.h>
#endif

using namespace std::chrono_literals;

namespace
{
geometry_msgs::msg::Twist makeStoppedTwist()
{
  geometry_msgs::msg::Twist twist;
  twist.linear.x = 0.0;
  twist.angular.z = 0.0;
  return twist;
}
}  // namespace

class QrTrackingDecoder : public rclcpp::Node
{
public:
  using PerceptionTargets = ai_msgs::msg::PerceptionTargets;

  QrTrackingDecoder()
  : Node("qr_tracking_decoder")
  {
    loadParameters();
    initWeChatModel();
    initZBarScanner();

    result_pub_ = create_publisher<std_msgs::msg::String>(output_topic_, 1);
    cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);
    target_sub_ = create_subscription<PerceptionTargets>(
      target_topic_,
      10,
      std::bind(&QrTrackingDecoder::targetCallback, this, std::placeholders::_1));
    image_sub_ = create_subscription<sensor_msgs::msg::Image>(
      image_topic_,
      rclcpp::SensorDataQoS(),
      std::bind(&QrTrackingDecoder::imageCallback, this, std::placeholders::_1));

    const auto cmd_period = std::chrono::duration<double>(1.0 / cmd_vel_publish_hz_);
    cmd_timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(cmd_period),
      std::bind(&QrTrackingDecoder::cmdTimerCallback, this));

    processing_thread_ = std::thread(&QrTrackingDecoder::processingLoop, this);

    RCLCPP_INFO(
      get_logger(),
      "qr_tracking_decoder started: target=%s image=%s cmd_vel=%s qr_decode=%s qr_tracking=%s obstacle=%s",
      target_topic_.c_str(),
      image_topic_.c_str(),
      cmd_vel_topic_.c_str(),
      enable_qr_decode_ ? "true" : "false",
      enable_qr_tracking_ ? "true" : "false",
      enable_obstacle_avoidance_ ? "true" : "false");
  }

  ~QrTrackingDecoder() override
  {
    {
      std::lock_guard<std::mutex> lock(queue_mutex_);
      stop_processing_ = true;
    }
    queue_cv_.notify_all();

    if (processing_thread_.joinable()) {
      processing_thread_.join();
    }
  }

private:
  struct PointTarget
  {
    int center_x{0};
    int center_y{0};
    float confidence{0.0F};
  };

  struct QrTarget
  {
    int center_x{0};
    int center_y{0};
    int size{0};
    float confidence{0.0F};
  };

  struct ObstacleTarget
  {
    int center_x{0};
    int left{0};
    int right{0};
    int bottom{0};
    float confidence{0.0F};
  };

  enum class MotionState
  {
    NORMAL,
    OBSTACLE_AVOIDING,
    RETURN_TO_LINE,
  };

  enum class TurnDirection
  {
    LEFT,
    RIGHT,
    UNKNOWN,
  };

  struct QrLocation
  {
    bool valid{false};
    double center_x{0.0};
    double center_y{0.0};
    int image_width{0};
    int image_height{0};
  };

  struct DecodeResult
  {
    bool decoded{false};
    bool located{false};
    std::string text;
    QrLocation location;
  };

  int declareIntParameter(const std::string &name, int default_value)
  {
    const int64_t value = declare_parameter<int64_t>(name, static_cast<int64_t>(default_value));
    if (value > static_cast<int64_t>(std::numeric_limits<int>::max())) {
      return std::numeric_limits<int>::max();
    }
    if (value < static_cast<int64_t>(std::numeric_limits<int>::min())) {
      return std::numeric_limits<int>::min();
    }
    return static_cast<int>(value);
  }

  void loadParameters()
  {
    target_topic_ = declare_parameter<std::string>("target_topic", target_topic_);
    image_topic_ = declare_parameter<std::string>("image_topic", image_topic_);
    output_topic_ = declare_parameter<std::string>("output_topic", output_topic_);
    cmd_vel_topic_ = declare_parameter<std::string>("cmd_vel_topic", cmd_vel_topic_);
    model_path_ = declare_parameter<std::string>("model_path", model_path_);
    if (model_path_.empty()) {
      model_path_ = defaultModelPath();
    }

    declare_parameter<std::string>("last_qr_code_result", "");

    image_width_ = std::max(1, declareIntParameter("image_width", image_width_));
    image_height_ = std::max(1, declareIntParameter("image_height", image_height_));
    point_label_ = declare_parameter<std::string>("point_label", point_label_);
    qr_label_ = declare_parameter<std::string>("qr_label", qr_label_);
    point_confidence_threshold_ =
      declare_parameter<double>("point_confidence_threshold", point_confidence_threshold_);
    qr_confidence_threshold_ = declare_parameter<double>("qr_confidence_threshold", qr_confidence_threshold_);
    enable_line_following_ = declare_parameter<bool>("enable_line_following", enable_line_following_);
    enable_qr_tracking_ = declare_parameter<bool>("enable_qr_tracking", enable_qr_tracking_);
    enable_qr_decode_ = declare_parameter<bool>("enable_qr_decode", enable_qr_decode_);
    enable_obstacle_avoidance_ =
      declare_parameter<bool>("enable_obstacle_avoidance", enable_obstacle_avoidance_);

    line_linear_speed_ = std::max(0.0, declare_parameter<double>("line_linear_speed", line_linear_speed_));
    line_angular_ratio_ = std::max(0.0, declare_parameter<double>("line_angular_ratio", line_angular_ratio_));
    line_dead_zone_px_ = std::max(0, declareIntParameter("line_dead_zone_px", line_dead_zone_px_));
    line_kp_ = declare_parameter<double>("line_kp", line_kp_);
    line_ki_ = declare_parameter<double>("line_ki", line_ki_);
    line_kd_ = declare_parameter<double>("line_kd", line_kd_);

    qr_linear_speed_ = std::max(0.0, declare_parameter<double>("qr_linear_speed", qr_linear_speed_));
    qr_angular_ratio_ = std::max(0.0, declare_parameter<double>("qr_angular_ratio", qr_angular_ratio_));
    qr_size_threshold_ = std::max(0, declareIntParameter("qr_size_threshold", qr_size_threshold_));
    qr_approach_slowdown_ =
      std::clamp(declare_parameter<double>("qr_approach_slowdown", qr_approach_slowdown_), 0.0, 1.0);
    qr_stop_size_ = std::max(0, declareIntParameter("qr_stop_size", qr_stop_size_));
    qr_dead_zone_px_ = std::max(0, declareIntParameter("qr_dead_zone_px", qr_dead_zone_px_));

    obstacle_label_ = declare_parameter<std::string>("obstacle_label", obstacle_label_);
    obstacle_confidence_threshold_ =
      declare_parameter<double>("obstacle_confidence_threshold", obstacle_confidence_threshold_);
    obstacle_bottom_threshold_ =
      std::max(0, declareIntParameter("obstacle_bottom_threshold", obstacle_bottom_threshold_));
    obstacle_effective_area_left_ =
      std::max(0, declareIntParameter("obstacle_effective_area_left", obstacle_effective_area_left_));
    obstacle_effective_area_right_ =
      std::max(0, declareIntParameter("obstacle_effective_area_right", obstacle_effective_area_right_));
    if (obstacle_effective_area_right_ < obstacle_effective_area_left_) {
      std::swap(obstacle_effective_area_left_, obstacle_effective_area_right_);
    }
    obstacle_angular_ratio_ =
      std::max(0.0, declare_parameter<double>("obstacle_angular_ratio", obstacle_angular_ratio_));
    obstacle_linear_speed_ =
      std::max(0.0, declare_parameter<double>("obstacle_linear_speed", obstacle_linear_speed_));
    obstacle_deviation_threshold_ =
      std::max(1, declareIntParameter("obstacle_deviation_threshold", obstacle_deviation_threshold_));
    obstacle_safe_duration_ =
      std::max(0.0, declare_parameter<double>("obstacle_safe_duration", obstacle_safe_duration_));
    obstacle_return_linear_speed_ =
      std::max(0.0, declare_parameter<double>("obstacle_return_linear_speed", obstacle_return_linear_speed_));
    obstacle_return_duration_left_ =
      std::max(0.0, declare_parameter<double>("obstacle_return_duration_left", obstacle_return_duration_left_));
    obstacle_return_duration_right_ =
      std::max(0.0, declare_parameter<double>("obstacle_return_duration_right", obstacle_return_duration_right_));
    obstacle_return_angular_speed_left_ =
      std::max(0.0, declare_parameter<double>(
        "obstacle_return_angular_speed_left",
        obstacle_return_angular_speed_left_));
    obstacle_return_angular_speed_right_ =
      std::max(0.0, declare_parameter<double>(
        "obstacle_return_angular_speed_right",
        obstacle_return_angular_speed_right_));
    obstacle_buffer_linear_speed_ =
      std::max(0.0, declare_parameter<double>("obstacle_buffer_linear_speed", obstacle_buffer_linear_speed_));

    max_angular_velocity_ =
      std::max(0.0, declare_parameter<double>("max_angular_velocity", max_angular_velocity_));
    cmd_vel_publish_hz_ =
      std::max(1.0, declare_parameter<double>("cmd_vel_publish_hz", cmd_vel_publish_hz_));
    stop_on_lost_ = declare_parameter<bool>("stop_on_lost", stop_on_lost_);

    process_interval_s_ = std::max(0.0, declare_parameter<double>("process_interval_s", process_interval_s_));
    wechat_scale_ = declare_parameter<double>("wechat_scale", wechat_scale_);
    if (wechat_scale_ <= 0.0) {
      wechat_scale_ = 1.0;
    }
    wechat_full_resolution_retry_ =
      declare_parameter<bool>("wechat_full_resolution_retry", wechat_full_resolution_retry_);
    zbar_qrcode_only_ = declare_parameter<bool>("zbar_qrcode_only", zbar_qrcode_only_);
  }

  std::string defaultModelPath() const
  {
    try {
      return ament_index_cpp::get_package_share_directory("fusion_nav") + "/model";
    } catch (const std::exception &) {
      return "/home/wc/CH1/yellow_channel_ws/src/fusion_nav/model";
    }
  }

  void initWeChatModel()
  {
    if (!enable_qr_decode_) {
      return;
    }

    std::string path = model_path_;
    if (!path.empty() && path.back() != '/') {
      path += '/';
    }

    try {
      wechat_detector_ = cv::makePtr<cv::wechat_qrcode::WeChatQRCode>(
        path + "detect.prototxt",
        path + "detect.caffemodel",
        path + "sr.prototxt",
        path + "sr.caffemodel");
      RCLCPP_INFO(get_logger(), "WeChatQRCode model loaded from %s", model_path_.c_str());
    } catch (const cv::Exception &error) {
      RCLCPP_ERROR(get_logger(), "WeChatQRCode model load failed: %s", error.what());
    } catch (const std::exception &error) {
      RCLCPP_ERROR(get_logger(), "WeChatQRCode model load failed: %s", error.what());
    }
  }

  void initZBarScanner()
  {
    if (!enable_qr_decode_) {
      return;
    }
#ifdef QR_TRACKING_DECODER_HAS_ZBAR
    try {
      if (zbar_qrcode_only_) {
        zbar_scanner_.set_config(zbar::ZBAR_NONE, zbar::ZBAR_CFG_ENABLE, 0);
        zbar_scanner_.set_config(zbar::ZBAR_QRCODE, zbar::ZBAR_CFG_ENABLE, 1);
      } else {
        zbar_scanner_.set_config(zbar::ZBAR_NONE, zbar::ZBAR_CFG_ENABLE, 1);
      }
      RCLCPP_INFO(get_logger(), "ZBar scanner enabled");
    } catch (const std::exception &error) {
      RCLCPP_ERROR(get_logger(), "ZBar initialization failed: %s", error.what());
    }
#else
    RCLCPP_WARN(get_logger(), "ZBar development files not found at build time; using WeChatQRCode only");
#endif
  }

  void targetCallback(const PerceptionTargets::SharedPtr msg)
  {
    PointTarget best_point;
    QrTarget best_qr;
    ObstacleTarget best_obstacle;
    bool found_point = false;
    bool found_qr = false;
    bool found_obstacle = false;

    for (const auto &target : msg->targets) {
      if (target.rois.empty()) {
        continue;
      }
      const auto &roi = target.rois.front();
      const auto &rect = roi.rect;
      const int center_x = rect.x_offset + rect.width / 2;
      const int center_y = rect.y_offset + rect.height / 2;
      const int size = rect.width * rect.height;

      if (target.type == point_label_ && roi.confidence > point_confidence_threshold_) {
        if (!found_point || center_y < best_point.center_y) {
          best_point.center_x = center_x;
          best_point.center_y = center_y;
          best_point.confidence = roi.confidence;
          found_point = true;
        }
      }

      if (target.type == qr_label_ && roi.confidence > qr_confidence_threshold_) {
        if (!found_qr || size > best_qr.size) {
          best_qr.center_x = center_x;
          best_qr.center_y = center_y;
          best_qr.size = size;
          best_qr.confidence = roi.confidence;
          found_qr = true;
        }
      }

      if (
        enable_obstacle_avoidance_ &&
        target.type == obstacle_label_ &&
        roi.confidence > obstacle_confidence_threshold_)
      {
        const int bottom = rect.y_offset + rect.height;
        if (!found_obstacle || bottom > best_obstacle.bottom) {
          best_obstacle.center_x = center_x;
          best_obstacle.left = rect.x_offset;
          best_obstacle.right = rect.x_offset + rect.width;
          best_obstacle.bottom = bottom;
          best_obstacle.confidence = roi.confidence;
          found_obstacle = true;
        }
      }
    }

    std::lock_guard<std::mutex> lock(state_mutex_);
    has_latest_point_ = found_point;
    if (found_point) {
      latest_point_ = best_point;
    }
    has_latest_qr_ = found_qr;
    if (found_qr) {
      latest_qr_ = best_qr;
    }
    has_latest_obstacle_ = found_obstacle;
    if (found_obstacle) {
      latest_obstacle_ = best_obstacle;
    }
  }

  void imageCallback(const sensor_msgs::msg::Image::SharedPtr msg)
  {
    if (!enable_qr_decode_ || decoded_.load()) {
      return;
    }

    const auto now = this->now();
    if ((now - last_image_time_).seconds() < process_interval_s_) {
      return;
    }
    last_image_time_ = now;

    {
      std::lock_guard<std::mutex> lock(queue_mutex_);
      latest_frame_ = msg;
      has_new_frame_ = true;
    }
    queue_cv_.notify_one();
  }

  void processingLoop()
  {
    while (true) {
      sensor_msgs::msg::Image::SharedPtr frame;
      {
        std::unique_lock<std::mutex> lock(queue_mutex_);
        queue_cv_.wait(lock, [this] {
          return has_new_frame_ || stop_processing_;
        });

        if (stop_processing_) {
          return;
        }

        frame = latest_frame_;
        has_new_frame_ = false;
      }

      if (frame) {
        processImage(frame);
      }
    }
  }

  void processImage(const sensor_msgs::msg::Image::SharedPtr &msg)
  {
    cv::Mat gray;
    if (!extractGrayImage(msg, gray)) {
      return;
    }

    DecodeResult result = decodeWithZBar(gray);
    if (!result.decoded) {
      result = decodeWithWeChat(gray);
    }
    if (
      !result.decoded &&
      wechat_full_resolution_retry_ &&
      std::abs(wechat_scale_ - 1.0) > 1e-6)
    {
      result = decodeWithWeChat(gray, 1.0);
    }

    if (result.decoded && !result.text.empty()) {
      publishDecodedResult(result.text);
    }
  }

  std::string normalizeEncoding(std::string encoding) const
  {
    std::transform(
      encoding.begin(),
      encoding.end(),
      encoding.begin(),
      [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return encoding;
  }

  bool extractGrayImage(const sensor_msgs::msg::Image::SharedPtr &msg, cv::Mat &gray)
  {
    if (!msg) {
      return false;
    }

    const std::string encoding = normalizeEncoding(msg->encoding);
    const int width = static_cast<int>(msg->width);
    const int height = static_cast<int>(msg->height);
    const size_t step = msg->step > 0 ? msg->step : msg->width;

    if (width <= 0 || height <= 0 || step < static_cast<size_t>(width)) {
      RCLCPP_ERROR(get_logger(), "invalid image size: %dx%d step=%zu", width, height, step);
      return false;
    }

    if (encoding == "nv12" || encoding == "nv21" || encoding == "mono8" || encoding == "8uc1") {
      const size_t required_size = step * static_cast<size_t>(height);
      if (msg->data.size() < required_size) {
        RCLCPP_ERROR(
          get_logger(),
          "invalid %s image data size: %zu, expected at least %zu",
          msg->encoding.c_str(),
          msg->data.size(),
          required_size);
        return false;
      }

      cv::Mat gray_view(height, width, CV_8UC1, const_cast<uint8_t *>(msg->data.data()), step);
      gray = gray_view.clone();
      return true;
    }

    if (encoding == "bgr8" || encoding == "rgb8" || encoding == "bgra8" || encoding == "rgba8") {
      const int channels = (encoding == "bgr8" || encoding == "rgb8") ? 3 : 4;
      const size_t min_step = static_cast<size_t>(width) * static_cast<size_t>(channels);
      const size_t required_size = step * static_cast<size_t>(height);
      if (step < min_step || msg->data.size() < required_size) {
        RCLCPP_ERROR(get_logger(), "invalid %s image buffer", msg->encoding.c_str());
        return false;
      }

      const int type = channels == 3 ? CV_8UC3 : CV_8UC4;
      cv::Mat color(height, width, type, const_cast<uint8_t *>(msg->data.data()), step);
      int code = cv::COLOR_BGR2GRAY;
      if (encoding == "rgb8") {
        code = cv::COLOR_RGB2GRAY;
      } else if (encoding == "bgra8") {
        code = cv::COLOR_BGRA2GRAY;
      } else if (encoding == "rgba8") {
        code = cv::COLOR_RGBA2GRAY;
      }
      cv::cvtColor(color, gray, code);
      return true;
    }

    RCLCPP_ERROR(get_logger(), "unsupported image encoding: %s", msg->encoding.c_str());
    return false;
  }

  DecodeResult decodeWithZBar(const cv::Mat &gray)
  {
    DecodeResult result;
#ifdef QR_TRACKING_DECODER_HAS_ZBAR
    try {
      zbar::Image zbar_image(gray.cols, gray.rows, "Y800", gray.data, gray.cols * gray.rows);
      const int count = zbar_scanner_.scan(zbar_image);
      if (count <= 0) {
        return result;
      }

      for (zbar::Image::SymbolIterator symbol = zbar_image.symbol_begin();
        symbol != zbar_image.symbol_end();
        ++symbol)
      {
        result.text = symbol->get_data();
        result.decoded = !result.text.empty();

        const unsigned int location_size = symbol->get_location_size();
        if (location_size > 0U) {
          double sum_x = 0.0;
          double sum_y = 0.0;
          for (unsigned int i = 0; i < location_size; ++i) {
            sum_x += static_cast<double>(symbol->get_location_x(i));
            sum_y += static_cast<double>(symbol->get_location_y(i));
          }
          result.located = true;
          result.location.valid = true;
          result.location.center_x = sum_x / static_cast<double>(location_size);
          result.location.center_y = sum_y / static_cast<double>(location_size);
          result.location.image_width = gray.cols;
          result.location.image_height = gray.rows;
        }
        return result;
      }
    } catch (const std::exception &error) {
      RCLCPP_ERROR(get_logger(), "ZBar decode failed: %s", error.what());
    }
#else
    (void)gray;
#endif
    return result;
  }

  DecodeResult decodeWithWeChat(const cv::Mat &gray, double scale = -1.0)
  {
    DecodeResult result;
    if (!wechat_detector_) {
      return result;
    }

    const double active_scale = scale > 0.0 ? scale : wechat_scale_;
    cv::Mat decode_image;
    if (std::abs(active_scale - 1.0) > 1e-6) {
      const int resized_width = std::max(1, static_cast<int>(std::lround(gray.cols * active_scale)));
      const int resized_height = std::max(1, static_cast<int>(std::lround(gray.rows * active_scale)));
      cv::resize(
        gray,
        decode_image,
        cv::Size(resized_width, resized_height),
        0,
        0,
        active_scale < 1.0 ? cv::INTER_AREA : cv::INTER_LINEAR);
    } else {
      decode_image = gray;
    }

    try {
      std::vector<cv::Mat> points;
      const std::vector<cv::String> decoded_info =
        wechat_detector_->detectAndDecode(decode_image, points);

      for (std::size_t i = 0; i < points.size(); ++i) {
        QrLocation location = locationFromPoints(points[i], active_scale, gray.cols, gray.rows);
        if (location.valid && !result.located) {
          result.located = true;
          result.location = location;
        }

        if (i < decoded_info.size() && !decoded_info[i].empty()) {
          result.decoded = true;
          result.text = decoded_info[i];
          if (location.valid) {
            result.located = true;
            result.location = location;
          }
          return result;
        }
      }

      for (const auto &info : decoded_info) {
        if (!info.empty()) {
          result.decoded = true;
          result.text = info;
          return result;
        }
      }
    } catch (const cv::Exception &error) {
      RCLCPP_ERROR(get_logger(), "WeChatQRCode decode failed: %s", error.what());
    }

    return result;
  }

  QrLocation locationFromPoints(
    const cv::Mat &points,
    double scale,
    int image_width,
    int image_height) const
  {
    QrLocation location;
    if (points.empty()) {
      return location;
    }

    cv::Mat point_matrix;
    points.convertTo(point_matrix, CV_32F);

    std::vector<cv::Point2f> extracted;
    if (point_matrix.channels() == 2) {
      for (int r = 0; r < point_matrix.rows; ++r) {
        for (int c = 0; c < point_matrix.cols; ++c) {
          extracted.push_back(point_matrix.at<cv::Point2f>(r, c));
        }
      }
    } else if (point_matrix.cols >= 2) {
      for (int r = 0; r < point_matrix.rows; ++r) {
        extracted.emplace_back(point_matrix.at<float>(r, 0), point_matrix.at<float>(r, 1));
      }
    } else if (point_matrix.rows >= 2) {
      for (int c = 0; c < point_matrix.cols; ++c) {
        extracted.emplace_back(point_matrix.at<float>(0, c), point_matrix.at<float>(1, c));
      }
    }

    if (extracted.empty()) {
      return location;
    }

    double sum_x = 0.0;
    double sum_y = 0.0;
    const double safe_scale = scale > 1e-6 ? scale : 1.0;
    for (const auto &point : extracted) {
      sum_x += static_cast<double>(point.x) / safe_scale;
      sum_y += static_cast<double>(point.y) / safe_scale;
    }

    location.valid = true;
    location.center_x = sum_x / static_cast<double>(extracted.size());
    location.center_y = sum_y / static_cast<double>(extracted.size());
    location.image_width = image_width;
    location.image_height = image_height;
    return location;
  }

  void publishDecodedResult(const std::string &text)
  {
    if (text.empty()) {
      return;
    }

    bool expected = false;
    if (!decoded_.compare_exchange_strong(expected, true)) {
      return;
    }

    set_parameter(rclcpp::Parameter("last_qr_code_result", text));

    std_msgs::msg::String msg;
    msg.data = text;
    result_pub_->publish(msg);
    cmd_vel_pub_->publish(makeStoppedTwist());

    RCLCPP_INFO(get_logger(), "QR decoded successfully: %s", text.c_str());
  }

  void cmdTimerCallback()
  {
    if (decoded_.load()) {
      cmd_vel_pub_->publish(makeStoppedTwist());
      return;
    }

    PointTarget point;
    QrTarget qr;
    ObstacleTarget obstacle;
    bool has_point = false;
    bool has_qr = false;
    bool has_obstacle = false;
    MotionState motion_state = MotionState::NORMAL;
    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      has_point = has_latest_point_;
      point = latest_point_;
      has_qr = has_latest_qr_;
      qr = latest_qr_;
      has_obstacle = has_latest_obstacle_;
      obstacle = latest_obstacle_;
      motion_state = motion_state_;
    }

    if (enable_obstacle_avoidance_) {
      const bool obstacle_active = has_obstacle && isObstacleActive(obstacle);

      if (motion_state == MotionState::OBSTACLE_AVOIDING) {
        if (obstacle_active) {
          publishObstacleAvoidCommand(obstacle);
        } else {
          enterObstacleReturnBuffer();
          publishObstacleBufferCommand();
        }
        return;
      }

      if (motion_state == MotionState::RETURN_TO_LINE) {
        if (obstacle_active) {
          enterObstacleAvoiding();
          publishObstacleAvoidCommand(obstacle);
        } else {
          publishReturnToLineCommand();
        }
        return;
      }

      if (obstacle_active) {
        enterObstacleAvoiding();
        publishObstacleAvoidCommand(obstacle);
        return;
      }
    } else if (motion_state != MotionState::NORMAL) {
      resetObstacleState();
    }

    if (enable_qr_tracking_ && has_qr) {
      publishQrCommand(qr);
      return;
    }

    if (enable_line_following_ && has_point) {
      publishLineCommand(point);
      return;
    }

    resetLinePid();
    if (stop_on_lost_) {
      cmd_vel_pub_->publish(makeStoppedTwist());
    }
  }

  void publishQrCommand(const QrTarget &qr)
  {
    if (qr.size >= qr_stop_size_) {
      cmd_vel_pub_->publish(makeStoppedTwist());
      return;
    }

    const double image_center_x = static_cast<double>(image_width_) / 2.0;
    double error_px = image_center_x - static_cast<double>(qr.center_x);
    if (std::abs(error_px) < static_cast<double>(qr_dead_zone_px_)) {
      error_px = 0.0;
    }

    geometry_msgs::msg::Twist twist;
    twist.linear.x = qr_linear_speed_ * (qr.size > qr_size_threshold_ ? qr_approach_slowdown_ : 1.0);
    twist.angular.z = std::clamp(
      qr_angular_ratio_ * error_px,
      -max_angular_velocity_,
      max_angular_velocity_);
    cmd_vel_pub_->publish(twist);
  }

  void publishLineCommand(const PointTarget &point)
  {
    const double image_center_x = static_cast<double>(image_width_) / 2.0;
    double error_px = image_center_x - static_cast<double>(point.center_x);
    if (std::abs(error_px) < static_cast<double>(line_dead_zone_px_)) {
      error_px = 0.0;
    }

    const double pid_error = line_angular_ratio_ * error_px / std::max(1.0, image_center_x);
    const rclcpp::Time now = get_clock()->now();
    double dt = line_pid_initialized_ ? (now - line_last_time_).seconds() : 0.05;
    if (dt <= 1e-6) {
      dt = 0.05;
    }

    line_error_sum_ += pid_error * dt;
    const double error_diff = line_pid_initialized_ ? (pid_error - line_last_error_) / dt : 0.0;
    const double output = line_kp_ * pid_error + line_ki_ * line_error_sum_ + line_kd_ * error_diff;

    line_last_error_ = pid_error;
    line_last_time_ = now;
    line_pid_initialized_ = true;

    geometry_msgs::msg::Twist twist;
    twist.linear.x = line_linear_speed_;
    twist.angular.z = std::clamp(output, -max_angular_velocity_, max_angular_velocity_);
    cmd_vel_pub_->publish(twist);
  }

  bool isObstacleInEffectiveArea(const ObstacleTarget &obstacle) const
  {
    return obstacle.right > obstacle_effective_area_left_ &&
           obstacle.left < obstacle_effective_area_right_;
  }

  bool isObstacleActive(const ObstacleTarget &obstacle) const
  {
    return obstacle.bottom >= obstacle_bottom_threshold_ && isObstacleInEffectiveArea(obstacle);
  }

  void enterObstacleAvoiding()
  {
    bool changed = false;
    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      if (motion_state_ != MotionState::OBSTACLE_AVOIDING) {
        motion_state_ = MotionState::OBSTACLE_AVOIDING;
        obstacle_in_buffer_ = false;
        last_obstacle_angular_z_ = 0.0;
        changed = true;
      }
    }

    if (changed) {
      RCLCPP_INFO(get_logger(), "detected obstacle, entering obstacle avoidance");
    }
  }

  void enterObstacleReturnBuffer()
  {
    bool should_enter = false;
    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      if (!obstacle_in_buffer_) {
        obstacle_in_buffer_ = true;
        obstacle_buffer_start_time_ = get_clock()->now();
        should_enter = true;
      }
    }

    if (should_enter) {
      RCLCPP_INFO(get_logger(), "obstacle lost or inactive, entering safety buffer");
    }
  }

  void enterReturnToLine()
  {
    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      motion_state_ = MotionState::RETURN_TO_LINE;
      obstacle_in_buffer_ = false;
      obstacle_return_start_time_ = get_clock()->now();
    }
    RCLCPP_INFO(get_logger(), "obstacle safety buffer finished, returning to line");
  }

  void finishReturnToLine()
  {
    resetObstacleState();
    resetLinePid();
    RCLCPP_INFO(get_logger(), "return to line finished, back to normal tracking");
  }

  void resetObstacleState()
  {
    std::lock_guard<std::mutex> lock(state_mutex_);
    motion_state_ = MotionState::NORMAL;
    obstacle_in_buffer_ = false;
    first_obstacle_avoid_recorded_ = false;
    last_obstacle_direction_ = TurnDirection::UNKNOWN;
    first_obstacle_abs_angular_ = 0.0;
    last_obstacle_angular_z_ = 0.0;
  }

  void publishObstacleAvoidCommand(const ObstacleTarget &obstacle)
  {
    const double image_height = static_cast<double>(std::max(1, image_height_));
    const double image_center_x = static_cast<double>(image_width_) / 2.0;
    double deviation = static_cast<double>(obstacle.center_x) - image_center_x;
    if (std::abs(deviation) < static_cast<double>(obstacle_deviation_threshold_)) {
      deviation = deviation >= 0.0 ?
        static_cast<double>(obstacle_deviation_threshold_) :
        -static_cast<double>(obstacle_deviation_threshold_);
    }

    const double distance_factor =
      1.0 - std::clamp(static_cast<double>(obstacle.bottom) / image_height, 0.0, 1.0);
    const double sensitivity = 1.0 + (2.0 * distance_factor);
    double angular_z =
      obstacle_angular_ratio_ * sensitivity * 700.0 / std::max(std::abs(deviation), 1.0);
    if (deviation < 0.0) {
      angular_z = -angular_z;
    }
    angular_z = std::clamp(angular_z, -max_angular_velocity_, max_angular_velocity_);

    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      const double angular_diff = std::abs(angular_z - last_obstacle_angular_z_);
      if (angular_diff > 4.0) {
        angular_z = last_obstacle_angular_z_;
      } else {
        last_obstacle_angular_z_ = angular_z;
      }

      if (!first_obstacle_avoid_recorded_) {
        first_obstacle_abs_angular_ = std::abs(angular_z);
        first_obstacle_avoid_recorded_ = true;
      }
      last_obstacle_direction_ = angular_z < 0.0 ? TurnDirection::RIGHT : TurnDirection::LEFT;
    }

    geometry_msgs::msg::Twist twist;
    twist.linear.x = obstacle_linear_speed_ * (1.0 - distance_factor * 0.5);
    twist.angular.z = angular_z;
    cmd_vel_pub_->publish(twist);
  }

  void publishObstacleBufferCommand()
  {
    rclcpp::Time buffer_start;
    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      buffer_start = obstacle_buffer_start_time_;
    }

    if ((get_clock()->now() - buffer_start).seconds() >= obstacle_safe_duration_) {
      enterReturnToLine();
      publishReturnToLineCommand();
      return;
    }

    geometry_msgs::msg::Twist twist;
    twist.linear.x = obstacle_buffer_linear_speed_;
    twist.angular.z = 0.0;
    cmd_vel_pub_->publish(twist);
  }

  void publishReturnToLineCommand()
  {
    TurnDirection direction;
    double first_abs_angular = 0.0;
    rclcpp::Time return_start;
    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      direction = last_obstacle_direction_;
      first_abs_angular = first_obstacle_abs_angular_;
      return_start = obstacle_return_start_time_;
    }

    const bool last_turn_left = direction == TurnDirection::LEFT;
    const double duration =
      last_turn_left ? obstacle_return_duration_left_ : obstacle_return_duration_right_;
    const double ratio =
      last_turn_left ? obstacle_return_angular_speed_left_ : obstacle_return_angular_speed_right_;

    if ((get_clock()->now() - return_start).seconds() >= duration) {
      finishReturnToLine();
      return;
    }

    double angular_z = first_abs_angular * ratio;
    if (last_turn_left) {
      angular_z = -angular_z;
    }
    angular_z = std::clamp(angular_z, -max_angular_velocity_, max_angular_velocity_);

    geometry_msgs::msg::Twist twist;
    twist.linear.x = obstacle_return_linear_speed_;
    twist.angular.z = angular_z;
    cmd_vel_pub_->publish(twist);
  }

  void resetLinePid()
  {
    line_last_error_ = 0.0;
    line_error_sum_ = 0.0;
    line_pid_initialized_ = false;
  }

  std::string target_topic_{"dnn_node_sample"};
  std::string image_topic_{"/nv12"};
  std::string output_topic_{"/qr_code_result"};
  std::string cmd_vel_topic_{"/cmd_vel"};
  std::string model_path_;
  std::string point_label_{"point"};
  std::string qr_label_{"qr"};
  std::string obstacle_label_{"tong"};
  int image_width_{640};
  int image_height_{480};
  double point_confidence_threshold_{0.7};
  double qr_confidence_threshold_{0.7};
  double obstacle_confidence_threshold_{0.7};
  bool enable_line_following_{true};
  bool enable_qr_tracking_{true};
  bool enable_qr_decode_{true};
  bool enable_obstacle_avoidance_{true};

  double line_linear_speed_{0.6};
  double line_angular_ratio_{0.8};
  int line_dead_zone_px_{30};
  double line_kp_{0.8};
  double line_ki_{0.0};
  double line_kd_{0.7};

  double qr_linear_speed_{0.12};
  double qr_angular_ratio_{0.01};
  int qr_size_threshold_{200};
  double qr_approach_slowdown_{0.3};
  int qr_stop_size_{3800};
  int qr_dead_zone_px_{30};

  int obstacle_bottom_threshold_{300};
  int obstacle_effective_area_left_{180};
  int obstacle_effective_area_right_{460};
  double obstacle_angular_ratio_{0.05};
  double obstacle_linear_speed_{0.3};
  int obstacle_deviation_threshold_{50};
  double obstacle_safe_duration_{0.5};
  double obstacle_return_linear_speed_{0.5};
  double obstacle_return_duration_left_{0.7};
  double obstacle_return_duration_right_{0.7};
  double obstacle_return_angular_speed_left_{0.5};
  double obstacle_return_angular_speed_right_{1.0};
  double obstacle_buffer_linear_speed_{0.3};

  double max_angular_velocity_{0.8};
  double cmd_vel_publish_hz_{20.0};
  bool stop_on_lost_{true};
  double process_interval_s_{0.05};
  double wechat_scale_{0.5};
  bool wechat_full_resolution_retry_{true};
  bool zbar_qrcode_only_{true};

  std::atomic<bool> decoded_{false};
  rclcpp::Time last_image_time_{0, 0, RCL_ROS_TIME};

  std::mutex queue_mutex_;
  std::condition_variable queue_cv_;
  sensor_msgs::msg::Image::SharedPtr latest_frame_;
  bool has_new_frame_{false};
  bool stop_processing_{false};
  std::thread processing_thread_;

  std::mutex state_mutex_;
  PointTarget latest_point_;
  QrTarget latest_qr_;
  ObstacleTarget latest_obstacle_;
  bool has_latest_point_{false};
  bool has_latest_qr_{false};
  bool has_latest_obstacle_{false};

  MotionState motion_state_{MotionState::NORMAL};
  bool obstacle_in_buffer_{false};
  rclcpp::Time obstacle_buffer_start_time_{0, 0, RCL_ROS_TIME};
  rclcpp::Time obstacle_return_start_time_{0, 0, RCL_ROS_TIME};
  double first_obstacle_abs_angular_{0.0};
  double last_obstacle_angular_z_{0.0};
  bool first_obstacle_avoid_recorded_{false};
  TurnDirection last_obstacle_direction_{TurnDirection::UNKNOWN};

  double line_last_error_{0.0};
  double line_error_sum_{0.0};
  rclcpp::Time line_last_time_{0, 0, RCL_ROS_TIME};
  bool line_pid_initialized_{false};

  cv::Ptr<cv::wechat_qrcode::WeChatQRCode> wechat_detector_;
#ifdef QR_TRACKING_DECODER_HAS_ZBAR
  zbar::ImageScanner zbar_scanner_;
#endif

  rclcpp::Subscription<PerceptionTargets>::SharedPtr target_sub_;
  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr image_sub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr result_pub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  rclcpp::TimerBase::SharedPtr cmd_timer_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<QrTrackingDecoder>());
  rclcpp::shutdown();
  return 0;
}
