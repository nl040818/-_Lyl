#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <std_msgs/msg/string.hpp>
#include <ament_index_cpp/get_package_share_directory.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/wechat_qrcode.hpp>
#include <zbar.h>
#include <atomic>
#include <thread>
#include <memory>
#include <chrono>
#include <mutex>
#include <condition_variable>
#include <algorithm>
#include <cctype>

class QRDetector : public rclcpp::Node {
public:
    QRDetector() : Node("qr_detector") {
        // 从参数服务器获取模型路径
        this->declare_parameter<std::string>("model_path", defaultModelPath());
        std::string model_path;
        this->get_parameter("model_path", model_path);
        this->declare_parameter<std::string>("input_topic", "/nv12");
        std::string input_topic;
        this->get_parameter("input_topic", input_topic);
        this->declare_parameter<std::string>("output_topic", "/qr_code_result");
        std::string output_topic;
        this->get_parameter("output_topic", output_topic);
        this->declare_parameter<std::string>("last_qr_code_result", "");
        this->declare_parameter<double>("process_interval_s", 0.05);
        this->get_parameter("process_interval_s", process_interval_s_);
        this->declare_parameter<double>("wechat_scale", 0.5);
        this->get_parameter("wechat_scale", wechat_scale_);
        this->declare_parameter<bool>("wechat_full_resolution_retry", true);
        this->get_parameter("wechat_full_resolution_retry", wechat_full_resolution_retry_);
        this->declare_parameter<bool>("zbar_qrcode_only", true);
        this->get_parameter("zbar_qrcode_only", zbar_qrcode_only_);
        this->declare_parameter<bool>("stop_after_detection", true);
        this->get_parameter("stop_after_detection", stop_after_detection_);
        this->declare_parameter<bool>("shutdown_after_detection", true);
        this->get_parameter("shutdown_after_detection", shutdown_after_detection_);
        this->declare_parameter<int>("publish_repeats", 3);
        this->get_parameter("publish_repeats", publish_repeats_);
        this->declare_parameter<double>("publish_interval_s", 1.0);
        this->get_parameter("publish_interval_s", publish_interval_s_);

        if (process_interval_s_ < 0.0) process_interval_s_ = 0.0;
        if (wechat_scale_ <= 0.0) wechat_scale_ = 1.0;
        if (publish_repeats_ < 1) publish_repeats_ = 1;
        if (publish_interval_s_ < 0.0) publish_interval_s_ = 0.0;

        // 初始化WeChatQRCode检测器
        if (!initWeChatModel(model_path)) {
            RCLCPP_ERROR(this->get_logger(), "Failed to initialize WeChatQRCode detector");
        } else {
            RCLCPP_INFO(this->get_logger(), "WeChatQRCode detector initialized");
        }

        // 初始化ZBar扫描器
        initZBarScanner();
        
        // 订阅与YOLO识别节点一致的NV12图像
        image_sub_ = this->create_subscription<sensor_msgs::msg::Image>(
            input_topic, rclcpp::SensorDataQoS(),
            std::bind(&QRDetector::imageCallback, this, std::placeholders::_1));
        
        // 发布二维码结果
        pub_ = this->create_publisher<std_msgs::msg::String>(output_topic, 1);
        
        detected_ = false;
        last_image_time_ = this->now();
        
        RCLCPP_INFO(this->get_logger(), "QR Detector Node started with dual decoders");
        RCLCPP_INFO(this->get_logger(), "Subscribing to %s", input_topic.c_str());
        RCLCPP_INFO(this->get_logger(),
                    "Publishing to %s, interval=%.3fs, wechat_scale=%.2f, zbar_qrcode_only=%s",
                    output_topic.c_str(), process_interval_s_, wechat_scale_,
                    zbar_qrcode_only_ ? "true" : "false");
        
        // 启动处理线程
        processing_thread_ = std::thread(&QRDetector::processingLoop, this);
    }

    ~QRDetector() {
        // 通知处理线程退出
        {
            std::lock_guard<std::mutex> lock(queue_mutex_);
            stop_processing_ = true;
        }
        queue_cv_.notify_all();
        
        // 等待处理线程结束
        if (processing_thread_.joinable()) {
            processing_thread_.join();
        }
    }

private:
    std::string defaultModelPath() {
        try {
            return ament_index_cpp::get_package_share_directory("fusion_nav") + "/model";
        } catch (const std::exception& e) {
            RCLCPP_WARN(this->get_logger(),
                        "Failed to get fusion_nav share directory, fallback to source model path: %s",
                        e.what());
            return "/home/wc/CH1/yellow_channel_ws/src/fusion_nav/model";
        }
    }

    bool initWeChatModel(const std::string& model_path) {
        // 确保路径以斜杠结尾
        std::string path = model_path;
        if (!path.empty() && path.back() != '/') path += '/';

        // 构建模型文件路径
        std::string detect_prototxt = path + "detect.prototxt";
        std::string detect_caffe_model = path + "detect.caffemodel";
        std::string sr_prototxt = path + "sr.prototxt";
        std::string sr_caffe_model = path + "sr.caffemodel";

        try {
            // 创建WeChat二维码检测器
            wechat_detector_ = cv::makePtr<cv::wechat_qrcode::WeChatQRCode>(
                detect_prototxt, detect_caffe_model, sr_prototxt, sr_caffe_model);
            return true;
        } catch (const cv::Exception& e) {
            RCLCPP_ERROR(this->get_logger(), "OpenCV exception: %s", e.what());
        } catch (const std::exception& e) {
            RCLCPP_ERROR(this->get_logger(), "Standard exception: %s", e.what());
        }
        return false;
    }

    void initZBarScanner() {
        try {
            if (zbar_qrcode_only_) {
                zbar_scanner_.set_config(zbar::ZBAR_NONE, zbar::ZBAR_CFG_ENABLE, 0);
                zbar_scanner_.set_config(zbar::ZBAR_QRCODE, zbar::ZBAR_CFG_ENABLE, 1);
            } else {
                zbar_scanner_.set_config(zbar::ZBAR_NONE, zbar::ZBAR_CFG_ENABLE, 1);
            }
            RCLCPP_INFO(this->get_logger(), "ZBar scanner initialized");
        } catch (const std::exception& e) {
            RCLCPP_ERROR(this->get_logger(), "ZBar initialization error: %s", e.what());
        }
    }

    void imageCallback(const sensor_msgs::msg::Image::SharedPtr msg) {
        if (stop_after_detection_ && detected_) return;

        // 控制处理频率
        auto now = this->now();
        if ((now - last_image_time_).seconds() < process_interval_s_) return;
        last_image_time_ = now;

        // 添加到处理队列 - 使用指针直接传递，避免拷贝
        {
            std::lock_guard<std::mutex> lock(queue_mutex_);
            // 只保留最新帧
            latest_frame_ = msg;
            has_new_frame_ = true;
            queue_cv_.notify_one();
        }
    }

    void processingLoop() {
        while (true) {
            sensor_msgs::msg::Image::SharedPtr frame;
            bool process_frame = false;
            
            {
                std::unique_lock<std::mutex> lock(queue_mutex_);
                queue_cv_.wait(lock, [this] {
                    return has_new_frame_ || stop_processing_;
                });
                
                if (stop_processing_) return;
                
                // 获取最新帧并重置标志
                if (has_new_frame_) {
                    frame = latest_frame_;
                    process_frame = true;
                    has_new_frame_ = false;
                }
            }
            
            // 处理NV12帧
            if (process_frame) {
                processNV12Image(frame);
            }
        }
    }

    void processNV12Image(const sensor_msgs::msg::Image::SharedPtr msg) {
    try {
        cv::Mat gray;
        if (!extractGrayImage(msg, gray)) {
            return;
        }

        // 优先使用 ZBar；失败后再回退到 WeChatQRCode。
        std::string zbar_result = decodeWithZBar(gray);
        if (!zbar_result.empty()) {
            RCLCPP_INFO(this->get_logger(), "ZBar QR Code detected: %s", zbar_result.c_str());
            publishResult(zbar_result);
            return;
        }

        std::string wechat_result = decodeWithWeChat(gray);
        if (!wechat_result.empty()) {
            RCLCPP_INFO(this->get_logger(), "WeChat QR Code detected: %s", wechat_result.c_str());
            publishResult(wechat_result);
            return;
        }

        if (wechat_full_resolution_retry_ && wechat_scale_ != 1.0) {
            std::string retry_result = decodeWithWeChat(gray, 1.0);
            if (!retry_result.empty()) {
                RCLCPP_INFO(this->get_logger(),
                            "WeChat full-resolution QR Code detected: %s",
                            retry_result.c_str());
                publishResult(retry_result);
            }
        }
    } catch (const std::exception& e) {
        RCLCPP_ERROR(this->get_logger(), "Processing error: %s", e.what());
    }
}

    std::string normalizeEncoding(std::string encoding) const {
        std::transform(encoding.begin(), encoding.end(), encoding.begin(),
                       [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        return encoding;
    }

    bool extractGrayImage(const sensor_msgs::msg::Image::SharedPtr& msg, cv::Mat& gray) {
        if (!msg) return false;

        const std::string encoding = normalizeEncoding(msg->encoding);
        const int width = static_cast<int>(msg->width);
        const int height = static_cast<int>(msg->height);
        const size_t step = msg->step > 0 ? msg->step : msg->width;

        if (width <= 0 || height <= 0) {
            RCLCPP_ERROR(this->get_logger(), "Invalid image size: %dx%d", width, height);
            return false;
        }

        if (encoding == "nv12" || encoding == "nv21" || encoding == "mono8" || encoding == "8uc1") {
            if (step < static_cast<size_t>(width)) {
                RCLCPP_ERROR(this->get_logger(),
                             "Invalid image step: %zu, width: %d", step, width);
                return false;
            }

            const size_t required_size = step * static_cast<size_t>(height);
            if (msg->data.size() < required_size) {
                RCLCPP_ERROR(this->get_logger(),
                             "Invalid %s image data size: %zu, expected at least %zu",
                             msg->encoding.c_str(), msg->data.size(), required_size);
                return false;
            }

            cv::Mat gray_view(height, width, CV_8UC1,
                              const_cast<unsigned char*>(msg->data.data()), step);
            gray = gray_view.clone();
            return true;
        }

        if (encoding == "bgr8" || encoding == "rgb8" ||
            encoding == "bgra8" || encoding == "rgba8") {
            const int channels = (encoding == "bgr8" || encoding == "rgb8") ? 3 : 4;
            const size_t min_step = static_cast<size_t>(width) * channels;
            if (step < min_step) {
                RCLCPP_ERROR(this->get_logger(),
                             "Invalid %s image step: %zu, expected at least %zu",
                             msg->encoding.c_str(), step, min_step);
                return false;
            }

            const size_t required_size = step * static_cast<size_t>(height);
            if (msg->data.size() < required_size) {
                RCLCPP_ERROR(this->get_logger(),
                             "Invalid %s image data size: %zu, expected at least %zu",
                             msg->encoding.c_str(), msg->data.size(), required_size);
                return false;
            }

            const int type = channels == 3 ? CV_8UC3 : CV_8UC4;
            cv::Mat color(height, width, type,
                          const_cast<unsigned char*>(msg->data.data()), step);
            int code = cv::COLOR_BGR2GRAY;
            if (encoding == "rgb8") code = cv::COLOR_RGB2GRAY;
            if (encoding == "bgra8") code = cv::COLOR_BGRA2GRAY;
            if (encoding == "rgba8") code = cv::COLOR_RGBA2GRAY;
            cv::cvtColor(color, gray, code);
            return true;
        }

        RCLCPP_ERROR(this->get_logger(),
                     "Unsupported image encoding: %s, expected nv12/nv21/mono8/bgr8/rgb8/bgra8/rgba8",
                     msg->encoding.c_str());
        return false;
    }

    std::string decodeWithWeChat(const cv::Mat& gray, double scale = -1.0) {
        if (!wechat_detector_) return "";
        
        try {
            const double active_scale = scale > 0.0 ? scale : wechat_scale_;
            cv::Mat decode_image;
            if (active_scale != 1.0) {
                const int resized_width = std::max(1, static_cast<int>(gray.cols * active_scale));
                const int resized_height = std::max(1, static_cast<int>(gray.rows * active_scale));
                cv::resize(gray, decode_image, cv::Size(resized_width, resized_height),
                           0, 0, active_scale < 1.0 ? cv::INTER_AREA : cv::INTER_LINEAR);
            } else {
                decode_image = gray;
            }
            
            // 执行二维码检测
            std::vector<cv::Mat> points;
            std::vector<cv::String> decoded_info = wechat_detector_->detectAndDecode(decode_image, points);
            
            // 返回第一个有效结果
            for (const auto& info : decoded_info) {
                if (!info.empty()) {
                    return info;
                }
            }
        } catch (const cv::Exception& e) {
            RCLCPP_ERROR(this->get_logger(), "WeChat decoding error: %s", e.what());
        }
        return "";
    }

    std::string decodeWithZBar(const cv::Mat& gray) {
        try {
            // 创建ZBar图像
            zbar::Image zbar_image(gray.cols, gray.rows, "Y800", gray.data, gray.cols * gray.rows);
            
            // 扫描二维码
            int n = zbar_scanner_.scan(zbar_image);
            
            // 返回第一个有效结果
            if (n > 0) {
                for (zbar::Image::SymbolIterator symbol = zbar_image.symbol_begin(); 
                     symbol != zbar_image.symbol_end(); 
                     ++symbol) {
                    return symbol->get_data();
                }
            }
        } catch (const std::exception& e) {
            RCLCPP_ERROR(this->get_logger(), "ZBar decoding error: %s", e.what());
        }
        return "";
    }

    void publishResult(const std::string& qr_data) {
        if (stop_after_detection_ && detected_.exchange(true)) {
            return;
        }

        set_parameter(rclcpp::Parameter("last_qr_code_result", qr_data));

        const int repeats = stop_after_detection_ ? publish_repeats_ : 1;
        for (int i = 0; i < repeats; ++i) {
            std_msgs::msg::String result_msg;
            result_msg.data = qr_data;
            pub_->publish(result_msg);
            RCLCPP_INFO(this->get_logger(), "Published QR result %d/%d: %s",
                        i + 1, repeats, qr_data.c_str());

            if (i + 1 < repeats && publish_interval_s_ > 0.0) {
                std::this_thread::sleep_for(std::chrono::duration<double>(publish_interval_s_));
            }
        }

        if (stop_after_detection_ && shutdown_after_detection_) {
            RCLCPP_INFO(this->get_logger(), "QR detection complete, shutting down");
            rclcpp::shutdown();
        }
    }

    // 订阅器和发布器
    rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr image_sub_;
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr pub_;
    
    // 状态变量
    std::atomic<bool> detected_;
    rclcpp::Time last_image_time_;
    double process_interval_s_;
    double wechat_scale_;
    bool wechat_full_resolution_retry_;
    bool zbar_qrcode_only_;
    bool stop_after_detection_;
    bool shutdown_after_detection_;
    int publish_repeats_;
    double publish_interval_s_;
    
    // 处理线程和队列
    std::thread processing_thread_;
    std::mutex queue_mutex_;
    std::condition_variable queue_cv_;
    bool stop_processing_ = false;
    
    // 最新帧缓存
    sensor_msgs::msg::Image::SharedPtr latest_frame_;
    bool has_new_frame_ = false;
    
    // 解码器实例
    cv::Ptr<cv::wechat_qrcode::WeChatQRCode> wechat_detector_;
    zbar::ImageScanner zbar_scanner_;
};

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<QRDetector>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
