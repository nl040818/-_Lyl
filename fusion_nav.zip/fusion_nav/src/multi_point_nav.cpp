/*
 * multi_point_nav
 *
 * 功能说明:
 * - 从 ROS2 参数/YAML 中读取多个导航目标点。
 * - 按顺序将目标点发送到 Nav2 的 NavigateToPose action，默认 /navigate_to_pose。
 * - 不直接发布 /cmd_vel，速度控制完全交给 Nav2。
 * - 发布当前多点导航状态到 /multi_point_nav/status，便于后续状态机判断进度。
 */

#include <algorithm>
#include <chrono>
#include <cstddef>
#include <memory>
#include <string>
#include <vector>

#include "geometry_msgs/msg/pose_stamped.hpp"
#include "nav2_msgs/action/navigate_to_pose.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "std_msgs/msg/string.hpp"

using namespace std::chrono_literals;

namespace
{
struct Waypoint
{
  std::string name;
  double x{0.0};
  double y{0.0};
  double qx{0.0};
  double qy{0.0};
  double qz{0.0};
  double qw{1.0};
};

geometry_msgs::msg::PoseStamped makePose(
  const Waypoint &waypoint,
  const std::string &frame_id,
  const rclcpp::Time &stamp)
{
  geometry_msgs::msg::PoseStamped pose;
  pose.header.frame_id = frame_id;
  pose.header.stamp = stamp;
  pose.pose.position.x = waypoint.x;
  pose.pose.position.y = waypoint.y;
  pose.pose.position.z = 0.0;

  pose.pose.orientation.x = waypoint.qx;
  pose.pose.orientation.y = waypoint.qy;
  pose.pose.orientation.z = waypoint.qz;
  pose.pose.orientation.w = waypoint.qw;
  return pose;
}
}  // namespace

class MultiPointNav : public rclcpp::Node
{
public:
  using NavigateToPose = nav2_msgs::action::NavigateToPose;
  using GoalHandleNavigateToPose = rclcpp_action::ClientGoalHandle<NavigateToPose>;

  MultiPointNav()
  : Node("multi_point_nav")
  {
    loadParameters();

    const auto status_qos = rclcpp::QoS(10).reliable().transient_local();
    status_pub_ = create_publisher<std_msgs::msg::String>(status_topic_, status_qos);
    action_client_ = rclcpp_action::create_client<NavigateToPose>(this, action_name_);

    publishStatus("stopped");
    start_timer_ = create_wall_timer(200ms, [this]() {
      start_timer_->cancel();
      startNavigation();
    });

    RCLCPP_INFO(
      get_logger(),
      "multi_point_nav started, action=%s, waypoints=%zu",
      action_name_.c_str(),
      waypoints_.size());
  }

private:
  void loadParameters()
  {
    action_name_ = declare_parameter<std::string>("action_name", action_name_);
    status_topic_ = declare_parameter<std::string>("status_topic", status_topic_);
    frame_id_ = declare_parameter<std::string>("frame_id", frame_id_);
    stop_on_failure_ = declare_parameter<bool>("stop_on_failure", stop_on_failure_);
    loop_ = declare_parameter<bool>("loop", loop_);
    action_server_timeout_sec_ = std::max(
      0.0, declare_parameter<double>("action_server_timeout_sec", action_server_timeout_sec_));
    wait_between_goals_sec_ = std::max(
      0.0, declare_parameter<double>("wait_between_goals_sec", wait_between_goals_sec_));

    std::vector<std::string> names =
      declare_parameter<std::vector<std::string>>("waypoint_names", {"p1", "p2", "p3"});
    std::vector<double> xs =
      declare_parameter<std::vector<double>>("waypoint_x", {0.0, 1.0, 2.0});
    std::vector<double> ys =
      declare_parameter<std::vector<double>>("waypoint_y", {0.0, 1.0, 0.5});
    std::vector<double> qxs =
      declare_parameter<std::vector<double>>("waypoint_qx", {0.0, 0.0, 0.0});
    std::vector<double> qys =
      declare_parameter<std::vector<double>>("waypoint_qy", {0.0, 0.0, 0.0});
    std::vector<double> qzs =
      declare_parameter<std::vector<double>>("waypoint_qz", {0.0, 0.0, 0.7068});
    std::vector<double> qws =
      declare_parameter<std::vector<double>>("waypoint_qw", {1.0, 1.0, 0.7074});

    if (xs.empty() || ys.empty() || qxs.empty() || qys.empty() || qzs.empty() || qws.empty()) {
      RCLCPP_ERROR(get_logger(), "Waypoint arrays cannot be empty");
      return;
    }
    if (
      xs.size() != ys.size() || xs.size() != qxs.size() || xs.size() != qys.size() ||
      xs.size() != qzs.size() || xs.size() != qws.size())
    {
      RCLCPP_ERROR(
        get_logger(),
        "Waypoint array sizes must match: x=%zu y=%zu qx=%zu qy=%zu qz=%zu qw=%zu",
        xs.size(),
        ys.size(),
        qxs.size(),
        qys.size(),
        qzs.size(),
        qws.size());
      return;
    }

    if (names.size() != xs.size()) {
      RCLCPP_WARN(
        get_logger(),
        "waypoint_names size does not match waypoint count; generating default names");
      names.clear();
      for (std::size_t i = 0; i < xs.size(); ++i) {
        names.push_back("p" + std::to_string(i + 1));
      }
    }

    waypoints_.clear();
    waypoints_.reserve(xs.size());
    for (std::size_t i = 0; i < xs.size(); ++i) {
      Waypoint waypoint;
      waypoint.name = names[i];
      waypoint.x = xs[i];
      waypoint.y = ys[i];
      waypoint.qx = qxs[i];
      waypoint.qy = qys[i];
      waypoint.qz = qzs[i];
      waypoint.qw = qws[i];
      waypoints_.push_back(waypoint);
    }
  }

  void startNavigation()
  {
    if (waypoints_.empty()) {
      publishStatus("stopped");
      RCLCPP_ERROR(get_logger(), "No valid waypoints loaded");
      return;
    }

    publishStatus("waiting_server");
    const auto timeout = std::chrono::duration_cast<std::chrono::nanoseconds>(
      std::chrono::duration<double>(action_server_timeout_sec_));
    if (!action_client_->wait_for_action_server(timeout)) {
      publishStatus("stopped");
      RCLCPP_ERROR(
        get_logger(),
        "NavigateToPose action server %s is not available",
        action_name_.c_str());
      return;
    }

    current_index_ = 0;
    sendCurrentGoal();
  }

  void sendCurrentGoal()
  {
    if (current_index_ >= waypoints_.size()) {
      if (loop_) {
        current_index_ = 0;
      } else {
        publishStatus("all_succeeded");
        RCLCPP_INFO(get_logger(), "All waypoints succeeded");
        return;
      }
    }

    const auto index = current_index_;
    const auto waypoint = waypoints_[index];

    NavigateToPose::Goal goal;
    goal.pose = makePose(waypoint, frame_id_, now());

    rclcpp_action::Client<NavigateToPose>::SendGoalOptions options;
    options.goal_response_callback = [this, index, waypoint](
      GoalHandleNavigateToPose::SharedPtr goal_handle) {
        onGoalResponse(index, waypoint, goal_handle);
      };
    options.result_callback = [this, index, waypoint](
      const GoalHandleNavigateToPose::WrappedResult &result) {
        onResult(index, waypoint, result);
      };

    publishStatus("running:" + waypoint.name);
    RCLCPP_INFO(
      get_logger(),
      "Sending waypoint %zu/%zu %s: x=%.3f y=%.3f q=(%.4f, %.4f, %.4f, %.4f)",
      index + 1,
      waypoints_.size(),
      waypoint.name.c_str(),
      waypoint.x,
      waypoint.y,
      waypoint.qx,
      waypoint.qy,
      waypoint.qz,
      waypoint.qw);
    action_client_->async_send_goal(goal, options);
  }

  void onGoalResponse(
    std::size_t index,
    const Waypoint &waypoint,
    const GoalHandleNavigateToPose::SharedPtr goal_handle)
  {
    if (index != current_index_) {
      return;
    }
    if (!goal_handle) {
      publishStatus("failed:" + waypoint.name);
      RCLCPP_WARN(get_logger(), "Waypoint %s was rejected", waypoint.name.c_str());
      handleFailure();
      return;
    }

    active_goal_handle_ = goal_handle;
  }

  void onResult(
    std::size_t index,
    const Waypoint &waypoint,
    const GoalHandleNavigateToPose::WrappedResult &result)
  {
    if (index != current_index_) {
      return;
    }

    active_goal_handle_.reset();
    if (result.code == rclcpp_action::ResultCode::SUCCEEDED) {
      publishStatus("succeeded:" + waypoint.name);
      RCLCPP_INFO(get_logger(), "Waypoint %s succeeded", waypoint.name.c_str());
      ++current_index_;
      scheduleNextGoal();
      return;
    }

    publishStatus("failed:" + waypoint.name);
    RCLCPP_WARN(get_logger(), "Waypoint %s failed or was canceled", waypoint.name.c_str());
    handleFailure();
  }

  void handleFailure()
  {
    if (stop_on_failure_) {
      publishStatus("stopped");
      return;
    }
    ++current_index_;
    scheduleNextGoal();
  }

  void scheduleNextGoal()
  {
    if (wait_between_goals_sec_ <= 0.0) {
      sendCurrentGoal();
      return;
    }

    const auto delay = std::chrono::duration_cast<std::chrono::nanoseconds>(
      std::chrono::duration<double>(wait_between_goals_sec_));
    next_goal_timer_ = create_wall_timer(delay, [this]() {
      next_goal_timer_->cancel();
      sendCurrentGoal();
    });
  }

  void publishStatus(const std::string &status)
  {
    if (status == last_status_) {
      return;
    }
    std_msgs::msg::String msg;
    msg.data = status;
    status_pub_->publish(msg);
    last_status_ = status;
  }

  std::string action_name_{"/navigate_to_pose"};
  std::string status_topic_{"/multi_point_nav/status"};
  std::string frame_id_{"map"};
  bool stop_on_failure_{true};
  bool loop_{false};
  double action_server_timeout_sec_{5.0};
  double wait_between_goals_sec_{0.2};

  std::vector<Waypoint> waypoints_;
  std::size_t current_index_{0};

  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr status_pub_;
  rclcpp_action::Client<NavigateToPose>::SharedPtr action_client_;
  GoalHandleNavigateToPose::SharedPtr active_goal_handle_;
  rclcpp::TimerBase::SharedPtr start_timer_;
  rclcpp::TimerBase::SharedPtr next_goal_timer_;
  std::string last_status_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MultiPointNav>());
  rclcpp::shutdown();
  return 0;
}
