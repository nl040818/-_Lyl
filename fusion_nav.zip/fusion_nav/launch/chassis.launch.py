import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource


def generate_launch_description():
    origincar_share = get_package_share_directory("origincar_base")

    buffered_logging = SetEnvironmentVariable("RCUTILS_LOGGING_BUFFERED_STREAM", "1")

    chassis_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(origincar_share, "launch", "origincar_bringup.launch.py")
        ),
        launch_arguments={"carto_slam": "false"}.items(),
    )

    return LaunchDescription([buffered_logging, chassis_bringup])
