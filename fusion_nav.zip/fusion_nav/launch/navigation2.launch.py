import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    IncludeLaunchDescription,
    SetEnvironmentVariable,
    TimerAction,
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    fusion_nav_share = get_package_share_directory("fusion_nav")
    origincar_share = get_package_share_directory("origincar_base")
    lidar_share = get_package_share_directory("lslidar_driver")
    nav2_share = get_package_share_directory("nav2_bringup")

    default_map = os.path.join(fusion_nav_share, "maps", "placeholder_map.yaml")
    default_params = os.path.join(fusion_nav_share, "config", "nav2_params.yaml")

    map_yaml_file = LaunchConfiguration("map")
    params_file = LaunchConfiguration("params_file")
    use_sim_time = LaunchConfiguration("use_sim_time")
    autostart = LaunchConfiguration("autostart")
    use_composition = LaunchConfiguration("use_composition")
    log_level = LaunchConfiguration("log_level")
    initial_pose_delay = LaunchConfiguration("initial_pose_delay")

    declare_map = DeclareLaunchArgument(
        "map",
        default_value=default_map,
        description="Navigation2 map yaml file",
    )
    declare_params = DeclareLaunchArgument(
        "params_file",
        default_value=default_params,
        description="Navigation2 parameters file",
    )
    declare_use_sim_time = DeclareLaunchArgument(
        "use_sim_time",
        default_value="false",
        description="Use simulation clock if true",
    )
    declare_autostart = DeclareLaunchArgument(
        "autostart",
        default_value="true",
        description="Automatically startup the nav2 stack",
    )
    declare_use_composition = DeclareLaunchArgument(
        "use_composition",
        default_value="False",
        description="Use nav2 composition container",
    )
    declare_log_level = DeclareLaunchArgument(
        "log_level",
        default_value="info",
        description="ROS log level for nav2 nodes",
    )
    declare_initial_pose_delay = DeclareLaunchArgument(
        "initial_pose_delay",
        default_value="8.0",
        description="Delay in seconds before publishing the default initial pose",
    )

    buffered_logging = SetEnvironmentVariable("RCUTILS_LOGGING_BUFFERED_STREAM", "1")

    base_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(origincar_share, "launch", "origincar_bringup.launch.py")
        ),
        launch_arguments={"carto_slam": "false"}.items(),
    )

    lidar_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(lidar_share, "launch", "lsn10_launch.py"))
    )

    nav2_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(nav2_share, "launch", "bringup_launch.py")),
        launch_arguments={
            "slam": "False",
            "map": map_yaml_file,
            "use_sim_time": use_sim_time,
            "params_file": params_file,
            "autostart": autostart,
            "use_composition": use_composition,
            "use_respawn": "False",
            "log_level": log_level,
        }.items(),
    )

    publish_initial_pose = TimerAction(
        period=initial_pose_delay,
        actions=[
            ExecuteProcess(
                cmd=[
                    "ros2",
                    "topic",
                    "pub",
                    "--once",
                    "/initialpose",
                    "geometry_msgs/msg/PoseWithCovarianceStamped",
                    (
                        "{header: {frame_id: map}, pose: {pose: {position: {x: 0.0, y: 0.0, z: 0.0}, "
                        "orientation: {x: 0.0, y: 0.0, z: 0.0, w: 1.0}}, covariance: [0.25, 0.0, 0.0, 0.0, "
                        "0.0, 0.0, 0.0, 0.25, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, "
                        "0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.068]}}"
                    ),
                ],
                output="screen",
            )
        ],
    )

    return LaunchDescription(
        [
            buffered_logging,
            declare_map,
            declare_params,
            declare_use_sim_time,
            declare_autostart,
            declare_use_composition,
            declare_log_level,
            declare_initial_pose_delay,
            base_bringup,
            lidar_bringup,
            nav2_bringup,
            publish_initial_pose,
        ]
    )
