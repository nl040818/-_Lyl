# fusion_nav 四阶段导航状态机

`fusion_nav_four_stage_state_machine` 是一个 ROS 2 任务编排节点。它本身不负责完成巡线、二维码识别、Nav2 多点导航或黄色通道视觉控制，而是按照比赛流程启动、停止并监控对应的子程序，在阶段之间传递二维码方向结果，并在状态切换或故障时发布零速度指令。

对应实现：[`src/fusion_nav_four_stage_state_machine.cpp`](src/fusion_nav_four_stage_state_machine.cpp)  
默认参数：[`config/fusion_nav_four_stage_state_machine.yaml`](config/fusion_nav_four_stage_state_machine.yaml)

> [!IMPORTANT]
> 该可执行目标只有在 CMake 同时找到 `ai_msgs` 和 `nav2_msgs` 时才会生成。文档编写时，当前工作空间中 `ai_msgs` 尚不可用，因此下文运行流程是依据源码和配置核验的使用说明，不代表已经在本机完成端到端运行验证。

<details>
<summary>目录</summary>

- [功能概览](#overview)
- [状态流转](#state-flow)
- [各状态功能](#states)
- [程序结构](#implementation)
- [ROS 2 接口](#ros-interfaces)
- [参数说明](#parameters)
- [编译与启动](#build-and-run)
- [运行监控](#monitoring)
- [安全与故障处理](#safety)
- [常见问题](#troubleshooting)
- [源码索引](#source-index)

</details>

<a id="overview"></a>
## 功能概览

状态机依次编排以下任务：

1. 启动 `qr_tracking_decoder`，在巡线过程中追踪并解码二维码。
2. 根据二维码内容选择顺时针或逆时针导航参数，启动 `multi_point_nav`。
3. 所有导航点完成后关闭 Nav2 lifecycle managers，避免 Nav2 继续占用底盘控制。
4. 启动 `yellow_channel`，沿黄色通道行驶。
5. 同时检测黄色通道的红色触发参数和 YOLO `point` 目标；两项条件同时满足后切换到最终巡线。
6. 任一受管子进程异常退出、导航失败、二维码内容不受支持或 Nav2 关闭失败时进入 `ERROR` 并停车。

四个业务阶段分别是：

| 阶段 | 状态值 | 受管子程序 |
| --- | --- | --- |
| 1 | `line_qr_tracking` | `qr_tracking_decoder` |
| 2 | `multi_point_nav` | `multi_point_nav` |
| 3 | `yellow_channel` | `yellow_channel` |
| 4 | `after_yellow_line_qr_tracking` | `qr_tracking_decoder`，使用另一份参数 |

`starting`、`nav_shutdown` 和 `error` 是为启动、资源交接和故障保护设置的辅助状态，因此源码枚举中共有七个状态。

<a id="state-flow"></a>
## 状态流转

```mermaid
stateDiagram-v2
    [*] --> STARTING
    STARTING --> LINE_QR_TRACKING: 启动定时器到期（200 ms）
    LINE_QR_TRACKING --> MULTI_POINT_NAV: QR = ClockWise / AntiClockWise
    MULTI_POINT_NAV --> NAV_SHUTDOWN: status = all_succeeded
    NAV_SHUTDOWN --> YELLOW_CHANNEL: Nav2 lifecycle shutdown 成功
    YELLOW_CHANNEL --> AFTER_YELLOW_LINE_QR_TRACKING: 红色触发非空 且近期检测到 point

    LINE_QR_TRACKING --> ERROR: QR 不受支持 / 子进程异常
    MULTI_POINT_NAV --> ERROR: failed / 提前 stopped / 子进程异常
    NAV_SHUTDOWN --> ERROR: 服务失败或超时
    YELLOW_CHANNEL --> ERROR: 子进程异常
    AFTER_YELLOW_LINE_QR_TRACKING --> ERROR: 子进程异常

    AFTER_YELLOW_LINE_QR_TRACKING --> [*]: 关闭状态机节点
    ERROR --> [*]: 关闭状态机节点
```

状态机不会从 `ERROR` 自动恢复。`AFTER_YELLOW_LINE_QR_TRACKING` 是持续运行的终态，只有关闭状态机节点才会结束。

<a id="states"></a>
## 各状态功能

| 状态 | 进入动作 | 等待条件 | 下一状态 | 异常行为 |
| --- | --- | --- | --- | --- |
| `STARTING` | 创建发布器、订阅器、服务客户端和定时器，发布 `starting` | 200 ms 启动定时器到期 | `LINE_QR_TRACKING` | 构造失败时节点无法启动 |
| `LINE_QR_TRACKING` | 启动 `qr_tracking_decoder`，加载 `line_qr_params_file` | `last_qr_code_result` 为 `ClockWise` 或 `AntiClockWise` | `MULTI_POINT_NAV` | 其他非空二维码结果进入 `ERROR` |
| `MULTI_POINT_NAV` | 按二维码方向加载对应参数并启动 `multi_point_nav` | `/multi_point_nav/status` 为 `all_succeeded` | `NAV_SHUTDOWN` | `failed:*` 或已运行后收到 `stopped` 时进入 `ERROR` |
| `NAV_SHUTDOWN` | 停止导航子进程、发布零速度、向所有 lifecycle manager 发送 `SHUTDOWN` | 所有服务成功返回 | `YELLOW_CHANNEL` | 任一请求失败或超过 `nav_shutdown_timeout_sec` 时进入 `ERROR` |
| `YELLOW_CHANNEL` | 启动 `yellow_channel`，清空历史红色触发和 `point` 检测状态 | 红色触发参数非空，并且 `point` 检测仍在有效期内 | `AFTER_YELLOW_LINE_QR_TRACKING` | 子进程异常退出时进入 `ERROR` |
| `AFTER_YELLOW_LINE_QR_TRACKING` | 重新启动 `qr_tracking_decoder`，加载 `after_yellow_line_qr_params_file` | 无，持续巡线 | 终态 | 子进程异常退出时进入 `ERROR` |
| `ERROR` | 停止当前子进程，重复发布零速度，发布 `error` | 无自动恢复条件 | 终态 | 需要排除故障后重启状态机 |

### 二维码与导航方向

二维码结果会先去除首尾空白，再进行区分大小写的精确匹配：

| 二维码内容 | 导航参数 |
| --- | --- |
| `AntiClockWise` | `multi_nav_anticlockwise_params_file` |
| `ClockWise` | `multi_nav_clockwise_params_file` |
| 空字符串 | 保持状态一并继续轮询 |
| 其他非空字符串 | 进入 `ERROR` |

`multi_nav_params_file` 是未选定方向时的后备参数。按当前正常流程，只有上述两个受支持的二维码结果会触发状态切换，所以实际运行通常会使用两份方向参数之一。

### 黄色通道退出条件

从 `YELLOW_CHANNEL` 进入最终巡线必须同时满足：

- `red_text_trigger.last_trigger` 为非空字符串；
- 最新感知消息中存在类型为 `point` 的目标；
- 该目标至少有一个 ROI，且第一个 ROI 的 `confidence` **严格大于** `point_confidence_threshold`；
- 距离最近一次有效 `point` 检测未超过 `point_detection_timeout_sec`。

两个条件的到达顺序没有限制。每次收到有效 `point` 或读到非空红色触发时，状态机都会重新检查组合条件。进入黄色通道时会清空此前积累的触发状态，避免旧数据直接触发状态四。

<a id="implementation"></a>
## 程序结构

### 参数加载与资源初始化

构造函数先调用 `loadParameters()`，再创建以下资源：

- 状态与速度发布器；
- 多点导航状态和 YOLO 目标订阅器；
- 两个 `GetParameters` 客户端；
- 每个 Nav2 lifecycle manager 对应的 `ManageLifecycleNodes` 客户端；
- 二维码轮询、红色触发轮询、子进程监控、Nav2 关闭和延时启动定时器。

所有参数文件参数在传入空字符串时，都会尝试从 `liu_dine/config/config` 解析默认文件。找不到 `liu_dine` 的安装目录时，源码还会回退到固定车端路径 `/home/sunrise/niubi_ws/src/liu_dine/config/config`。在当前 `fusion_nav` 工作空间中运行时，应显式传入参数文件路径。

### 参数轮询

状态机不订阅二维码和红色触发话题，而是异步调用目标节点的 `/get_parameters` 服务：

- 二维码默认以 `2 Hz` 读取 `/qr_tracking_decoder` 的 `last_qr_code_result`；
- 红色触发默认以 `5 Hz` 读取 `/single_cetnerline_param_node` 的 `red_text_trigger.last_trigger`。

每类请求都有 pending 标志，上一请求未返回时不会重复发送。参数服务未就绪时只输出节流警告，并停留在当前状态等待服务出现。

### 导航状态处理

`multiNavStatusCallback()` 识别下列消息：

| 消息格式 | 处理 |
| --- | --- |
| `waiting_server` | 标记导航已经进入活动流程 |
| `running:*` | 标记导航已经进入活动流程 |
| `succeeded:*` | 标记导航已经进入活动流程，继续等待其他点 |
| `all_succeeded` | 进入 Nav2 关闭流程 |
| `failed:*` | 进入 `ERROR` |
| `stopped` | 仅在导航已经活动后视为提前退出并进入 `ERROR` |

### Nav2 生命周期关闭

多点导航完成后，状态机不会立即启动黄色通道，而是先：

1. 停止 `multi_point_nav` 子进程并发布零速度；
2. 等待配置的所有 lifecycle manager 服务可用；
3. 并行发送 `ManageLifecycleNodes::Request::SHUTDOWN`；
4. 等待所有响应成功；
5. 再次发布零速度并启动 `yellow_channel`。

服务列表为空时会记录警告并直接进入黄色通道。服务始终不可用、响应失败或整体耗时超过限制时进入 `ERROR`。

### 子进程管理

每个业务子程序通过以下等价命令启动：

```text
ros2 run <package_name> <executable> --ros-args --params-file <params_file>
```

状态机使用 `fork()` 和 `execvp()` 创建独立进程组。切换状态时依次向整个子进程组发送：

1. `SIGINT`，等待 `stop_grace_sec`；
2. 未退出则发送 `SIGTERM`，再次等待；
3. 仍未退出则发送 `SIGKILL`。

后台定时器每 `500 ms` 调用一次 `waitpid(..., WNOHANG)`。只要当前业务状态中的子进程自行退出，无论退出码是多少，状态机都会将其视为异常并进入 `ERROR`。

<a id="ros-interfaces"></a>
## ROS 2 接口

### 发布话题

| 默认话题 | 类型 | QoS | 用途 |
| --- | --- | --- | --- |
| `/fusion_nav_four_stage_state_machine/status` | `std_msgs/msg/String` | depth 10、Reliable、Transient Local | 发布当前状态；新订阅者可以收到最近状态 |
| `/cmd_vel` | `geometry_msgs/msg/Twist` | depth 10 | 状态切换和错误时发布全零速度 |

可能发布的状态字符串：

```text
starting
line_qr_tracking
multi_point_nav
nav_shutdown
yellow_channel
after_yellow_line_qr_tracking
error
```

### 订阅话题

| 默认话题 | 类型 | QoS | 用途 |
| --- | --- | --- | --- |
| `/multi_point_nav/status` | `std_msgs/msg/String` | depth 10、Reliable、Transient Local | 判断导航进度、成功和失败 |
| `dnn_node_sample` | `ai_msgs/msg/PerceptionTargets` | depth 10 | 检测 `point` 标签及 ROI 置信度 |

### 调用服务

| 默认服务 | 类型 | 用途 |
| --- | --- | --- |
| `/qr_tracking_decoder/get_parameters` | `rcl_interfaces/srv/GetParameters` | 读取二维码结果 |
| `/single_cetnerline_param_node/get_parameters` | `rcl_interfaces/srv/GetParameters` | 读取黄色通道红色触发参数 |
| `/lifecycle_manager_navigation/manage_nodes` | `nav2_msgs/srv/ManageLifecycleNodes` | 关闭 Nav2 导航 lifecycle manager |
| `/lifecycle_manager_localization/manage_nodes` | `nav2_msgs/srv/ManageLifecycleNodes` | 关闭 Nav2 定位 lifecycle manager |

`single_cetnerline_param_node` 中的 `cetnerline` 是当前 `yellow_channel.cpp` 使用的实际节点名，并非本文拼写错误。节点名和话题都可以通过状态机参数覆盖。

<a id="parameters"></a>
## 参数说明

### 通用与接口参数

| 参数 | 默认值 | 单位 | 作用 |
| --- | --- | --- | --- |
| `package_name` | `liu_dine` | - | 受管子程序所在的 ROS 2 功能包 |
| `ros2_executable` | `ros2` | - | 启动子程序时调用的命令或绝对路径 |
| `status_topic` | `/fusion_nav_four_stage_state_machine/status` | - | 状态发布话题 |
| `cmd_vel_topic` | `/cmd_vel` | - | 零速度指令发布话题 |
| `multi_nav_status_topic` | `/multi_point_nav/status` | - | 多点导航状态订阅话题 |
| `yolo_targets_topic` | `dnn_node_sample` | - | AI 感知目标订阅话题 |

### 二维码与黄色通道触发参数

| 参数 | 默认值 | 单位 | 作用 |
| --- | --- | --- | --- |
| `line_qr_node_name` | `/qr_tracking_decoder` | - | 二维码节点名，用于拼接参数服务名 |
| `qr_result_param` | `last_qr_code_result` | - | 二维码结果参数名 |
| `poll_qr_param_hz` | `2.0` | Hz | 二维码参数轮询频率，最小值 `0.1` |
| `yellow_node_name` | `/single_cetnerline_param_node` | - | 黄色通道节点名，用于拼接参数服务名 |
| `yellow_red_trigger_param` | `red_text_trigger.last_trigger` | - | 红色触发结果参数名 |
| `poll_yellow_red_param_hz` | `5.0` | Hz | 红色触发参数轮询频率，最小值 `0.1` |
| `point_label` | `point` | - | 黄色通道退出所需的目标类别 |
| `point_confidence_threshold` | `0.7` | - | ROI 置信度下限；判定条件为严格大于，参数最小值为 `0` |
| `point_detection_timeout_sec` | `0.5` | s | `point` 检测有效期；`0` 表示检测到后持续有效 |

### 子程序与参数文件

| 参数 | 默认值 | 空值解析结果 |
| --- | --- | --- |
| `line_qr_executable` | `qr_tracking_decoder` | - |
| `multi_nav_executable` | `multi_point_nav` | - |
| `yellow_executable` | `yellow_channel` | - |
| `line_qr_params_file` | 空 | `liu_dine/config/config/qr_tracking_decoder.yaml` |
| `multi_nav_params_file` | 空 | `liu_dine/config/config/multi_point_nav.yaml` |
| `multi_nav_anticlockwise_params_file` | 空 | `liu_dine/config/config/multi_point_nav_anticlockwise.yaml` |
| `multi_nav_clockwise_params_file` | 空 | `liu_dine/config/config/multi_point_nav_clockwise.yaml` |
| `yellow_params_file` | 空 | `liu_dine/config/config/yellow_channel.yaml` |
| `after_yellow_line_qr_params_file` | 空 | `liu_dine/config/config/qr_tracking_decoder_after_yellow.yaml` |

这里的 `liu_dine/config/config/...` 表示通过 ament 包索引取得 `liu_dine` share 目录后再拼接路径。若 ament 查找失败，则使用源码中固定的车端绝对路径。

### 生命周期与安全参数

| 参数 | 默认值 | 单位 | 作用 |
| --- | --- | --- | --- |
| `nav_lifecycle_manager_services` | 导航和定位两个 `manage_nodes` 服务 | - | 需要关闭的 Nav2 lifecycle managers；可设为空列表跳过关闭请求 |
| `nav_shutdown_timeout_sec` | `5.0` | s | 等待所有 Nav2 关闭请求完成的总超时，最小值 `0.1` |
| `stop_grace_sec` | `1.0` | s | 每种温和终止信号发出后的等待时间，最小值 `0.1` |
| `publish_stop_on_transition` | `true` | - | 是否在停止子进程、Nav2 交接、错误和节点退出时发布零速度 |
| `stop_publish_repeats` | `3` | 次 | 每次停车连续发布的消息数，最小值 `1` |
| `stop_publish_interval_sec` | `0.05` | s | 多次零速度消息之间的间隔，最小值 `0` |

<a id="build-and-run"></a>
## 编译与启动

### 依赖

状态机源码直接依赖：

- ROS 2 Humble 与 `rclcpp`；
- `ai_msgs`，提供 `ai_msgs/msg/PerceptionTargets`；
- `nav2_msgs`，提供 lifecycle manager 服务类型；
- `rcl_interfaces`、`geometry_msgs`、`std_msgs`；
- `ament_index_cpp`；
- Linux/POSIX 进程接口，包括 `fork`、`execvp`、进程组和信号。

完整编译 `fusion_nav` 包还需要其余视觉和导航目标使用的 OpenCV、`cv_bridge`、`sensor_msgs`、`nav2_msgs` 等依赖。ZBar 缺失时部分二维码目标会降级或跳过，具体行为以 CMake 输出为准。

### 编译

```bash
cd /home/wc/CH1/yellow_channel_ws
source /opt/ros/humble/setup.bash

# 先确保 ai_msgs 和 nav2_msgs 能被当前环境找到
ros2 pkg prefix ai_msgs
ros2 pkg prefix nav2_msgs

colcon build --packages-select fusion_nav --symlink-install
source install/setup.bash

# 构建后确认四阶段状态机目标确实已生成
ros2 pkg executables fusion_nav | grep fusion_nav_four_stage_state_machine
```

如果 `ai_msgs` 或 `nav2_msgs` 不可见，CMake 会跳过 `fusion_nav_four_stage_state_machine`，此时 `ros2 run` 会报告找不到可执行程序。应先安装或加载提供这些消息包的工作空间，再重新编译。

### 当前工作空间启动方式

源码中的状态机属于 `fusion_nav` 包，但默认参数针对车端 `liu_dine` 包。当前工作空间运行时，必须将 `package_name` 覆盖为 `fusion_nav`，并显式传入所有子程序参数文件，避免回退到 `liu_dine` 路径。

当前仓库没有 `multi_point_nav_anticlockwise.yaml` 和 `multi_point_nav_clockwise.yaml`。下面的本地联调命令将两个方向都临时映射到同一份 `multi_point_nav.yaml`，因此只能验证流程，不能体现顺/逆时针路线差异：

```bash
cd /home/wc/CH1/yellow_channel_ws
source /opt/ros/humble/setup.bash
source install/setup.bash

PARAM_DIR="$(ros2 pkg prefix --share fusion_nav)/config"

ros2 run fusion_nav fusion_nav_four_stage_state_machine --ros-args \
  --params-file "$PARAM_DIR/fusion_nav_four_stage_state_machine.yaml" \
  -p package_name:=fusion_nav \
  -p line_qr_params_file:="$PARAM_DIR/qr_tracking_decoder.yaml" \
  -p multi_nav_params_file:="$PARAM_DIR/multi_point_nav.yaml" \
  -p multi_nav_anticlockwise_params_file:="$PARAM_DIR/multi_point_nav.yaml" \
  -p multi_nav_clockwise_params_file:="$PARAM_DIR/multi_point_nav.yaml" \
  -p yellow_params_file:="$PARAM_DIR/yellow_channel.yaml" \
  -p after_yellow_line_qr_params_file:="$PARAM_DIR/qr_tracking_decoder_after_yellow.yaml"
```

正式比赛应把下面两个参数分别指向实际存在、航点方向正确的 YAML：

```bash
-p multi_nav_anticlockwise_params_file:=/absolute/path/multi_point_nav_anticlockwise.yaml
-p multi_nav_clockwise_params_file:=/absolute/path/multi_point_nav_clockwise.yaml
```

车端已经把子程序和配置安装在 `liu_dine` 时，可以保留 `package_name: liu_dine` 以及空参数文件配置，但应先确认以下资源真实存在：

```bash
ros2 pkg executables liu_dine
ros2 pkg prefix --share liu_dine
```

<a id="monitoring"></a>
## 运行监控

### 查看当前状态

状态话题使用 Transient Local QoS，建议显式匹配：

```bash
ros2 topic echo \
  --qos-reliability reliable \
  --qos-durability transient_local \
  /fusion_nav_four_stage_state_machine/status std_msgs/msg/String
```

### 检查阶段输入

```bash
# 二维码结果
ros2 param get /qr_tracking_decoder last_qr_code_result

# 多点导航状态
ros2 topic echo \
  --qos-reliability reliable \
  --qos-durability transient_local \
  /multi_point_nav/status std_msgs/msg/String

# 黄色通道红色触发
ros2 param get /single_cetnerline_param_node red_text_trigger.last_trigger

# YOLO/AI 感知消息
ros2 topic echo dnn_node_sample ai_msgs/msg/PerceptionTargets
```

### 检查服务与进程

```bash
ros2 service type /qr_tracking_decoder/get_parameters
ros2 service type /single_cetnerline_param_node/get_parameters
ros2 service type /lifecycle_manager_navigation/manage_nodes
ros2 service type /lifecycle_manager_localization/manage_nodes

ros2 node list
ros2 topic info -v /cmd_vel
```

<a id="safety"></a>
## 安全与故障处理

- **切换前停止旧进程**：新状态启动前先终止上一状态的整个进程组。
- **重复发布零速度**：默认连续发布三次全零 `Twist`，降低单条消息丢失或控制交接残留的风险。
- **Nav2 显式关闭**：多点导航结束后先关闭导航与定位 lifecycle managers，再把底盘控制交给黄色通道。
- **异常子进程监控**：受管子程序意外退出会触发 `ERROR`，不会静默进入下一阶段。
- **服务超时保护**：Nav2 lifecycle 关闭超过 `5 s` 会停车并进入 `ERROR`。
- **感知时效限制**：`point` 默认只保持 `0.5 s` 有效，防止很早以前的检测结果与新的红色触发错误组合。
- **析构停车**：关闭状态机节点时会停止当前子进程并发布零速度。

> [!WARNING]
> 零速度发布是应用层保护，不等同于硬件急停。实车测试仍应保留独立急停、底盘通信超时停车和安全测试区域。

<a id="troubleshooting"></a>
## 常见问题

### 找不到 `fusion_nav_four_stage_state_machine`

先检查依赖和目标：

```bash
ros2 pkg prefix ai_msgs
ros2 pkg prefix nav2_msgs
ros2 pkg executables fusion_nav | grep four_stage
```

只要 `ai_msgs` 或 `nav2_msgs` 在配置阶段不可见，CMake 就不会生成该目标。加载正确的依赖工作空间后需要重新编译 `fusion_nav`。

### 子程序提示找不到 `liu_dine`

日志中的受管命令默认使用 `ros2 run liu_dine ...`。本工作空间应设置：

```bash
-p package_name:=fusion_nav
```

同时显式设置六个 `*_params_file` 参数；只修改包名不能改变源码中针对 `liu_dine` 的参数文件回退逻辑。

### 一直等待二维码参数服务

检查二维码子进程是否启动、节点名是否一致，以及参数服务是否存在：

```bash
ros2 node info /qr_tracking_decoder
ros2 service type /qr_tracking_decoder/get_parameters
ros2 param get /qr_tracking_decoder last_qr_code_result
```

二维码内容必须精确为 `ClockWise` 或 `AntiClockWise`。其他非空内容会立即进入 `ERROR`。

### 导航完成后无法进入黄色通道

确认 `/multi_point_nav/status` 最终发布的是精确字符串 `all_succeeded`，然后检查两个 lifecycle manager 服务是否存在并能处理 `SHUTDOWN`。若 Nav2 没有使用其中某个 manager，应从 `nav_lifecycle_manager_services` 中移除对应服务，而不是等待到超时。

### 黄色通道无法进入最终巡线

依次确认：

```bash
ros2 param get /single_cetnerline_param_node red_text_trigger.last_trigger
ros2 topic echo dnn_node_sample ai_msgs/msg/PerceptionTargets
ros2 param get /fusion_nav_four_stage_state_machine point_confidence_threshold
ros2 param get /fusion_nav_four_stage_state_machine point_detection_timeout_sec
```

红色触发和有效 `point` 必须在检测有效期内同时成立。置信度等于 `0.7` 不通过默认阈值，因为源码使用的是严格大于比较。

### 子程序启动后马上进入 `ERROR`

状态机将任何自行退出的受管子进程视为异常。根据日志中的可执行名和参数文件，先在单独终端手动运行等价命令，检查参数文件不存在、节点重名、消息类型缺失或 Nav2 action server 不可用等问题。

<a id="source-index"></a>
## 源码索引

| 源码位置 | 功能 |
| --- | --- |
| [`fallbackSourceConfigPath()` / `packageConfigPath()`](src/fusion_nav_four_stage_state_machine.cpp#L37-L49) | 解析 `liu_dine` 参数文件及车端回退路径 |
| [`normalizeNodeName()` / `trimWhitespace()`](src/fusion_nav_four_stage_state_machine.cpp#L51-L75) | 规范服务节点名并清理二维码结果 |
| [`FusionNavFourStageStateMachine()`](src/fusion_nav_four_stage_state_machine.cpp#L83-L133) | 初始化 ROS 接口、客户端和定时器 |
| [`State`](src/fusion_nav_four_stage_state_machine.cpp#L140-L149) | 定义全部运行状态 |
| [`loadParameters()`](src/fusion_nav_four_stage_state_machine.cpp#L159-L231) | 声明参数、限制数值范围并解析默认文件 |
| [`enterLineQrTracking()` 至 `enterError()`](src/fusion_nav_four_stage_state_machine.cpp#L233-L326) | 各状态的进入动作和故障终态 |
| [`pollQrParameter()`](src/fusion_nav_four_stage_state_machine.cpp#L328-L380) | 轮询二维码并选择导航方向参数 |
| [`multiNavStatusCallback()`](src/fusion_nav_four_stage_state_machine.cpp#L382-L412) | 解析多点导航状态 |
| [`yoloTargetsCallback()` / `messageHasPoint()`](src/fusion_nav_four_stage_state_machine.cpp#L414-L440) | 检测有效 `point` 目标 |
| [`pollYellowRedParameter()` / `tryEnterAfterYellowLineQrTracking()`](src/fusion_nav_four_stage_state_machine.cpp#L459-L524) | 组合红色触发与 `point` 条件 |
| [`processNavShutdown()` / `sendNavShutdownRequests()`](src/fusion_nav_four_stage_state_machine.cpp#L526-L612) | 关闭 Nav2 lifecycle managers |
| [`makeCommand()` / `startManagedProcess()`](src/fusion_nav_four_stage_state_machine.cpp#L614-L658) | 构造命令并启动子进程组 |
| [`stopCurrentProcess()` / `watchChildProcess()`](src/fusion_nav_four_stage_state_machine.cpp#L660-L718) | 分级停止和监控子进程 |
| [`publishStopCommand()` / `publishStatus()`](src/fusion_nav_four_stage_state_machine.cpp#L720-L742) | 发布安全停车和状态消息 |
| [`main()`](src/fusion_nav_four_stage_state_machine.cpp#L808-L814) | 初始化、运行并关闭 ROS 2 节点 |

## 设计边界

该节点是任务编排器，不替代以下组件自身的功能：

- `qr_tracking_decoder` 负责巡线、目标跟踪和二维码解码；
- `multi_point_nav` 负责向 Nav2 提交航点目标并发布进度；
- `yellow_channel` 负责黄色区域视觉处理、底盘控制和红色触发检测；
- YOLO/DNN 节点负责向 `dnn_node_sample` 发布目标检测结果；
- Nav2 lifecycle managers 负责导航和定位节点的生命周期管理。

修改某一阶段算法时，应优先调整对应子程序或 YAML。只有阶段顺序、切换条件、子进程管理或全局安全策略发生变化时，才需要修改四阶段状态机本身。
