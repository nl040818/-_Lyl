//显示降噪后HSV图像和LAB图像，并将LAB的反相结果与HSV结果进行融合，
// 进一步提升黄色区域的识别效果，线所
// 原图：
// HSV掩码：hsv_mask = inRange(blurred, Scalar(h_min, s_min, v_min), Scalar(h_max, s_max, v_max))
// LAB掩码（反相后）：lab_mask = NOT lab_mask
// 融合结果：final_mask = hsv_mask OR (NOT lab_mask)
#include <algorithm>
#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "cv_bridge/cv_bridge.h"
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/image_encodings.hpp"
#include "sensor_msgs/msg/image.hpp"

#include <opencv2/opencv.hpp>

using namespace std::chrono_literals;

namespace
{
constexpr int kAndFusion = 0;
constexpr int kOrFusion = 1;

int makeOddKernelSize(int size)
{
  size = std::max(size, 1);
  if (size % 2 == 0) {
    ++size;
  }
  return size;
}

int makeMedianKernelSize(int size)
{
  return std::max(3, std::min(makeOddKernelSize(size), 7));
}

void noopTrackbarCallback(int, void *)
{
}
}  // namespace

class YellowChannelLab3InvertDenoiseDetector : public rclcpp::Node
{
public:
  YellowChannelLab3InvertDenoiseDetector()
  : Node("yellow_channel_lab3_invert_denoise_detector")
  {
    camera_index_ = declare_parameter<int>("camera_index", 2);
    frame_width_ = declare_parameter<int>("frame_width", 640);
    frame_height_ = declare_parameter<int>("frame_height", 480);
    fps_ = declare_parameter<int>("fps", 30);
    frame_id_ = declare_parameter<std::string>("frame_id", "camera");
    use_gui_ = declare_parameter<bool>("use_gui", true);
    h_min_ = declare_parameter<int>("h_min", 43);
    h_max_ = declare_parameter<int>("h_max", 179);
    s_min_ = declare_parameter<int>("s_min", 34);
    s_max_ = declare_parameter<int>("s_max", 255);
    v_min_ = declare_parameter<int>("v_min", 0);
    v_max_ = declare_parameter<int>("v_max", 255);
    l_min_ = declare_parameter<int>("l_min", 0);
    l_max_ = declare_parameter<int>("l_max", 255);
    a_min_ = declare_parameter<int>("a_min", 0);
    a_max_ = declare_parameter<int>("a_max", 255);
    b_min_ = declare_parameter<int>("b_min", 121);
    b_max_ = declare_parameter<int>("b_max", 255);
    kernel_size_ = declare_parameter<int>("kernel_size", 3);
    min_area_ = declare_parameter<int>("min_area", 1311);
    dilate_iterations_ = declare_parameter<int>("dilate_iterations", 3);
    keep_largest_ = declare_parameter<int>("keep_largest", 1);
    fusion_mode_ = declare_parameter<int>("fusion_mode", kOrFusion);

    raw_pub_ = create_publisher<sensor_msgs::msg::Image>("/yellow_lab3_invert/raw_image", 10);
    hsv_mask_pub_ = create_publisher<sensor_msgs::msg::Image>("/yellow_lab3_invert/hsv_mask", 10);
    lab_mask_pub_ = create_publisher<sensor_msgs::msg::Image>("/yellow_lab3_invert/lab_mask", 10);
    final_mask_pub_ =
      create_publisher<sensor_msgs::msg::Image>("/yellow_lab3_invert/final_mask", 10);

    cap_.open(camera_index_);
    if (!cap_.isOpened()) {
      RCLCPP_ERROR(get_logger(), "无法打开相机 /dev/video%d", camera_index_);
      throw std::runtime_error("camera open failed");
    }

    cap_.set(cv::CAP_PROP_FRAME_WIDTH, frame_width_);
    cap_.set(cv::CAP_PROP_FRAME_HEIGHT, frame_height_);
    cap_.set(cv::CAP_PROP_FPS, fps_);

    if (use_gui_) {
      createWindowsAndTrackbars();
    }

    const auto period = std::chrono::milliseconds(std::max(1, 1000 / std::max(fps_, 1)));
    timer_ = create_wall_timer(
      period, std::bind(&YellowChannelLab3InvertDenoiseDetector::timerCallback, this));

    RCLCPP_INFO(
      get_logger(),
      "LAB三通道反相融合降噪节点已启动: camera_index=%d, size=%dx%d, fps=%d",
      camera_index_, frame_width_, frame_height_, fps_);
  }

  ~YellowChannelLab3InvertDenoiseDetector() override
  {
    cap_.release();
    if (use_gui_) {
      cv::destroyAllWindows();
    }
  }

private:
  void createWindowsAndTrackbars()
  {
    cv::namedWindow("yellow_lab3/raw", cv::WINDOW_NORMAL);
    cv::namedWindow("yellow_lab3/hsv_mask", cv::WINDOW_NORMAL);
    cv::namedWindow("yellow_lab3/lab_mask", cv::WINDOW_NORMAL);
    cv::namedWindow("yellow_lab3/final_mask", cv::WINDOW_NORMAL);
    cv::namedWindow("yellow_lab3/trackbars", cv::WINDOW_NORMAL);

    cv::createTrackbar("H min", "yellow_lab3/trackbars", &h_min_, 179, noopTrackbarCallback);
    cv::createTrackbar("H max", "yellow_lab3/trackbars", &h_max_, 179, noopTrackbarCallback);
    cv::createTrackbar("S min", "yellow_lab3/trackbars", &s_min_, 255, noopTrackbarCallback);
    cv::createTrackbar("S max", "yellow_lab3/trackbars", &s_max_, 255, noopTrackbarCallback);
    cv::createTrackbar("V min", "yellow_lab3/trackbars", &v_min_, 255, noopTrackbarCallback);
    cv::createTrackbar("V max", "yellow_lab3/trackbars", &v_max_, 255, noopTrackbarCallback);

    cv::createTrackbar("L min", "yellow_lab3/trackbars", &l_min_, 255, noopTrackbarCallback);
    cv::createTrackbar("L max", "yellow_lab3/trackbars", &l_max_, 255, noopTrackbarCallback);
    cv::createTrackbar("A min", "yellow_lab3/trackbars", &a_min_, 255, noopTrackbarCallback);
    cv::createTrackbar("A max", "yellow_lab3/trackbars", &a_max_, 255, noopTrackbarCallback);
    cv::createTrackbar("B min", "yellow_lab3/trackbars", &b_min_, 255, noopTrackbarCallback);
    cv::createTrackbar("B max", "yellow_lab3/trackbars", &b_max_, 255, noopTrackbarCallback);

    cv::createTrackbar("kernel", "yellow_lab3/trackbars", &kernel_size_, 25, noopTrackbarCallback);
    cv::createTrackbar("min area", "yellow_lab3/trackbars", &min_area_, 20000, noopTrackbarCallback);
    cv::createTrackbar(
      "dilate iterations", "yellow_lab3/trackbars", &dilate_iterations_, 8,
      noopTrackbarCallback);
    cv::createTrackbar("keep largest 0/1", "yellow_lab3/trackbars", &keep_largest_, 1, noopTrackbarCallback);
    cv::createTrackbar("fusion 0AND 1OR", "yellow_lab3/trackbars", &fusion_mode_, 1, noopTrackbarCallback);
  }

  void timerCallback()
  {
    cv::Mat frame;
    cap_ >> frame;
    if (frame.empty()) {
      RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000, "读取相机画面失败");
      return;
    }

    cv::Mat hsv_mask;
    cv::Mat lab_mask;
    cv::Mat final_mask;
    cv::Mat display = frame.clone();

    processFrame(frame, hsv_mask, lab_mask, final_mask, display);
    publishImages(frame, hsv_mask, lab_mask, final_mask);

    if (use_gui_) {
      cv::imshow("yellow_lab3/raw", display);
      cv::imshow("yellow_lab3/hsv_mask", hsv_mask);
      cv::imshow("yellow_lab3/lab_mask", lab_mask);
      cv::imshow("yellow_lab3/final_mask", final_mask);

      const char key = static_cast<char>(cv::waitKey(1));
      if (key == 27 || key == 'q' || key == 'Q') {
        RCLCPP_INFO(get_logger(), "收到退出按键，关闭节点");
        rclcpp::shutdown();
      } else if (key == 'p' || key == 'P') {
        printCurrentParameters();
      }
    }
  }

  void processFrame(
    const cv::Mat &frame,
    cv::Mat &hsv_mask,
    cv::Mat &lab_mask,
    cv::Mat &final_mask,
    cv::Mat &display)
  {
    cv::Mat filtered;
    cv::bilateralFilter(frame, filtered, 5, 50, 50);

    cv::Mat hsv;
    cv::cvtColor(filtered, hsv, cv::COLOR_BGR2HSV);
    cv::inRange(
      hsv,
      cv::Scalar(std::min(h_min_, h_max_), std::min(s_min_, s_max_), std::min(v_min_, v_max_)),
      cv::Scalar(std::max(h_min_, h_max_), std::max(s_min_, s_max_), std::max(v_min_, v_max_)),
      hsv_mask);
    denoisePreFusionMask(hsv_mask);

    cv::Mat lab;
    cv::cvtColor(filtered, lab, cv::COLOR_BGR2Lab);
    cv::inRange(
      lab,
      cv::Scalar(std::min(l_min_, l_max_), std::min(a_min_, a_max_), std::min(b_min_, b_max_)),
      cv::Scalar(std::max(l_min_, l_max_), std::max(a_min_, a_max_), std::max(b_min_, b_max_)),
      lab_mask);
    denoisePreFusionMask(lab_mask);
    cv::bitwise_not(lab_mask, lab_mask);
    denoisePreFusionMask(lab_mask);

    if (fusion_mode_ == kOrFusion) {
      cv::bitwise_or(hsv_mask, lab_mask, final_mask);
    } else {
      cv::bitwise_and(hsv_mask, lab_mask, final_mask);
    }

    std::vector<cv::Point> largest_contour;
    const double area = denoiseFinalMask(final_mask, largest_contour);
    drawTarget(display, largest_contour, area);
  }

  void denoisePreFusionMask(cv::Mat &mask)
  {
    const int kernel_size = makeOddKernelSize(kernel_size_);
    const cv::Mat kernel =
      cv::getStructuringElement(cv::MORPH_RECT, cv::Size(kernel_size, kernel_size));

    cv::medianBlur(mask, mask, makeMedianKernelSize(kernel_size_));
    cv::morphologyEx(mask, mask, cv::MORPH_OPEN, kernel);
    cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);
    removeSmallComponents(mask);
  }

  void removeSmallComponents(cv::Mat &mask)
  {
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    cv::Mat cleaned = cv::Mat::zeros(mask.size(), CV_8UC1);
    for (size_t i = 0; i < contours.size(); ++i) {
      if (cv::contourArea(contours[i]) >= static_cast<double>(min_area_)) {
        cv::drawContours(cleaned, contours, static_cast<int>(i), cv::Scalar(255), cv::FILLED);
      }
    }
    mask = cleaned;
  }

  double denoiseFinalMask(cv::Mat &mask, std::vector<cv::Point> &largest_contour)
  {
    const int kernel_size = makeOddKernelSize(kernel_size_);
    const cv::Mat kernel =
      cv::getStructuringElement(cv::MORPH_RECT, cv::Size(kernel_size, kernel_size));

    cv::medianBlur(mask, mask, makeMedianKernelSize(kernel_size_));
    cv::morphologyEx(mask, mask, cv::MORPH_OPEN, kernel);
    cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);

    const int iterations = std::max(0, dilate_iterations_);
    if (iterations > 0) {
      cv::dilate(mask, mask, kernel, cv::Point(-1, -1), iterations);
      cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);
    }

    if (keep_largest_ != 0) {
      return keepLargestComponent(mask, largest_contour);
    }

    return keepAreaFilteredComponents(mask, largest_contour);
  }

  double keepLargestComponent(cv::Mat &mask, std::vector<cv::Point> &largest_contour)
  {
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    int best_index = -1;
    double best_area = 0.0;
    for (size_t i = 0; i < contours.size(); ++i) {
      const double area = cv::contourArea(contours[i]);
      if (area >= static_cast<double>(min_area_) && area > best_area) {
        best_area = area;
        best_index = static_cast<int>(i);
      }
    }

    cv::Mat cleaned = cv::Mat::zeros(mask.size(), CV_8UC1);
    largest_contour.clear();
    if (best_index >= 0) {
      cv::drawContours(cleaned, contours, best_index, cv::Scalar(255), cv::FILLED);
      largest_contour = contours[best_index];
    }

    mask = cleaned;
    return best_area;
  }

  double keepAreaFilteredComponents(cv::Mat &mask, std::vector<cv::Point> &largest_contour)
  {
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    cv::Mat cleaned = cv::Mat::zeros(mask.size(), CV_8UC1);
    largest_contour.clear();
    double largest_area = 0.0;

    for (size_t i = 0; i < contours.size(); ++i) {
      const double area = cv::contourArea(contours[i]);
      if (area >= static_cast<double>(min_area_)) {
        cv::drawContours(cleaned, contours, static_cast<int>(i), cv::Scalar(255), cv::FILLED);
        if (area > largest_area) {
          largest_area = area;
          largest_contour = contours[i];
        }
      }
    }

    mask = cleaned;
    return largest_area;
  }

  void drawTarget(cv::Mat &display, const std::vector<cv::Point> &contour, double area)
  {
    if (contour.empty()) {
      cv::putText(
        display,
        "yellow: none",
        cv::Point(20, 40),
        cv::FONT_HERSHEY_SIMPLEX,
        1.0,
        cv::Scalar(0, 0, 255),
        2);
      return;
    }

    cv::drawContours(
      display,
      std::vector<std::vector<cv::Point>>{contour},
      -1,
      cv::Scalar(0, 255, 255),
      2);

    const cv::Moments moments = cv::moments(contour);
    if (moments.m00 != 0.0) {
      const int cx = static_cast<int>(moments.m10 / moments.m00);
      const int cy = static_cast<int>(moments.m01 / moments.m00);
      cv::circle(display, cv::Point(cx, cy), 6, cv::Scalar(0, 0, 255), -1);
      cv::putText(
        display,
        "center: (" + std::to_string(cx) + "," + std::to_string(cy) + ")",
        cv::Point(20, 80),
        cv::FONT_HERSHEY_SIMPLEX,
        0.8,
        cv::Scalar(0, 255, 0),
        2);
    }

    cv::putText(
      display,
      "yellow area: " + std::to_string(static_cast<int>(area)),
      cv::Point(20, 40),
      cv::FONT_HERSHEY_SIMPLEX,
      0.8,
      cv::Scalar(0, 255, 0),
      2);

    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      1000,
      "黄色区域面积: %.0f, 融合模式: %s, 只保留最大区域: %s",
      area,
      fusion_mode_ == kOrFusion ? "OR" : "AND",
      keep_largest_ != 0 ? "true" : "false");
  }

  void printCurrentParameters()
  {
    RCLCPP_INFO(
      get_logger(),
      "\n当前LAB三通道反相融合降噪参数:"
      "\n  camera_index=%d, frame_width=%d, frame_height=%d, fps=%d"
      "\n  HSV: H=[%d,%d], S=[%d,%d], V=[%d,%d]"
      "\n  LAB: L=[%d,%d], A=[%d,%d], B=[%d,%d]"
      "\n  denoise: kernel=%d, min_area=%d, dilate_iterations=%d, keep_largest=%d"
      "\n  fusion_mode=%s",
      camera_index_,
      frame_width_,
      frame_height_,
      fps_,
      std::min(h_min_, h_max_),
      std::max(h_min_, h_max_),
      std::min(s_min_, s_max_),
      std::max(s_min_, s_max_),
      std::min(v_min_, v_max_),
      std::max(v_min_, v_max_),
      std::min(l_min_, l_max_),
      std::max(l_min_, l_max_),
      std::min(a_min_, a_max_),
      std::max(a_min_, a_max_),
      std::min(b_min_, b_max_),
      std::max(b_min_, b_max_),
      makeOddKernelSize(kernel_size_),
      min_area_,
      std::max(0, dilate_iterations_),
      keep_largest_,
      fusion_mode_ == kOrFusion ? "OR" : "AND");
  }

  void publishImages(
    const cv::Mat &raw_frame,
    const cv::Mat &hsv_mask,
    const cv::Mat &lab_mask,
    const cv::Mat &final_mask)
  {
    std_msgs::msg::Header header;
    header.stamp = now();
    header.frame_id = frame_id_;

    raw_pub_->publish(
      *cv_bridge::CvImage(header, sensor_msgs::image_encodings::BGR8, raw_frame).toImageMsg());
    hsv_mask_pub_->publish(
      *cv_bridge::CvImage(header, sensor_msgs::image_encodings::MONO8, hsv_mask).toImageMsg());
    lab_mask_pub_->publish(
      *cv_bridge::CvImage(header, sensor_msgs::image_encodings::MONO8, lab_mask).toImageMsg());
    final_mask_pub_->publish(
      *cv_bridge::CvImage(header, sensor_msgs::image_encodings::MONO8, final_mask).toImageMsg());
  }

  int camera_index_;
  int frame_width_;
  int frame_height_;
  int fps_;
  std::string frame_id_;
  bool use_gui_;

  int h_min_ = 43;
  int h_max_ = 179;
  int s_min_ = 34;
  int s_max_ = 255;
  int v_min_ = 0;
  int v_max_ = 255;
  int l_min_ = 0;
  int l_max_ = 255;
  int a_min_ = 0;
  int a_max_ = 255;
  int b_min_ = 121;
  int b_max_ = 255;
  int kernel_size_ = 3;
  int min_area_ = 1311;
  int dilate_iterations_ = 3;
  int keep_largest_ = 1;
  int fusion_mode_ = kOrFusion;

  cv::VideoCapture cap_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr raw_pub_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr hsv_mask_pub_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr lab_mask_pub_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr final_mask_pub_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);

  try {
    rclcpp::spin(std::make_shared<YellowChannelLab3InvertDenoiseDetector>());
  } catch (const std::exception &error) {
    RCLCPP_ERROR(
      rclcpp::get_logger("yellow_channel_lab3_invert_denoise_detector"),
      "节点启动失败: %s",
      error.what());
    rclcpp::shutdown();
    return 1;
  }

  rclcpp::shutdown();
  return 0;
}